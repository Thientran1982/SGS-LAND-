# ═══════════════════════════════════════════════
# FILE: .replit  — Replit run config
# ═══════════════════════════════════════════════
run = "npm run start"
language = "nodejs"
entrypoint = "src/multi-scraper.ts"

[env]
SCRAPER_PROXY_KEY = ""
SCRAPER_PROXY_URL = ""
USE_PLAYWRIGHT = "false"

[nix]
channel = "stable-23_11"

[deployment]
run = ["sh", "-c", "npm run start"]

[[ports]]
localPort = 3000
externalPort = 80

---
# ═══════════════════════════════════════════════
# FILE: package.json
# ═══════════════════════════════════════════════
{
  "name": "sgsland-multi-scraper",
  "version": "3.0.0",
  "description": "Multi-source BĐS scraper: sgsland.vn + batdongsan.com.vn + muaban.net",
  "type": "module",
  "scripts": {
    "start":      "tsx src/multi-scraper.ts",
    "sgsland":    "tsx src/multi-scraper.ts --sources=sgsland",
    "all-proxy":  "USE_PLAYWRIGHT=false tsx src/multi-scraper.ts",
    "all-pw":     "USE_PLAYWRIGHT=true tsx src/multi-scraper.ts",
    "install-pw": "npx playwright install chromium --with-deps"
  },
  "dependencies": {
    "cheerio":    "^1.0.0",
    "playwright": "^1.44.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "tsx":         "^4.0.0",
    "typescript":  "^5.4.0"
  }
}

---
# ═══════════════════════════════════════════════
# FILE: .env.example  — copy thành .env
# ═══════════════════════════════════════════════

# ── OPTION 1: ScraperAPI (dễ nhất, free 5000 calls/tháng) ──────
# Đăng ký: https://www.scraperapi.com (free tier)
SCRAPER_PROXY_KEY=your_scraperapi_key_here

# ── OPTION 2: BrightData ────────────────────────────────────────
# SCRAPER_PROXY_URL=http://user:pass@brd.superproxy.io:22225

# ── OPTION 3: Oxylabs ───────────────────────────────────────────
# SCRAPER_PROXY_URL=http://user:pass@residential.oxylabs.io:10000

# ── OPTION 4: Playwright headless (chậm hơn, không cần proxy) ──
# USE_PLAYWRIGHT=true

---
# ═══════════════════════════════════════════════
# FILE: README.md
# ═══════════════════════════════════════════════

# SGSLand Multi-Source Scraper v3.0

Thu thập BĐS từ 3 nguồn: **sgsland.vn** + **batdongsan.com.vn** + **muaban.net**

## Cài đặt trên Replit

```bash
npm install
```

## Cấu hình

Copy `.env.example` thành `.env` và điền key:

```bash
cp .env.example .env
```

## Chạy

### Chỉ sgsland.vn (không cần proxy)
```bash
npm run start
# hoặc
npm run sgsland
```

### Tất cả 3 nguồn với ScraperAPI
```bash
SCRAPER_PROXY_KEY=your_key npm run all-proxy
```

### Tất cả 3 nguồn với Playwright
```bash
npm run install-pw   # cài chromium 1 lần
USE_PLAYWRIGHT=true npm run all-pw
```

## Cách lấy ScraperAPI key (miễn phí)

1. Truy cập https://www.scraperapi.com
2. Đăng ký tài khoản (miễn phí, 5000 API calls/tháng)
3. Copy API key từ dashboard
4. Set `SCRAPER_PROXY_KEY=<key>` trong Replit Secrets

## Output

Tất cả data lưu vào `./output/` dạng JSON:
```json
{
  "total": 150,
  "unique": 140,
  "bySource": { "sgsland": 53, "batdongsan": 60, "muaban": 37 },
  "listings": [...]
}
```

## Schema thống nhất

| Field | Mô tả |
|-------|-------|
| `id` | UUID nội bộ |
| `source` | sgsland / batdongsan / muaban |
| `title` | Tiêu đề |
| `price` | Giá VND (null = thoả thuận) |
| `priceText` | "13.2 tỷ" |
| `area` | m² |
| `type` | Villa / Townhouse / Apartment / Land... |
| `transaction` | SALE / RENT |
| `locationFull` | Địa chỉ đầy đủ |
| `coordinates` | {lat, lng} nếu có |
| `images` | Mảng URL ảnh |
| `sourceUrl` | Link gốc |
| `scrapedAt` | ISO timestamp |
