// ================================================================
// SGSLand Multi-Source Scraper v3.0
// Nguồn: sgsland.vn (API) + batdongsan.com.vn + muaban.net
//
// Cấu trúc:
//   src/
//     adapters/
//       sgsland.ts      — API public, không cần proxy
//       batdongsan.ts   — cần proxy hoặc Playwright
//       muaban.ts       — cần proxy hoặc Playwright
//     core/
//       types.ts        — unified listing type
//       fetcher.ts      — HTTP client với proxy/Playwright
//       normalizer.ts   — normalize về cùng schema
//       deduper.ts      — loại trùng lặp cross-source
//     index.ts          — orchestrator chính
// ================================================================

// ────────────────────────────────────────────────────────────────
// FILE: src/core/types.ts
// ────────────────────────────────────────────────────────────────

export type Source = 'sgsland' | 'batdongsan' | 'muaban';

export type PropertyType =
  | 'Villa' | 'Townhouse' | 'Apartment' | 'Commercial'
  | 'Land' | 'Shophouse' | 'Room' | 'Warehouse' | string;

export type TransactionType = 'SALE' | 'RENT';

/** Schema thống nhất cho mọi nguồn */
export interface UnifiedListing {
  // ── Định danh ──
  id:         string;          // uuid nội bộ (tạo từ source+originalId)
  originalId: string;          // ID gốc từ nguồn
  source:     Source;
  sourceUrl:  string;

  // ── Nội dung ──
  title:       string;
  description: string | null;
  type:        PropertyType;
  transaction: TransactionType;

  // ── Giá ──
  price:       number | null;  // VND
  pricePerM2:  number | null;  // VND/m²
  currency:    'VND';
  priceText:   string;         // "13.2 tỷ" | "Thoả thuận"

  // ── Diện tích ──
  area:      number | null;    // m²
  bedrooms:  number | null;
  bathrooms: number | null;
  floors:    number | null;
  frontage:  number | null;    // m

  // ── Vị trí ──
  address:       string | null;
  ward:          string | null;
  district:      string | null;
  city:          string | null;
  locationFull:  string;       // full display string
  coordinates:   { lat: number; lng: number } | null;

  // ── Thuộc tính ──
  direction:  string | null;
  furniture:  string | null;
  legalType:  string | null;
  landType:   string | null;

  // ── Media ──
  images:      string[];       // URL ảnh

  // ── Liên hệ ──
  contactName:  string | null;
  contactPhone: string | null;

  // ── Meta ──
  postedAt:   string | null;
  updatedAt:  string | null;
  scrapedAt:  string;
  isVerified: boolean;
  viewCount:  number;
}

export interface ScraperProxyConfig {
  type:     'scraperapi' | 'brightdata' | 'oxylabs' | 'none';
  apiKey?:  string;
  endpoint?: string;
}

export interface ScraperPlaywrightConfig {
  enabled:      boolean;
  headless:     boolean;
  timeout:      number;
  userAgent?:   string;
}

export interface ScraperConfig {
  proxy:      ScraperProxyConfig;
  playwright: ScraperPlaywrightConfig;
  delayMs:    number;
  maxRetries: number;
  pageSize:   number;
  outputDir:  string;
  sources: {
    sgsland:    boolean;
    batdongsan: boolean;
    muaban:     boolean;
  };
  filters?: {
    city?:        string;    // 'Hồ Chí Minh' | 'Đồng Nai' | ...
    type?:        PropertyType;
    transaction?: TransactionType;
    minPrice?:    number;
    maxPrice?:    number;
    search?:      string;
  };
}


// ────────────────────────────────────────────────────────────────
// FILE: src/core/fetcher.ts
// Xử lý: direct fetch, ScraperAPI proxy, Playwright headless
// ────────────────────────────────────────────────────────────────

import * as crypto from 'crypto';

function uuid(input: string): string {
  return crypto.createHash('md5').update(input).digest('hex')
    .replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
}

const DEFAULT_HEADERS = {
  'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
  'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Cache-Control':   'no-cache',
  'Pragma':          'no-cache',
};

const JSON_HEADERS = {
  ...DEFAULT_HEADERS,
  'Accept': 'application/json, text/plain, */*',
};

// ── ScraperAPI proxy wrapper ──────────────────────────────────────

function wrapScraperAPI(url: string, apiKey: string, render = false): string {
  const params = new URLSearchParams({
    api_key: apiKey,
    url,
    ...(render ? { render: 'true' } : {}),
    country_code: 'vn',
    keep_headers: 'true',
  });
  return `http://api.scraperapi.com/?${params}`;
}

// ── BrightData proxy wrapper ──────────────────────────────────────

function wrapBrightData(url: string, endpoint: string): RequestInit {
  // BrightData dùng HTTP proxy — cần node-fetch với proxy agent
  // Ở đây trả về custom header để nhận biết
  return {
    headers: {
      ...JSON_HEADERS,
      'x-proxy-url': endpoint,
      'x-target-url': url,
    },
  };
}

// ── Core fetcher class ────────────────────────────────────────────

export class Fetcher {
  private cfg: ScraperConfig;

  constructor(cfg: ScraperConfig) {
    this.cfg = cfg;
  }

  async fetchHTML(url: string): Promise<string> {
    if (this.cfg.playwright.enabled) {
      return this.fetchWithPlaywright(url);
    }
    return this.fetchWithHttp(url, false);
  }

  async fetchJSON<T = any>(url: string): Promise<T> {
    const text = await this.fetchWithHttp(url, true);
    return JSON.parse(text) as T;
  }

  private buildUrl(url: string): string {
    const { proxy } = this.cfg;
    if (proxy.type === 'scraperapi' && proxy.apiKey) {
      return wrapScraperAPI(url, proxy.apiKey, false);
    }
    if (proxy.type === 'brightdata' && proxy.endpoint) {
      // BrightData cần proxy agent — trả về URL gốc, sẽ dùng agent riêng
      return url;
    }
    return url;
  }

  private async fetchWithHttp(url: string, isJSON: boolean, retries = 0): Promise<string> {
    const proxyUrl = this.buildUrl(url);
    const headers  = isJSON ? JSON_HEADERS : DEFAULT_HEADERS;

    try {
      const res = await fetch(proxyUrl, { headers: headers as HeadersInit });

      if (res.status === 429) {
        const wait = this.cfg.delayMs * Math.pow(2, retries + 1);
        console.warn(`  ⏳ Rate limited (429) — chờ ${wait}ms`);
        await sleep(wait);
        if (retries < this.cfg.maxRetries) return this.fetchWithHttp(url, isJSON, retries + 1);
        throw new Error(`Rate limited after ${retries} retries`);
      }

      if (res.status === 403 || res.status === 503) {
        throw new Error(`HTTP ${res.status} — cần proxy hoặc Playwright`);
      }

      if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);

      return await res.text();
    } catch (e) {
      if (retries < this.cfg.maxRetries) {
        await sleep(this.cfg.delayMs * (retries + 1));
        return this.fetchWithHttp(url, isJSON, retries + 1);
      }
      throw e;
    }
  }

  /**
   * Playwright/Puppeteer headless fetch
   * Cài: npm install playwright && npx playwright install chromium
   */
  private async fetchWithPlaywright(url: string): Promise<string> {
    // Dynamic import để không bắt buộc cài playwright nếu không dùng
    try {
      const { chromium } = await import('playwright');
      const browser = await chromium.launch({
        headless: this.cfg.playwright.headless,
        args: [
          '--no-sandbox', '--disable-setuid-sandbox',
          '--disable-blink-features=AutomationControlled',
        ],
      });

      const ctx  = await browser.newContext({
        userAgent: this.cfg.playwright.userAgent || DEFAULT_HEADERS['User-Agent'],
        locale: 'vi-VN',
        viewport: { width: 1366, height: 768 },
      });

      const page = await ctx.newPage();

      // Anti-detection
      await page.addInitScript(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      });

      await page.goto(url, {
        waitUntil: 'networkidle',
        timeout: this.cfg.playwright.timeout,
      });

      // Chờ content load với selector cụ thể
      await page.waitForTimeout(1500);

      const html = await page.content();
      await browser.close();
      return html;
    } catch (e: any) {
      if (e.message.includes('Cannot find module')) {
        throw new Error('Playwright chưa được cài. Chạy: npm install playwright && npx playwright install chromium');
      }
      throw e;
    }
  }
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }


// ────────────────────────────────────────────────────────────────
// FILE: src/adapters/sgsland.ts
// Nguồn: API public sgsland.vn — KHÔNG CẦN proxy
// ────────────────────────────────────────────────────────────────

export class SgsLandAdapter {
  private base = 'https://sgsland.vn';
  private cfg:  ScraperConfig;
  private fetcher: Fetcher;

  constructor(cfg: ScraperConfig) {
    this.cfg     = cfg;
    this.fetcher = new Fetcher(cfg);
  }

  async scrapeAll(): Promise<UnifiedListing[]> {
    console.log('\n[SGSLand] Bắt đầu scrape API...');
    const results: UnifiedListing[] = [];
    const page1 = await this.fetcher.fetchJSON<any>(this.buildUrl(1));
    const { total, totalPages } = page1;
    console.log(`[SGSLand] Total: ${total} listings / ${totalPages} trang`);

    results.push(...(page1.data || []).map((r: any) => this.normalize(r)));

    for (let p = 2; p <= totalPages; p++) {
      await sleep(this.cfg.delayMs);
      try {
        const d = await this.fetcher.fetchJSON<any>(this.buildUrl(p));
        results.push(...(d.data || []).map((r: any) => this.normalize(r)));
        console.log(`[SGSLand] Trang ${p}/${totalPages}: ${d.data?.length} items`);
      } catch (e: any) {
        console.error(`[SGSLand] Trang ${p} lỗi: ${e.message}`);
      }
    }

    console.log(`[SGSLand] Hoàn thành: ${results.length} listings`);
    return results;
  }

  private buildUrl(page: number): string {
    const p = new URLSearchParams({ page: String(page), pageSize: String(this.cfg.pageSize) });
    const f = this.cfg.filters || {};
    if (f.type)        p.set('type', f.type);
    if (f.transaction) p.set('transaction', f.transaction);
    if (f.search)      p.set('search', f.search);
    if (f.minPrice)    p.set('minPrice', String(f.minPrice));
    if (f.maxPrice)    p.set('maxPrice', String(f.maxPrice));
    return `${this.base}/api/public/listings?${p}`;
  }

  private normalize(raw: any): UnifiedListing {
    const pricePerM2 = raw.price && raw.area ? Math.round(raw.price / raw.area) : null;
    return {
      id:          uuid(`sgsland:${raw.id}`),
      originalId:  raw.id,
      source:      'sgsland',
      sourceUrl:   `${this.base}/listing/${raw.id}`,
      title:       raw.title || '',
      description: raw.attributes?.description || null,
      type:        raw.type || 'Unknown',
      transaction: raw.transaction || 'SALE',
      price:       raw.price || null,
      pricePerM2,
      currency:    'VND',
      priceText:   raw.price ? `${(raw.price / 1e9).toFixed(2)} tỷ` : 'Thoả thuận',
      area:        raw.area || null,
      bedrooms:    raw.bedrooms ?? null,
      bathrooms:   raw.bathrooms ?? null,
      floors:      raw.attributes?.floors ?? null,
      frontage:    raw.attributes?.frontage ?? null,
      address:     raw.address || null,
      ward:        null,
      district:    null,
      city:        null,
      locationFull: raw.location || '',
      coordinates: raw.coordinates || null,
      direction:   raw.attributes?.direction || null,
      furniture:   raw.attributes?.furniture || null,
      legalType:   raw.attributes?.legalType || null,
      landType:    raw.attributes?.landType || null,
      images:      (raw.images || []).map((i: any) => typeof i === 'string' ? i : i.url || ''),
      contactName:  raw.ownerName || raw.assignedToName || null,
      contactPhone: raw.contactPhone || raw.ownerPhone || null,
      postedAt:    raw.createdAt || null,
      updatedAt:   raw.updatedAt || null,
      scrapedAt:   new Date().toISOString(),
      isVerified:  raw.isVerified || false,
      viewCount:   raw.viewCount || 0,
    };
  }
}


// ────────────────────────────────────────────────────────────────
// FILE: src/adapters/batdongsan.ts
// Nguồn: batdongsan.com.vn — CẦN proxy hoặc Playwright
//
// CÁCH HOẠT ĐỘNG:
//   1. Fetch HTML trang listing qua proxy/Playwright
//   2. Parse HTML với cheerio (server-side jQuery)
//   3. Extract data từ CSS selectors đã xác nhận
//
// CSS SELECTORS (xác nhận từ cộng đồng Viblo + GitHub):
//   Container:  article.js__card  hoặc  div.re__card-full
//   Tiêu đề:    span.js__card-title  |  .re__card-title
//   Giá:        span.re__card-config-price  |  .js__card-price
//   Diện tích:  span.re__card-config-area   |  .js__card-area
//   Địa chỉ:    div.re__card-location span  |  .js__card-location
//   Link:       a.js__card-link[href]
//   Ảnh:        img.re__card-image[src]
// ────────────────────────────────────────────────────────────────

export class BatDongSanAdapter {
  private base = 'https://batdongsan.com.vn';
  private cfg:  ScraperConfig;
  private fetcher: Fetcher;

  constructor(cfg: ScraperConfig) {
    this.cfg     = cfg;
    this.fetcher = new Fetcher(cfg);
  }

  /** Map keyword tìm kiếm → path BDS */
  private buildSearchUrl(page: number): string {
    const f = this.cfg.filters || {};
    const categoryMap: Record<string, string> = {
      'SALE+Villa':       'ban-biet-thu-lien-ke',
      'SALE+Townhouse':   'ban-nha-rieng',
      'SALE+Apartment':   'ban-can-ho-chung-cu',
      'SALE+Land':        'ban-dat',
      'SALE+Commercial':  'ban-nha-mat-pho',
      'RENT+Apartment':   'cho-thue-can-ho-chung-cu',
      'RENT+Townhouse':   'cho-thue-nha-rieng',
      'SALE':             'nha-dat-ban',
      'RENT':             'nha-dat-cho-thue',
    };

    const txKey = f.transaction || 'SALE';
    const typeKey = f.type ? `${txKey}+${f.type}` : txKey;
    const category = categoryMap[typeKey] || categoryMap[txKey] || 'nha-dat-ban';

    // City slug map
    const cityMap: Record<string, string> = {
      'Hồ Chí Minh':  'tp-hcm',
      'Hà Nội':       'ha-noi',
      'Đồng Nai':     'dong-nai',
      'Bình Dương':   'binh-duong',
    };
    const citySlug = f.city ? cityMap[f.city] || '' : '';
    const cityPath = citySlug ? `-${citySlug}` : '';

    const pageStr = page > 1 ? `/p${page}` : '';
    return `${this.base}/${category}${cityPath}${pageStr}`;
  }

  async scrapeAll(): Promise<UnifiedListing[]> {
    if (this.cfg.proxy.type === 'none' && !this.cfg.playwright.enabled) {
      console.warn('[BatDongSan] ⚠️  Không có proxy/Playwright — sẽ bị block 403');
      console.warn('[BatDongSan]    Set SCRAPER_PROXY_URL hoặc bật playwright.enabled=true');
      return [];
    }

    console.log('\n[BatDongSan] Bắt đầu scrape...');
    // Dynamic import cheerio
    let cheerio: any;
    try {
      cheerio = await import('cheerio');
    } catch {
      throw new Error('Thiếu cheerio. Chạy: npm install cheerio');
    }

    const results: UnifiedListing[] = [];
    const MAX_PAGES = 10; // BDS có anti-bot nặng — giới hạn 10 trang

    for (let page = 1; page <= MAX_PAGES; page++) {
      await sleep(this.cfg.delayMs * 2); // BDS cần delay dài hơn
      const url = this.buildSearchUrl(page);
      console.log(`[BatDongSan] Trang ${page}: ${url}`);

      try {
        const html = await this.fetcher.fetchHTML(url);
        const $    = cheerio.load(html);

        // Thử các selectors khác nhau (BDS đổi class thường xuyên)
        const cards = $(
          'article.js__card, div.re__card-full, div[class*="card-full"], ' +
          'article[class*="js__card"], div.js__product-link-wrapper'
        );

        if (cards.length === 0) {
          console.warn(`[BatDongSan] Trang ${page}: Không tìm thấy card. Kiểm tra selector.`);
          // Debug: in ra 500 chars HTML đầu
          console.debug('[BatDongSan] HTML snippet:', html.substring(0, 500));
          break;
        }

        console.log(`[BatDongSan] Trang ${page}: ${cards.length} cards`);
        cards.each((_: number, el: any) => {
          const listing = this.parseCard($, el, url);
          if (listing) results.push(listing);
        });

        // Kiểm tra có trang tiếp không
        const hasNext = $('a.re__pagination-next, a[title*="Trang sau"]').length > 0;
        if (!hasNext && page > 1) break;

      } catch (e: any) {
        console.error(`[BatDongSan] Trang ${page} lỗi: ${e.message}`);
        if (e.message.includes('403') || e.message.includes('proxy')) break;
      }
    }

    console.log(`[BatDongSan] Hoàn thành: ${results.length} listings`);
    return results;
  }

  private parseCard($: any, el: any, baseUrl: string): UnifiedListing | null {
    try {
      const card = $(el);

      // ── Tiêu đề ──
      const title = (
        card.find('span.js__card-title, .re__card-title, h3 a, h2 a, a.js__card-link').first().text()
        || card.find('[class*="title"]').first().text()
      ).trim();
      if (!title) return null;

      // ── URL ──
      const href = (
        card.find('a.js__card-link, a[class*="link"]').first().attr('href')
        || card.find('a[href*="/mua-ban"], a[href*="/cho-thue"]').first().attr('href')
        || card.find('a').first().attr('href')
        || ''
      );
      const sourceUrl = href.startsWith('http') ? href : `${this.base}${href}`;
      const originalId = href.match(/pr(\d+)/)?.[1] || href.split('/').pop() || title.substring(0, 20);

      // ── Giá ──
      const priceText = (
        card.find('.re__card-config-price, .js__card-price, [class*="price"]').first().text()
        || card.find('[data-price]').first().attr('data-price')
        || 'Thoả thuận'
      ).trim();
      const price = this.parsePrice(priceText);

      // ── Diện tích ──
      const areaText = (
        card.find('.re__card-config-area, .js__card-area, [class*="area"]').first().text()
        || card.find('span[class*="m2"], span[class*="area"]').first().text()
        || ''
      ).trim();
      const area = this.parseArea(areaText);

      // ── Địa chỉ ──
      const locationText = (
        card.find('.re__card-location span, .js__card-location, [class*="location"]').first().text()
        || card.find('[class*="address"]').first().text()
        || ''
      ).trim();

      // ── Ảnh ──
      const imgSrc = (
        card.find('img.re__card-image, img[class*="image"], img[src*="cafeland"], img[data-src]').first().attr('src')
        || card.find('img').first().attr('data-src')
        || card.find('img').first().attr('src')
        || ''
      );

      // ── Loại BĐS từ URL ──
      const type = this.detectType(href, title);
      const transaction = href.includes('cho-thue') ? 'RENT' : 'SALE';

      // ── Phân tích location ──
      const { ward, district, city } = this.parseLocation(locationText);

      const pricePerM2 = price && area ? Math.round(price / area) : null;

      return {
        id:           uuid(`bds:${originalId}`),
        originalId,
        source:       'batdongsan',
        sourceUrl,
        title,
        description:  null,
        type,
        transaction,
        price,
        pricePerM2,
        currency:     'VND',
        priceText:    priceText || 'Thoả thuận',
        area,
        bedrooms:     this.parseNumber(card.find('[class*="bedroom"], [class*="room"]').first().text()),
        bathrooms:    this.parseNumber(card.find('[class*="bathroom"], [class*="toilet"]').first().text()),
        floors:       null,
        frontage:     null,
        address:      locationText || null,
        ward,
        district,
        city,
        locationFull: locationText,
        coordinates:  null,
        direction:    card.find('[class*="direction"]').first().text().trim() || null,
        furniture:    null,
        legalType:    null,
        landType:     null,
        images:       imgSrc ? [imgSrc] : [],
        contactName:  card.find('[class*="agent-name"], [class*="contact"]').first().text().trim() || null,
        contactPhone: null,
        postedAt:     card.find('[class*="date"], time').first().text().trim() || null,
        updatedAt:    null,
        scrapedAt:    new Date().toISOString(),
        isVerified:   card.find('[class*="verified"], [class*="xac-thuc"]').length > 0,
        viewCount:    0,
      };
    } catch {
      return null;
    }
  }

  private parsePrice(text: string): number | null {
    if (!text || text.toLowerCase().includes('thoả') || text.toLowerCase().includes('thoa')) return null;
    // "13.2 tỷ", "850 triệu", "13,200,000,000"
    const numMatch = text.replace(/[,\s]/g, '').match(/([\d.]+)\s*(tỷ|ty|triệu|trieu|tr|đ|d)/i);
    if (!numMatch) return null;
    const num  = parseFloat(numMatch[1]);
    const unit = numMatch[2].toLowerCase();
    if (unit.startsWith('tỷ') || unit === 'ty') return Math.round(num * 1e9);
    if (unit.startsWith('triệu') || unit === 'trieu' || unit === 'tr') return Math.round(num * 1e6);
    return Math.round(num);
  }

  private parseArea(text: string): number | null {
    const m = text.match(/([\d,]+\.?\d*)\s*m/i);
    if (!m) return null;
    return parseFloat(m[1].replace(/,/g, ''));
  }

  private parseNumber(text: string): number | null {
    const m = text.match(/\d+/);
    return m ? parseInt(m[0]) : null;
  }

  private detectType(href: string, title: string): PropertyType {
    const h = (href + title).toLowerCase();
    if (h.includes('biet-thu') || h.includes('biệt thự')) return 'Villa';
    if (h.includes('can-ho') || h.includes('chung-cu') || h.includes('căn hộ')) return 'Apartment';
    if (h.includes('nha-rieng') || h.includes('nhà riêng') || h.includes('nha-pho') || h.includes('nhà phố')) return 'Townhouse';
    if (h.includes('dat') || h.includes('đất')) return 'Land';
    if (h.includes('shophouse') || h.includes('mat-pho')) return 'Shophouse';
    if (h.includes('kho') || h.includes('warehouse')) return 'Warehouse';
    return 'Townhouse';
  }

  private parseLocation(text: string): { ward: string | null; district: string | null; city: string | null } {
    const parts = text.split(',').map(s => s.trim());
    return {
      ward:     parts[0] || null,
      district: parts[1] || null,
      city:     parts[parts.length - 1] || null,
    };
  }
}


// ────────────────────────────────────────────────────────────────
// FILE: src/adapters/muaban.ts
// Nguồn: muaban.net — CẦN proxy hoặc Playwright
//
// CSS SELECTORS muaban.net:
//   Container:  div.listing-item  hoặc  article.post
//   Tiêu đề:    h2.listing-title a  |  .post-title a
//   Giá:        span.price  |  .listing-price
//   Diện tích:  span.area   |  .listing-area
//   Địa chỉ:    span.location  |  .listing-location
// ────────────────────────────────────────────────────────────────

export class MuaBanAdapter {
  private base = 'https://muaban.net';
  private cfg:  ScraperConfig;
  private fetcher: Fetcher;

  constructor(cfg: ScraperConfig) {
    this.cfg     = cfg;
    this.fetcher = new Fetcher(cfg);
  }

  private buildSearchUrl(page: number): string {
    const f = this.cfg.filters || {};
    const categoryMap: Record<string, string> = {
      'SALE+Apartment': 'can-ho-chung-cu',
      'SALE+Townhouse': 'ban-nha',
      'SALE+Villa':     'ban-biet-thu',
      'SALE+Land':      'ban-dat-nen',
      'RENT+Apartment': 'cho-thue-can-ho',
      'RENT':           'cho-thue-bat-dong-san',
      'SALE':           'ban-nha',
    };
    const txKey   = f.transaction || 'SALE';
    const typeKey = f.type ? `${txKey}+${f.type}` : txKey;
    const cat     = categoryMap[typeKey] || categoryMap[txKey] || 'ban-nha';
    const pageStr = page > 1 ? `?page=${page}` : '';
    return `${this.base}/bat-dong-san/${cat}${pageStr}`;
  }

  async scrapeAll(): Promise<UnifiedListing[]> {
    if (this.cfg.proxy.type === 'none' && !this.cfg.playwright.enabled) {
      console.warn('[MuaBan] ⚠️  Không có proxy/Playwright — skip');
      return [];
    }

    console.log('\n[MuaBan] Bắt đầu scrape...');
    let cheerio: any;
    try { cheerio = await import('cheerio'); }
    catch { throw new Error('Thiếu cheerio. Chạy: npm install cheerio'); }

    const results: UnifiedListing[] = [];
    const MAX_PAGES = 10;

    for (let page = 1; page <= MAX_PAGES; page++) {
      await sleep(this.cfg.delayMs * 2);
      const url = this.buildSearchUrl(page);
      console.log(`[MuaBan] Trang ${page}: ${url}`);

      try {
        const html = await this.fetcher.fetchHTML(url);
        const $    = cheerio.load(html);

        const cards = $(
          'div.listing-item, article.post, div[class*="listing-item"], ' +
          'li.search-item, div.product-item, div[class*="adItem"]'
        );

        if (cards.length === 0) {
          console.warn(`[MuaBan] Trang ${page}: Không tìm thấy card`);
          break;
        }

        console.log(`[MuaBan] Trang ${page}: ${cards.length} cards`);
        cards.each((_: number, el: any) => {
          const listing = this.parseCard($, el);
          if (listing) results.push(listing);
        });

        const hasNext = $('a.next, a[rel="next"], .pagination a:contains("Tiếp")').length > 0;
        if (!hasNext && page > 1) break;

      } catch (e: any) {
        console.error(`[MuaBan] Trang ${page} lỗi: ${e.message}`);
        if (e.message.includes('403') || e.message.includes('proxy')) break;
      }
    }

    console.log(`[MuaBan] Hoàn thành: ${results.length} listings`);
    return results;
  }

  private parseCard($: any, el: any): UnifiedListing | null {
    try {
      const card = $(el);

      const title = (
        card.find('h2 a, h3 a, .listing-title a, .post-title a, [class*="title"] a').first().text()
        || card.find('a[href*="bat-dong-san"]').first().text()
      ).trim();
      if (!title) return null;

      const href = (
        card.find('a[href*="bat-dong-san"], a[href*="/mua-ban"]').first().attr('href')
        || card.find('h2 a, h3 a').first().attr('href')
        || ''
      );
      const sourceUrl  = href.startsWith('http') ? href : `${this.base}${href}`;
      const originalId = href.split('/').pop()?.split('?')[0] || title.substring(0, 20);

      const priceText = (
        card.find('span.price, .listing-price, [class*="price"]').first().text()
        || 'Thoả thuận'
      ).trim();
      const price = this.parsePrice(priceText);

      const areaText = (
        card.find('span.area, .listing-area, [class*="area"]').first().text()
        || ''
      ).trim();
      const area = this.parseArea(areaText);

      const locationText = (
        card.find('span.location, .listing-location, [class*="location"], [class*="address"]').first().text()
        || ''
      ).trim();

      const imgSrc = (
        card.find('img[src*="muaban"], img[data-src]').first().attr('src')
        || card.find('img').first().attr('data-src')
        || ''
      );

      const type = this.detectType(href, title);
      const transaction = (href + title).toLowerCase().includes('cho-thue') || (href + title).toLowerCase().includes('cho thuê') ? 'RENT' : 'SALE';

      const parts   = locationText.split(',').map((s: string) => s.trim());
      const pricePerM2 = price && area ? Math.round(price / area) : null;

      return {
        id:           uuid(`muaban:${originalId}`),
        originalId,
        source:       'muaban',
        sourceUrl,
        title,
        description:  null,
        type,
        transaction,
        price,
        pricePerM2,
        currency:     'VND',
        priceText,
        area,
        bedrooms:     null,
        bathrooms:    null,
        floors:       null,
        frontage:     null,
        address:      locationText || null,
        ward:         parts[0] || null,
        district:     parts[1] || null,
        city:         parts[parts.length - 1] || null,
        locationFull: locationText,
        coordinates:  null,
        direction:    null,
        furniture:    null,
        legalType:    null,
        landType:     null,
        images:       imgSrc ? [imgSrc] : [],
        contactName:  card.find('[class*="contact-name"], [class*="user"]').first().text().trim() || null,
        contactPhone: null,
        postedAt:     card.find('[class*="date"], time').first().text().trim() || null,
        updatedAt:    null,
        scrapedAt:    new Date().toISOString(),
        isVerified:   false,
        viewCount:    0,
      };
    } catch {
      return null;
    }
  }

  private parsePrice(text: string): number | null {
    if (!text || text.toLowerCase().includes('thoả')) return null;
    const m = text.replace(/[,\s]/g, '').match(/([\d.]+)\s*(tỷ|ty|triệu|trieu|tr)/i);
    if (!m) return null;
    const num  = parseFloat(m[1]);
    const unit = m[2].toLowerCase();
    if (unit.startsWith('tỷ') || unit === 'ty') return Math.round(num * 1e9);
    return Math.round(num * 1e6);
  }

  private parseArea(text: string): number | null {
    const m = text.match(/([\d,]+\.?\d*)\s*m/i);
    return m ? parseFloat(m[1].replace(/,/g, '')) : null;
  }

  private detectType(href: string, title: string): PropertyType {
    const h = (href + title).toLowerCase();
    if (h.includes('biet-thu') || h.includes('biệt thự')) return 'Villa';
    if (h.includes('can-ho') || h.includes('chung-cu')) return 'Apartment';
    if (h.includes('dat') || h.includes('đất')) return 'Land';
    return 'Townhouse';
  }
}


// ────────────────────────────────────────────────────────────────
// FILE: src/core/deduper.ts
// Loại bỏ listing trùng lặp cross-source (BDS + MuaBan + SGSLand)
// Logic: so sánh tiêu đề đã normalize + giá + diện tích
// ────────────────────────────────────────────────────────────────

export function deduplicate(listings: UnifiedListing[]): UnifiedListing[] {
  const seen = new Map<string, UnifiedListing>();

  for (const l of listings) {
    // Key dedup: normalize title + price + area
    const titleKey = l.title.toLowerCase()
      .replace(/\s+/g, ' ')
      .replace(/[^\w\s]/g, '')
      .substring(0, 60);
    const key = `${titleKey}|${l.price || 0}|${l.area || 0}`;

    if (!seen.has(key)) {
      seen.set(key, l);
    } else {
      // Ưu tiên: sgsland > batdongsan > muaban (sgsland có nhiều data nhất)
      const existing = seen.get(key)!;
      const priority: Record<Source, number> = { sgsland: 3, batdongsan: 2, muaban: 1 };
      if (priority[l.source] > priority[existing.source]) {
        seen.set(key, { ...l, id: existing.id }); // giữ id gốc
      }
    }
  }

  return Array.from(seen.values());
}


// ────────────────────────────────────────────────────────────────
// FILE: src/index.ts — Orchestrator chính
// ────────────────────────────────────────────────────────────────

import * as fs   from 'fs';
import * as path from 'path';

interface MultiSourceResult {
  total:    number;
  unique:   number;
  bySource: Record<Source, number>;
  listings: UnifiedListing[];
  scrapedAt: string;
  durationMs: number;
}

export async function runMultiScraper(cfg: ScraperConfig): Promise<MultiSourceResult> {
  const start = Date.now();
  const all: UnifiedListing[] = [];

  // ── 1. sgsland.vn (luôn chạy, API public) ──
  if (cfg.sources.sgsland) {
    const adapter = new SgsLandAdapter(cfg);
    const results = await adapter.scrapeAll();
    all.push(...results);
  }

  // ── 2. batdongsan.com.vn (cần proxy/Playwright) ──
  if (cfg.sources.batdongsan) {
    const adapter = new BatDongSanAdapter(cfg);
    const results = await adapter.scrapeAll();
    all.push(...results);
  }

  // ── 3. muaban.net (cần proxy/Playwright) ──
  if (cfg.sources.muaban) {
    const adapter = new MuaBanAdapter(cfg);
    const results = await adapter.scrapeAll();
    all.push(...results);
  }

  // ── 4. Dedup cross-source ──
  const unique = deduplicate(all);

  // ── 5. Count by source ──
  const bySource = all.reduce((acc, l) => {
    acc[l.source] = (acc[l.source] || 0) + 1;
    return acc;
  }, {} as Record<Source, number>);

  const result: MultiSourceResult = {
    total:     all.length,
    unique:    unique.length,
    bySource,
    listings:  unique,
    scrapedAt: new Date().toISOString(),
    durationMs: Date.now() - start,
  };

  // ── 6. Export ──
  fs.mkdirSync(cfg.outputDir, { recursive: true });
  const ts   = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(cfg.outputDir, `multi_${ts}.json`);
  fs.writeFileSync(file, JSON.stringify(result, null, 2));
  console.log(`\n💾 Saved: ${file}`);
  console.log(`📊 Total: ${all.length} raw → ${unique.length} unique`);
  console.log(`   By source:`, bySource);

  return result;
}

// ── CLI ────────────────────────────────────────────────────────

async function main() {
  const SCRAPER_PROXY_URL  = process.env.SCRAPER_PROXY_URL  || '';
  const SCRAPER_PROXY_KEY  = process.env.SCRAPER_PROXY_KEY  || '';
  const USE_PLAYWRIGHT     = process.env.USE_PLAYWRIGHT === 'true';

  // Detect proxy type từ URL
  const proxyType: ScraperProxyConfig['type'] =
    SCRAPER_PROXY_URL.includes('scraperapi') ? 'scraperapi' :
    SCRAPER_PROXY_URL.includes('brightdata') || SCRAPER_PROXY_URL.includes('brd') ? 'brightdata' :
    SCRAPER_PROXY_URL.includes('oxylabs')    ? 'oxylabs' :
    'none';

  const cfg: ScraperConfig = {
    proxy: {
      type:     SCRAPER_PROXY_KEY ? 'scraperapi' : proxyType,
      apiKey:   SCRAPER_PROXY_KEY || undefined,
      endpoint: SCRAPER_PROXY_URL || undefined,
    },
    playwright: {
      enabled:  USE_PLAYWRIGHT,
      headless: true,
      timeout:  30_000,
    },
    delayMs:    1200,
    maxRetries: 3,
    pageSize:   20,
    outputDir:  './output',
    sources: {
      sgsland:    true,
      batdongsan: !!(SCRAPER_PROXY_KEY || SCRAPER_PROXY_URL || USE_PLAYWRIGHT),
      muaban:     !!(SCRAPER_PROXY_KEY || SCRAPER_PROXY_URL || USE_PLAYWRIGHT),
    },
    filters: {
      transaction: 'SALE',
      // city: 'Hồ Chí Minh',
    },
  };

  console.log('🚀 Multi-Source BĐS Scraper v3.0');
  console.log(`   Proxy:      ${cfg.proxy.type}`);
  console.log(`   Playwright: ${cfg.playwright.enabled}`);
  console.log(`   Sources:    ${Object.entries(cfg.sources).filter(([,v])=>v).map(([k])=>k).join(', ')}`);
  if (cfg.proxy.type === 'none' && !cfg.playwright.enabled) {
    console.log('\n⚠️  QUAN TRỌNG: Chỉ sgsland.vn chạy được (API public)');
    console.log('   Để scrape BatDongSan + MuaBan, cần 1 trong:');
    console.log('   1. SCRAPER_PROXY_KEY=your_key  (ScraperAPI — free tier 5k calls/tháng)');
    console.log('   2. SCRAPER_PROXY_URL=http://...  (BrightData hoặc Oxylabs)');
    console.log('   3. USE_PLAYWRIGHT=true  (Playwright headless browser)');
  }

  await runMultiScraper(cfg);
}

main().catch(console.error);
