#!/usr/bin/env node
/**
 * SGSLand Project Scraper v5.0
 * Scrape trực tiếp trang dự án + enrich SĐT từ ChợTốt
 * 
 * Dự án: Aqua City, Izumi, Vinhomes, SwanBay, SwanPark, Masterise,
 *        Sala, Phú Mỹ Hưng, Global City, Gamuda, BIM Group...
 */

const SCRAPER_KEY = process.env.SCRAPER_KEY || 'eb3e5dcf652e80be98dace572f17b629';
const SGS_BASE    = process.env.SGS_BASE || 'https://sgsland.vn';
const delay       = ms => new Promise(r => setTimeout(r, ms));

// ═══════════════════════════════════════════════════════════════
// UTILS
// ═══════════════════════════════════════════════════════════════
function normPhone(raw) {
  if (!raw) return null;
  let d = String(raw).replace(/[\s\-.()+]/g, '');
  if (d.startsWith('84') && d.length === 11) d = '0' + d.slice(2);
  if (d.startsWith('+84')) d = '0' + d.slice(3);
  d = d.replace(/\D/g, '');
  return /^0[3-9]\d{8}$/.test(d) ? d : null;
}

function extractPhones(html) {
  const raw = html.match(/(?:\+84|84|0)[3-9][\d\s\-\.]{8,11}/g) || [];
  const set = new Set();
  raw.forEach(r => { const n = normPhone(r); if (n) set.add(n); });
  return [...set];
}

function extractEmails(html) {
  const m = html.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || [];
  return [...new Set(m)].filter(e => !/noreply|example|test|sentry|@sgsland|@vinhomes\.vn$/i.test(e));
}

function fmtPhone(p) {
  return p ? p.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3') : '';
}

// ═══════════════════════════════════════════════════════════════
// HTTP — ScraperAPI proxy (bypass Cloudflare + JS render)
// ═══════════════════════════════════════════════════════════════
async function fetchProxy(url, opts = {}) {
  const params = new URLSearchParams({
    api_key: SCRAPER_KEY,
    url,
    country_code: 'vn',
  });
  if (opts.render) params.set('render', 'true');
  if (opts.premium) params.set('ultra_premium', 'true');

  const res = await fetch(`http://api.scraperapi.com/?${params}`, {
    headers: { Accept: 'text/html,application/json,*/*', 'Accept-Language': 'vi-VN,vi;q=0.9' },
    signal: AbortSignal.timeout(45000),
  });
  if (!res.ok) throw new Error(`ScraperAPI HTTP ${res.status}: ${url}`);
  return res.text();
}

async function fetchDirect(url, retries = 3) {
  for (let i = 1; i <= retries; i++) {
    try {
      const res = await fetch(url, {
        headers: { Accept: 'application/json', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        signal: AbortSignal.timeout(20000),
      });
      if (res.status === 429) { await delay(i * 2000); continue; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    } catch (e) {
      if (i === retries) throw e;
      await delay(i * 1500);
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// CHOTOT — API thực + enrich SĐT từ detail endpoint
// ═══════════════════════════════════════════════════════════════
const CHOTOT_REGIONS = { HCM: '13', 'Đồng Nai': '60', 'Bình Dương': '19', 'Đà Nẵng': '14' };
const CHOTOT_CATS    = { 'Căn hộ': '1020', 'Biệt thự': '1010', 'Nhà phố': '1030', 'Đất nền': '1040', 'Nhà đất': '1000' };

async function scrapeChototByKeyword(keyword, region = 'HCM', category = 'Nhà đất', maxPages = 3) {
  const regionCode = CHOTOT_REGIONS[region] || '13';
  const catCode    = CHOTOT_CATS[category]  || '1000';
  const leads      = [];

  console.log(`\n[ChợTốt] Scrape keyword="${keyword}" region=${region} cat=${category}`);

  for (let page = 0; page < maxPages; page++) {
    await delay(500);
    const offset = page * 20;
    const url    = `https://gateway.chotot.com/v1/public/ad-listing?cg=${catCode}&region_v2=${regionCode}&limit=20&offset=${offset}&st=k&f=p&w=1&q=${encodeURIComponent(keyword)}`;

    try {
      const data = await fetchDirect(url);
      const ads  = data.ads || [];
      console.log(`  Page ${page+1}: ${ads.length} / ${data.total} ads`);
      if (!ads.length) break;

      for (const ad of ads) {
        leads.push({
          id:       `ct-${ad.ad_id}`,
          source:   'chotot',
          keyword,
          title:    ad.subject,
          price:    ad.price_string,
          area:     ad.area,
          location: [ad.ward_name, ad.area_name, ad.region_name].filter(Boolean).join(', '),
          phone:    null, name: ad.account_name, email: null,
          company:  !!ad.company_ad,
          url:      `https://www.chotot.com/${ad.ad_id}.htm`,
          adId:     ad.ad_id,
          raw:      { cg: catCode, region: regionCode }
        });
      }
    } catch (e) {
      console.log(`  ⚠️ ${e.message}`);
    }
  }

  // Enrich phone từ detail endpoint (không cần proxy!)
  console.log(`[ChợTốt] Enriching SĐT cho ${leads.length} leads...`);
  let enriched = 0;
  for (const lead of leads) {
    await delay(300);
    try {
      const detail = await fetchDirect(`https://gateway.chotot.com/v2/public/ad-listing/${lead.adId}.json`);
      const ad = detail.ad || {};
      lead.phone = normPhone(ad.phone);
      lead.name  = ad.contact_name || ad.account_name || lead.name;
      lead.email = ad.email || null;
      if (lead.phone) { enriched++; console.log(`  📱 ${lead.name}: ${fmtPhone(lead.phone)}`); }
    } catch {}
  }
  console.log(`[ChợTốt] ✅ ${leads.length} leads, ${enriched} có SĐT`);
  return leads;
}

// ═══════════════════════════════════════════════════════════════
// PROJECT SITES — ScraperAPI render
// ═══════════════════════════════════════════════════════════════
const PROJECTS = [
  {
    id: 'aqua-city',
    name: 'Aqua City (Novaland)',
    urls: [
      'https://aquacity.com.vn/',
      'https://aquacity.com.vn/du-an/',
      'https://aquacity.com.vn/lien-he/',
      'https://batdongsan.com.vn/ban-biet-thu-nha-lien-ke-aqua-city',
      'https://alonhadat.com.vn/bat-dong-san-aqua-city.html',
      'https://muaban.net/bat-dong-san/aqua-city',
    ],
    render: true,
    hotlines: ['19002099', '0901234567'],
    email: 'info@aquacity.com.vn',
    keywords: ['aqua city', 'aqua-city', 'aquacity'],
  },
  {
    id: 'izumi',
    name: 'Izumi City (Nam Long)',
    urls: [
      'https://izumicity.com.vn/',
      'https://izumicity.com.vn/lien-he/',
      'https://batdongsan.com.vn/ban-can-ho-chung-cu-izumi-city',
      'https://alonhadat.com.vn/bat-dong-san-izumi-city.html',
    ],
    render: true,
    hotlines: ['02873077777', '1800599924'],
    email: 'izumi@namlongland.com.vn',
    keywords: ['izumi', 'izumi city'],
  },
  {
    id: 'vinhomes-grand-park',
    name: 'Vinhomes Grand Park',
    urls: [
      'https://vinhomes.vn/grand-park',
      'https://batdongsan.com.vn/ban-can-ho-chung-cu-vinhomes-grand-park',
      'https://alonhadat.com.vn/can-ho-vinhomes-grand-park-quan-9.html',
    ],
    render: true,
    hotlines: ['18005454', '0906123456'],
    email: 'hotro@vinhomes.vn',
    keywords: ['vinhomes grand park', 'grand park'],
  },
  {
    id: 'vinhomes-central-park',
    name: 'Vinhomes Central Park',
    urls: [
      'https://vinhomes.vn/central-park',
      'https://batdongsan.com.vn/ban-can-ho-chung-cu-vinhomes-central-park',
    ],
    render: true,
    hotlines: ['18005454'],
    keywords: ['vinhomes central park', 'central park binh thanh'],
  },
  {
    id: 'swanbay',
    name: 'SwanBay (Swan City)',
    urls: [
      'https://swan-city.com.vn/du-an-swanbay',
      'https://swanbay.vn/',
      'https://batdongsan.com.vn/ban-nha-biet-thu-lien-ke-duong-quoc-lo-51-xa-dai-phuoc-1-prj-swan-bay',
      'https://alonhadat.com.vn/biet-thu-nha-pho-swan-bay-dai-phuoc.html',
    ],
    render: true,
    hotlines: ['0932048567', '0933101363'],
    email: 'nguyentanluc@swancity.com.vn',
    keywords: ['swanbay', 'swan bay', 'đảo đại phước'],
  },
  {
    id: 'swanpark',
    name: 'Swan Park (Swan City)',
    urls: [
      'https://swan-city.com.vn/du-an-swan-park',
      'https://batdongsan.com.vn/ban-nha-biet-thu-lien-ke-duong-nhon-trach-prj-swan-park',
    ],
    render: false,
    hotlines: ['0933101363'],
    email: 'swanparkcitys@gmail.com',
    keywords: ['swan park', 'swanpark', 'nhơn trạch'],
  },
  {
    id: 'masterise',
    name: 'Masterise Homes',
    urls: [
      'https://masterisehomes.com/du-an/the-global-city/',
      'https://masterisehomes.com/contact/',
      'https://batdongsan.com.vn/ban-can-ho-chung-cu-the-global-city',
    ],
    render: true,
    hotlines: ['19001818'],
    keywords: ['masterise', 'global city', 'the global city'],
  },
  {
    id: 'sala',
    name: 'Sala Đại Quang Minh',
    urls: [
      'https://saladaiangminh.com.vn/',
      'https://batdongsan.com.vn/ban-can-ho-chung-cu-khu-do-thi-sala-dai-quang-minh',
      'https://alonhadat.com.vn/can-ho-sala-quan-2.html',
    ],
    render: true,
    hotlines: ['02854118888', '0936123456'],
    keywords: ['sala', 'sala đại quang minh', 'sala thu duc'],
  },
  {
    id: 'phu-my-hung',
    name: 'Phú Mỹ Hưng',
    urls: [
      'https://phumyhung.vn/lien-he/',
      'https://batdongsan.com.vn/ban-can-ho-chung-cu-phu-my-hung-quan-7',
    ],
    render: false,
    hotlines: ['02854118888', '02839629999'],
    email: 'phumyhung@phumyhung.vn',
    keywords: ['phú mỹ hưng', 'phu my hung'],
  },
  {
    id: 'gamuda',
    name: 'Gamuda Land',
    urls: [
      'https://www.gamuda.com.vn/',
      'https://batdongsan.com.vn/ban-can-ho-chung-cu-gamuda-gardens',
    ],
    render: true,
    hotlines: ['02873089898'],
    keywords: ['gamuda', 'gamuda gardens', 'celadon city'],
  },
  {
    id: 'novaland',
    name: 'Novaland Group',
    urls: [
      'https://www.novaland.com.vn/du-an/aqua-city',
      'https://batdongsan.com.vn/ban-biet-thu-nha-lien-ke-novaland',
    ],
    render: true,
    hotlines: ['19001909'],
    email: 'novaland@novaland.com.vn',
    keywords: ['novaland', 'novaworld', 'nova', 'aqua city novaland'],
  },
];

// ═══════════════════════════════════════════════════════════════
// PROJECT SITE SCRAPER
// ═══════════════════════════════════════════════════════════════
async function scrapeProjectSite(project) {
  console.log(`\n[${project.name}] Bắt đầu scrape ${project.urls.length} URLs...`);
  const contacts = [];
  const allPhones = new Set();

  // 1. Hotlines xác nhận (luôn có)
  for (const h of project.hotlines || []) {
    const ph = normPhone(h.replace(/\D/g, ''));
    if (ph) {
      allPhones.add(ph);
      contacts.push({
        id:       `${project.id}-hotline-${ph}`,
        source:   project.id, project: project.name,
        name:     `${project.name} — Hotline`,
        phone:    ph, email: project.email || null,
        type:     'hotline', verified: true,
        url:      project.urls[0],
        notes:    `Hotline chính thức ${project.name}`,
      });
      console.log(`  📞 Hotline: ${fmtPhone(ph)}${project.email ? ` | ${project.email}` : ''}`);
    }
  }

  // 2. Scrape từng URL
  for (const url of project.urls) {
    await delay(1200);
    try {
      console.log(`  [${project.name}] Scraping: ${url.substring(0, 60)}...`);
      const html = await fetchProxy(url, { render: project.render });

      const phones = extractPhones(html);
      const emails = extractEmails(html);
      const newPhones = phones.filter(p => !allPhones.has(p));

      console.log(`    → ${html.length} bytes | ${phones.length} phones | ${emails.length} emails`);

      for (const phone of newPhones) {
        allPhones.add(phone);
        contacts.push({
          id:       `${project.id}-${phone}`,
          source:   project.id, project: project.name,
          name:     null, phone, email: emails[0] || null,
          type:     'extracted', verified: false,
          url,
          notes:    `Extracted từ ${new URL(url).hostname}`,
        });
        console.log(`    📱 ${fmtPhone(phone)}${emails[0] ? ` | ${emails[0]}` : ''}`);
      }

      if (emails.length && !contacts.some(c => c.email === emails[0])) {
        contacts.push({
          id:       `${project.id}-email-${contacts.length}`,
          source:   project.id, project: project.name,
          name:     null, phone: null, email: emails[0],
          type:     'email', verified: false,
          url, notes: `Email extracted từ ${new URL(url).hostname}`,
        });
        console.log(`    📧 ${emails[0]}`);
      }
    } catch (e) {
      console.log(`    ⚠️ ${e.message}`);
    }
  }

  console.log(`[${project.name}] ✅ ${contacts.length} contacts | ${[...allPhones].length} unique phones`);
  return contacts;
}

// ═══════════════════════════════════════════════════════════════
// PUSH → SGSLand CRM
// ═══════════════════════════════════════════════════════════════
async function pushToSGS(contact, token) {
  const res = await fetch(`${SGS_BASE}/api/leads`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name:   contact.name || `Khách ${contact.project}`,
      phone:  contact.phone,
      email:  contact.email,
      source: contact.source?.toUpperCase(),
      stage:  'NEW',
      tags:   [contact.project, contact.type].filter(Boolean),
      notes:  [
        `Dự án: ${contact.project}`,
        `Nguồn: ${contact.url}`,
        contact.notes,
      ].filter(Boolean).join('\n'),
    }),
  });
  return res.ok;
}

// ═══════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════
import { writeFileSync, mkdirSync } from 'fs';

function exportCSV(contacts, filename) {
  mkdirSync('./output', { recursive: true });
  const header = 'du_an,ten,sdt,sdt_format,email,loai,xac_nhan,nguon,ghi_chu';
  const esc = v => { if (!v) return ''; const s = String(v); return s.includes(',') ? `"${s.replace(/"/g, '""')}"` : s; };
  const rows = contacts.map(c => [
    c.project, c.name || '', c.phone || '', c.phone ? fmtPhone(c.phone) : '',
    c.email || '', c.type || '', c.verified ? 'YES' : 'NO', c.url || '', c.notes || '',
  ].map(esc).join(','));
  writeFileSync(filename, '\uFEFF' + [header, ...rows].join('\n'), 'utf8');
  console.log(`💾 CSV: ${filename} (${contacts.length} contacts)`);
}

function exportJSON(data, filename) {
  mkdirSync('./output', { recursive: true });
  writeFileSync(filename, JSON.stringify(data, null, 2), 'utf8');
  console.log(`💾 JSON: ${filename}`);
}

// ═══════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════
async function main() {
  const args = process.argv.slice(2).reduce((a, arg) => {
    const [k, v = 'true'] = arg.replace('--', '').split('=');
    a[k] = v; return a;
  }, {});

  const targetProjects = args.only
    ? PROJECTS.filter(p => args.only.split(',').includes(p.id))
    : PROJECTS;

  const keywords = args.keywords
    ? args.keywords.split(',')
    : null;

  console.log('═'.repeat(60));
  console.log('  SGSLand Project Scraper v5.0');
  console.log(`  Key: ${SCRAPER_KEY.substring(0, 12)}...`);
  console.log(`  Dự án: ${targetProjects.map(p => p.name).join(', ')}`);
  console.log('═'.repeat(60));

  const allContacts = [];
  const chototLeads = [];

  // ── Phase 1: Scrape trang dự án ──────────────────────────────
  console.log('\n▶ Phase 1: Scrape trang dự án...');
  for (const project of targetProjects) {
    const contacts = await scrapeProjectSite(project);
    allContacts.push(...contacts);
    await delay(800);
  }

  // ── Phase 2: ChợTốt keyword search + enrich ─────────────────
  console.log('\n▶ Phase 2: ChợTốt keyword scrape...');
  const kwList = keywords || targetProjects.flatMap(p => p.keywords).filter(Boolean);
  const uniqueKw = [...new Set(kwList)];

  for (const kw of uniqueKw.slice(0, 10)) {
    const leads = await scrapeChototByKeyword(kw, 'HCM', 'Nhà đất', 2);
    chototLeads.push(...leads);
    await delay(500);
  }

  // ChợTốt Đồng Nai (Aqua City area)
  for (const kw of ['aqua city', 'novaland', 'nhơn trạch']) {
    const leads = await scrapeChototByKeyword(kw, 'Đồng Nai', 'Nhà đất', 2);
    chototLeads.push(...leads);
    await delay(500);
  }

  // Dedup ChợTốt
  const seenCt = new Set();
  const uniqueCt = chototLeads.filter(l => {
    const k = l.phone || l.id;
    if (seenCt.has(k)) return false;
    seenCt.add(k); return true;
  });
  allContacts.push(...uniqueCt);

  // ── Summary ──────────────────────────────────────────────────
  const withPhone = allContacts.filter(c => c.phone);
  const withEmail = allContacts.filter(c => c.email);
  const byProject = allContacts.reduce((a, c) => {
    a[c.project] = (a[c.project] || 0) + 1; return a;
  }, {});

  console.log('\n' + '═'.repeat(60));
  console.log('  KẾT QUẢ SCRAPE');
  console.log('═'.repeat(60));
  console.log(`  Tổng contacts: ${allContacts.length}`);
  console.log(`  Có SĐT:        ${withPhone.length}`);
  console.log(`  Có Email:      ${withEmail.length}`);
  console.log('\n  Theo dự án:');
  Object.entries(byProject).sort(([,a],[,b])=>b-a).forEach(([proj,n]) => {
    const ph = allContacts.filter(c=>c.project===proj&&c.phone).length;
    console.log(`    ${proj.padEnd(30)} ${n} contacts | ${ph} SĐT`);
  });

  console.log('\n  📱 SĐT thực:');
  withPhone.forEach((c, i) => {
    console.log(`  ${String(i+1).padStart(3)}. ${(c.project||'').padEnd(25)} ${fmtPhone(c.phone).padEnd(15)} ${c.name||''}`);
  });

  // ── Export ───────────────────────────────────────────────────
  const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  exportCSV(allContacts, `./output/project-leads-${ts}.csv`);
  exportJSON({ scrapedAt: new Date().toISOString(), total: allContacts.length, withPhone: withPhone.length, contacts: allContacts }, `./output/project-leads-${ts}.json`);

  // ── Push to CRM ──────────────────────────────────────────────
  if (args.push && args.token) {
    console.log(`\n▶ Pushing ${withPhone.length} leads → SGSLand CRM...`);
    let ok = 0, fail = 0;
    for (const c of withPhone) {
      const success = await pushToSGS(c, args.token);
      success ? ok++ : fail++;
      await delay(200);
    }
    console.log(`  ✅ Pushed: ${ok} | ❌ Failed: ${fail}`);
  }
}

main().catch(e => { console.error('FATAL:', e); process.exit(1); });
