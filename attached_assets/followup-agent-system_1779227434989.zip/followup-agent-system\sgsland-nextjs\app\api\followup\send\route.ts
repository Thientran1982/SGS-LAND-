// POST /api/followup/send
// Multi-channel dispatcher: Zalo OA → SMS → Email
import { NextRequest, NextResponse } from "next/server";

const BACKEND = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000";
const ZALO_OA_SECRET = process.env.ZALO_OA_ACCESS_TOKEN ?? "";
const SMS_API_KEY = process.env.SMS_API_KEY ?? "";

interface SendPayload {
  followup_id?: string;
  session_id: string;
  channel: "zalo" | "sms" | "email" | "chat";
  day: string;
  message_text: string;
  recipient: {
    name?: string;
    phone?: string;
    email?: string;
    zalo_user_id?: string;
  };
}

// ─── Zalo OA sender ───────────────────────────────────────
async function sendZalo(userId: string, text: string): Promise<{ ok: boolean; message_id?: string }> {
  if (!ZALO_OA_SECRET) return { ok: false };

  const res = await fetch("https://openapi.zalo.me/v3.0/oa/message/cs", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      access_token: ZALO_OA_SECRET,
    },
    body: JSON.stringify({
      recipient: { user_id: userId },
      message: { text },
    }),
    signal: AbortSignal.timeout(8000),
  });

  const data = await res.json() as { error?: number; message?: string; data?: { message_id: string } };
  if (!res.ok || data.error !== 0) return { ok: false };
  return { ok: true, message_id: data.data?.message_id };
}

// ─── SMS sender (SpeedSMS / VNPT) ─────────────────────────
async function sendSMS(phone: string, text: string): Promise<{ ok: boolean; message_id?: string }> {
  if (!SMS_API_KEY) return { ok: false };

  const res = await fetch("https://api.speedsms.vn/index.php/sms/send", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Basic ${Buffer.from(SMS_API_KEY + ":x").toString("base64")}`,
    },
    body: JSON.stringify({
      to: [phone],
      content: text,
      type: 2, // Brandname
      sender: "SGSLAND",
    }),
    signal: AbortSignal.timeout(10000),
  });

  if (!res.ok) return { ok: false };
  const data = await res.json() as { status?: string; data?: { tranId?: string } };
  return { ok: data.status === "success", message_id: data.data?.tranId };
}

// ─── Email sender (via backend SMTP) ──────────────────────
async function sendEmail(
  email: string,
  name: string | undefined,
  text: string
): Promise<{ ok: boolean; message_id?: string }> {
  const res = await fetch(`${BACKEND}/api/notifications/email`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      to: email,
      to_name: name,
      subject: "SGS LAND — Thông tin BĐS dành riêng cho bạn",
      text,
      html: text.replace(/\n/g, "<br/>").replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>"),
    }),
    signal: AbortSignal.timeout(10000),
  });

  if (!res.ok) return { ok: false };
  const data = await res.json() as { message_id?: string };
  return { ok: true, message_id: data.message_id };
}

export async function POST(req: NextRequest) {
  try {
    const payload = await req.json() as SendPayload;
    const { channel, message_text, recipient, followup_id, session_id, day } = payload;

    let result: { ok: boolean; message_id?: string } = { ok: false };

    // ── Dispatch by channel ─────────────────────────────
    if (channel === "zalo" && recipient.zalo_user_id) {
      result = await sendZalo(recipient.zalo_user_id, message_text);
    } else if (channel === "sms" && recipient.phone) {
      result = await sendSMS(recipient.phone, message_text);
    } else if (channel === "email" && recipient.email) {
      result = await sendEmail(recipient.email, recipient.name, message_text);
    } else {
      // Chat re-engagement via backend push
      const res = await fetch(`${BACKEND}/api/followup/send`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(8000),
      });
      result = { ok: res.ok };
    }

    // ── Mark as sent in backend ─────────────────────────
    if (result.ok && followup_id) {
      await fetch(`${BACKEND}/api/followup/items/${followup_id}/sent`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sent_at: new Date().toISOString(),
          message_id: result.message_id,
          delivery_status: "sent",
        }),
        signal: AbortSignal.timeout(5000),
      }).catch(() => null); // non-blocking
    }

    if (result.ok) {
      return NextResponse.json({
        success: true,
        message_id: result.message_id,
        channel,
        day,
        session_id,
        delivery_status: "sent",
        sent_at: new Date().toISOString(),
      });
    }

    return NextResponse.json(
      { success: false, error: `Channel ${channel} send failed` },
      { status: 502 }
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ success: false, error: msg }, { status: 500 });
  }
}
