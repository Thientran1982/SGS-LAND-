"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  MessageCircle,
  Send,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  BarChart3,
  Play,
  Pause,
  Trash2,
  RefreshCw,
  Filter,
  Calendar,
  Phone,
  Mail,
  Zap,
  TrendingUp,
  Users,
  Eye,
  MessageSquare,
  ChevronDown,
  ChevronRight,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────
type FollowUpDay = "d1" | "d3" | "d5" | "d7";
type Channel = "zalo" | "sms" | "email" | "chat";
type Status = "pending" | "sent" | "failed" | "cancelled";

interface SequenceItem {
  id: string;
  day: FollowUpDay;
  channel: Channel;
  status: Status;
  scheduled_at: string;
  sent_at?: string;
  opened_at?: string;
  replied_at?: string;
  converted?: boolean;
  message_preview?: string;
  error_message?: string;
}

interface Sequence {
  id: string;
  lead_id?: string;
  session_id: string;
  status: "active" | "completed" | "cancelled";
  created_at: string;
  channel: Channel;
  recipient_name?: string;
  recipient_phone?: string;
  items: SequenceItem[];
  context?: {
    budget?: number;
    location?: string;
    project_interest?: string;
  };
}

interface Stats {
  total_scheduled: number;
  total_sent: number;
  total_opened: number;
  total_replied: number;
  total_converted: number;
  open_rate: number;
  reply_rate: number;
  conversion_rate: number;
  by_day: Record<FollowUpDay, { sent: number; opened: number; converted: number }>;
}

// ─── Mock Data (used when backend unavailable) ────────────
const MOCK_STATS: Stats = {
  total_scheduled: 342,
  total_sent: 298,
  total_opened: 201,
  total_replied: 89,
  total_converted: 24,
  open_rate: 0.674,
  reply_rate: 0.299,
  conversion_rate: 0.081,
  by_day: {
    d1: { sent: 298, opened: 201, converted: 12 },
    d3: { sent: 276, opened: 165, converted: 7 },
    d5: { sent: 251, opened: 132, converted: 4 },
    d7: { sent: 198, opened: 87, converted: 1 },
  },
};

const MOCK_SEQUENCES: Sequence[] = [
  {
    id: "seq_001",
    session_id: "sess_abc123",
    status: "active",
    created_at: new Date(Date.now() - 86400000).toISOString(),
    channel: "zalo",
    recipient_name: "Nguyễn Văn An",
    recipient_phone: "0912 345 678",
    context: { budget: 3000000000, location: "Long Thành", project_interest: "Aqua City" },
    items: [
      { id: "i1", day: "d1", channel: "zalo", status: "sent", scheduled_at: new Date(Date.now() - 82800000).toISOString(), sent_at: new Date(Date.now() - 82000000).toISOString(), opened_at: new Date(Date.now() - 81000000).toISOString(), message_preview: "Xin chào, Nguyễn Văn An! 👋 Tôi là SGS AI từ SGS LAND..." },
      { id: "i2", day: "d3", channel: "zalo", status: "pending", scheduled_at: new Date(Date.now() + 172800000).toISOString(), message_preview: "Chào, Nguyễn Văn An! 📊 Tin thị trường BĐS Long Thành..." },
      { id: "i3", day: "d5", channel: "zalo", status: "pending", scheduled_at: new Date(Date.now() + 345600000).toISOString(), message_preview: "Xin chào, Nguyễn Văn An! 🏠 Chúng tôi vừa cập nhật 12 BĐS mới..." },
      { id: "i4", day: "d7", channel: "zalo", status: "pending", scheduled_at: new Date(Date.now() + 518400000).toISOString(), message_preview: "Chào Nguyễn Văn An, Đây là tin nhắn cuối..." },
    ],
  },
  {
    id: "seq_002",
    session_id: "sess_def456",
    status: "active",
    created_at: new Date(Date.now() - 3 * 86400000).toISOString(),
    channel: "sms",
    recipient_name: "Trần Thị Bích",
    recipient_phone: "0987 654 321",
    context: { budget: 5000000000, location: "Quận 7", project_interest: "Midtown" },
    items: [
      { id: "i5", day: "d1", channel: "sms", status: "sent", scheduled_at: new Date(Date.now() - 3 * 86400000 + 3600000).toISOString(), sent_at: new Date(Date.now() - 3 * 86400000 + 4000000).toISOString(), opened_at: undefined, message_preview: "Xin chào, Trần Thị Bích!..." },
      { id: "i6", day: "d3", channel: "sms", status: "sent", scheduled_at: new Date(Date.now() - 86400000).toISOString(), sent_at: new Date(Date.now() - 85000000).toISOString(), replied_at: new Date(Date.now() - 84000000).toISOString(), message_preview: "Chào, Trần Thị Bích! 📊 Tin thị trường..." },
      { id: "i7", day: "d5", channel: "sms", status: "pending", scheduled_at: new Date(Date.now() + 172800000).toISOString(), message_preview: "Xin chào, Trần Thị Bích! 🏠..." },
      { id: "i8", day: "d7", channel: "sms", status: "pending", scheduled_at: new Date(Date.now() + 345600000).toISOString(), message_preview: "Chào Trần Thị Bích, Đây là tin nhắn cuối..." },
    ],
  },
  {
    id: "seq_003",
    session_id: "sess_ghi789",
    status: "completed",
    created_at: new Date(Date.now() - 8 * 86400000).toISOString(),
    channel: "zalo",
    recipient_name: "Lê Hoàng Minh",
    recipient_phone: "0901 111 222",
    context: { budget: 2000000000, location: "Nhơn Trạch" },
    items: [
      { id: "i9", day: "d1", channel: "zalo", status: "sent", scheduled_at: "", sent_at: new Date(Date.now() - 7 * 86400000).toISOString(), opened_at: new Date(Date.now() - 7 * 86400000 + 3600000).toISOString(), converted: true, message_preview: "Xin chào, Lê Hoàng Minh!..." },
      { id: "i10", day: "d3", channel: "zalo", status: "cancelled", scheduled_at: "", message_preview: "Hủy — khách đã chuyển đổi" },
      { id: "i11", day: "d5", channel: "zalo", status: "cancelled", scheduled_at: "", message_preview: "Hủy — khách đã chuyển đổi" },
      { id: "i12", day: "d7", channel: "zalo", status: "cancelled", scheduled_at: "", message_preview: "Hủy — khách đã chuyển đổi" },
    ],
  },
];

// ─── Helpers ──────────────────────────────────────────────
const DAY_LABELS: Record<FollowUpDay, string> = {
  d1: "Ngày 1",
  d3: "Ngày 3",
  d5: "Ngày 5",
  d7: "Ngày 7",
};

const CHANNEL_ICONS: Record<Channel, React.ElementType> = {
  zalo: MessageCircle,
  sms: Phone,
  email: Mail,
  chat: MessageSquare,
};

const CHANNEL_COLORS: Record<Channel, string> = {
  zalo: "#0068ff",
  sms: "#10b981",
  email: "#f59e0b",
  chat: "#8b5cf6",
};

const STATUS_CONFIG: Record<Status, { label: string; icon: React.ElementType; color: string }> = {
  pending: { label: "Chờ gửi", icon: Clock, color: "var(--text-secondary)" },
  sent: { label: "Đã gửi", icon: CheckCircle, color: "#10b981" },
  failed: { label: "Lỗi", icon: XCircle, color: "#ef4444" },
  cancelled: { label: "Đã hủy", icon: XCircle, color: "var(--text-muted)" },
};

function pct(n: number) {
  return `${(n * 100).toFixed(1)}%`;
}

function fmtDate(iso: string) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function fmtBudget(n?: number) {
  if (!n) return "";
  if (n >= 1e9) return `${(n / 1e9).toFixed(1)} tỷ`;
  return `${(n / 1e6).toFixed(0)} triệu`;
}

// ─── Sub-components ───────────────────────────────────────
function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  color?: string;
}) {
  return (
    <div
      className="rounded-xl p-4 flex items-start gap-3"
      style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)" }}
    >
      <div
        className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
        style={{ background: color ? `${color}18` : "var(--primary-subtle)" }}
      >
        <Icon className="w-4 h-4" style={{ color: color ?? "var(--primary-600)" }} />
      </div>
      <div>
        <p className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</p>
        <p className="text-xl font-bold leading-tight" style={{ color: "var(--text-primary)" }}>
          {value}
        </p>
        {sub && <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>{sub}</p>}
      </div>
    </div>
  );
}

function SequenceRow({ seq, onCancel, onRefresh }: {
  seq: Sequence;
  onCancel: (id: string) => void;
  onRefresh: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  const sentCount = seq.items.filter((i) => i.status === "sent").length;
  const openedCount = seq.items.filter((i) => i.opened_at).length;
  const repliedCount = seq.items.filter((i) => i.replied_at).length;
  const convertedCount = seq.items.filter((i) => i.converted).length;
  const ChanIcon = CHANNEL_ICONS[seq.channel];

  const handleCancel = async () => {
    if (!confirm(`Hủy toàn bộ follow-up cho ${seq.recipient_name || seq.session_id}?`)) return;
    setCancelling(true);
    try {
      await fetch("/api/followup/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sequence_id: seq.id, reason: "manual" }),
      });
      onCancel(seq.id);
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{ border: "1px solid var(--border-default)", background: "var(--bg-surface)" }}
    >
      {/* Row header */}
      <div
        className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-[var(--bg-elevated)] transition-colors"
        onClick={() => setExpanded((v) => !v)}
      >
        {/* Channel icon */}
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center shrink-0"
          style={{ background: `${CHANNEL_COLORS[seq.channel]}18` }}
        >
          <ChanIcon className="w-4 h-4" style={{ color: CHANNEL_COLORS[seq.channel] }} />
        </div>

        {/* Recipient */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate" style={{ color: "var(--text-primary)" }}>
            {seq.recipient_name || `Session ${seq.session_id.slice(-6)}`}
            {seq.context?.project_interest && (
              <span className="ml-2 text-xs font-normal" style={{ color: "var(--text-secondary)" }}>
                · {seq.context.project_interest}
              </span>
            )}
          </p>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            {seq.recipient_phone} · {seq.channel.toUpperCase()}
            {seq.context?.budget && ` · ${fmtBudget(seq.context.budget)}`}
          </p>
        </div>

        {/* Progress pills */}
        <div className="hidden sm:flex items-center gap-4 text-xs" style={{ color: "var(--text-secondary)" }}>
          <span title="Đã gửi"><Send className="w-3 h-3 inline mr-0.5" />{sentCount}/4</span>
          <span title="Đã mở"><Eye className="w-3 h-3 inline mr-0.5" />{openedCount}</span>
          <span title="Đã reply"><MessageSquare className="w-3 h-3 inline mr-0.5" />{repliedCount}</span>
          {convertedCount > 0 && (
            <span className="font-semibold text-emerald-500" title="Chuyển đổi">
              🎯 {convertedCount}
            </span>
          )}
        </div>

        {/* Status badge */}
        <span
          className="text-xs px-2 py-0.5 rounded-full font-medium shrink-0"
          style={{
            background:
              seq.status === "active" ? "#dcfce7" :
              seq.status === "completed" ? "#dbeafe" : "#f3f4f6",
            color:
              seq.status === "active" ? "#15803d" :
              seq.status === "completed" ? "#1d4ed8" : "#6b7280",
          }}
        >
          {seq.status === "active" ? "Đang chạy" :
           seq.status === "completed" ? "Hoàn thành" : "Đã hủy"}
        </span>

        {/* Actions */}
        <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
          {seq.status === "active" && (
            <button
              onClick={handleCancel}
              disabled={cancelling}
              className="p-1.5 rounded-lg hover:bg-red-50 transition-colors"
              title="Hủy sequence"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
            </button>
          )}
          {expanded ? (
            <ChevronDown className="w-4 h-4" style={{ color: "var(--text-muted)" }} />
          ) : (
            <ChevronRight className="w-4 h-4" style={{ color: "var(--text-muted)" }} />
          )}
        </div>
      </div>

      {/* Expanded: timeline */}
      {expanded && (
        <div
          className="px-4 pb-4 border-t"
          style={{ borderColor: "var(--border-default)", background: "var(--bg-elevated)" }}
        >
          <div className="mt-3 space-y-2">
            {seq.items.map((item) => {
              const cfg = STATUS_CONFIG[item.status];
              const StatusIcon = cfg.icon;
              return (
                <div key={item.id} className="flex items-start gap-2.5">
                  <div className="mt-0.5">
                    <StatusIcon className="w-4 h-4" style={{ color: cfg.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-semibold" style={{ color: "var(--text-primary)" }}>
                        {DAY_LABELS[item.day]}
                      </span>
                      <span className="text-xs" style={{ color: cfg.color }}>{cfg.label}</span>
                      {item.scheduled_at && (
                        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                          📅 {fmtDate(item.scheduled_at)}
                        </span>
                      )}
                      {item.sent_at && (
                        <span className="text-xs text-emerald-600">✅ Gửi {fmtDate(item.sent_at)}</span>
                      )}
                      {item.opened_at && (
                        <span className="text-xs text-blue-500">👁️ Mở {fmtDate(item.opened_at)}</span>
                      )}
                      {item.replied_at && (
                        <span className="text-xs text-purple-500">💬 Reply {fmtDate(item.replied_at)}</span>
                      )}
                      {item.converted && (
                        <span className="text-xs font-bold text-emerald-600">🎯 Chuyển đổi!</span>
                      )}
                    </div>
                    {item.message_preview && (
                      <p className="text-xs mt-0.5 truncate" style={{ color: "var(--text-muted)" }}>
                        {item.message_preview}
                      </p>
                    )}
                    {item.error_message && (
                      <p className="text-xs text-red-400 mt-0.5">{item.error_message}</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Created at */}
          <p className="text-xs mt-3" style={{ color: "var(--text-muted)" }}>
            Tạo lúc: {fmtDate(seq.created_at)} · Session: {seq.session_id}
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────
export default function SequencesPage() {
  const [stats, setStats] = useState<Stats>(MOCK_STATS);
  const [sequences, setSequences] = useState<Sequence[]>(MOCK_SEQUENCES);
  const [loading, setLoading] = useState(false);
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "completed" | "cancelled">("all");
  const [filterChannel, setFilterChannel] = useState<"all" | Channel>("all");
  const [period, setPeriod] = useState<"today" | "week" | "month">("week");
  const [cronRunning, setCronRunning] = useState(false);
  const [cronResult, setCronResult] = useState<string>("");

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [seqRes, statsRes] = await Promise.allSettled([
        fetch(`/api/followup/sequences?status=${filterStatus}&channel=${filterChannel}&limit=50`),
        fetch(`/api/followup/stats?period=${period}`),
      ]);

      if (seqRes.status === "fulfilled" && seqRes.value.ok) {
        const d = await seqRes.value.json() as { data?: Sequence[] };
        if (d.data) setSequences(d.data);
      }
      if (statsRes.status === "fulfilled" && statsRes.value.ok) {
        const d = await statsRes.value.json() as Stats;
        setStats(d);
      }
    } catch {
      // Use mock data
    } finally {
      setLoading(false);
    }
  }, [filterStatus, filterChannel, period]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleCancelSequence = (id: string) => {
    setSequences((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status: "cancelled" } : s))
    );
  };

  const handleRunCron = async () => {
    setCronRunning(true);
    setCronResult("");
    try {
      const res = await fetch("/api/cron/followup", {
        headers: { "x-internal": "manual-trigger" },
      });
      const data = await res.json() as {
        success?: boolean;
        processed?: number;
        sent?: number;
        failed?: number;
      };
      setCronResult(
        data.success
          ? `✅ Cron chạy thành công: xử lý ${data.processed ?? 0} items, gửi ${data.sent ?? 0}, lỗi ${data.failed ?? 0}`
          : "❌ Cron gặp lỗi"
      );
      await fetchData();
    } catch {
      setCronResult("❌ Không thể kết nối cron");
    } finally {
      setCronRunning(false);
    }
  };

  const filteredSequences = sequences.filter((s) => {
    if (filterStatus !== "all" && s.status !== filterStatus) return false;
    if (filterChannel !== "all" && s.channel !== filterChannel) return false;
    return true;
  });

  return (
    <div className="p-6 max-w-6xl space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: "var(--text-primary)" }}>
            Follow-Up Sequences
          </h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--text-secondary)" }}>
            Tự động nhắn lại khách D+1, D+3, D+5, D+7 qua Zalo OA / SMS / Email
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleRunCron}
            disabled={cronRunning}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all disabled:opacity-60"
            style={{ background: "var(--primary-subtle)", color: "var(--primary-700, #1d4ed8)", border: "1px solid var(--primary-200, #bfdbfe)" }}
          >
            {cronRunning ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Zap className="w-4 h-4" />
            )}
            Chạy Cron Thủ Công
          </button>
          <button
            onClick={fetchData}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all"
            style={{ background: "var(--bg-elevated)", color: "var(--text-secondary)", border: "1px solid var(--border-default)" }}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            Làm mới
          </button>
        </div>
      </div>

      {cronResult && (
        <div
          className="px-4 py-2.5 rounded-lg text-sm"
          style={{
            background: cronResult.startsWith("✅") ? "#ecfdf5" : "#fef2f2",
            border: `1px solid ${cronResult.startsWith("✅") ? "#10b981" : "#ef4444"}`,
            color: cronResult.startsWith("✅") ? "#065f46" : "#7f1d1d",
          }}
        >
          {cronResult}
        </div>
      )}

      {/* Stats Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
            Thống kê hiệu quả
          </h2>
          <div className="flex items-center gap-1">
            {(["today", "week", "month"] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                style={{
                  background: period === p ? "var(--primary-600)" : "var(--bg-elevated)",
                  color: period === p ? "#fff" : "var(--text-secondary)",
                  border: period === p ? "none" : "1px solid var(--border-default)",
                }}
              >
                {p === "today" ? "Hôm nay" : p === "week" ? "7 ngày" : "30 ngày"}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          <StatCard icon={Send} label="Đã gửi" value={stats.total_sent} sub={`/ ${stats.total_scheduled} lên lịch`} />
          <StatCard icon={Eye} label="Tỷ lệ mở" value={pct(stats.open_rate)} sub={`${stats.total_opened} khách`} color="#3b82f6" />
          <StatCard icon={MessageSquare} label="Tỷ lệ reply" value={pct(stats.reply_rate)} sub={`${stats.total_replied} reply`} color="#8b5cf6" />
          <StatCard icon={TrendingUp} label="Chuyển đổi" value={pct(stats.conversion_rate)} sub={`${stats.total_converted} khách`} color="#10b981" />
          <StatCard icon={Users} label="Tổng lead" value={sequences.length} sub={`${sequences.filter((s) => s.status === "active").length} đang chạy`} color="#f59e0b" />
        </div>

        {/* By day breakdown */}
        <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-3">
          {(["d1", "d3", "d5", "d7"] as FollowUpDay[]).map((day) => {
            const d = stats.by_day[day];
            const openRate = d.sent > 0 ? d.opened / d.sent : 0;
            return (
              <div
                key={day}
                className="rounded-xl p-3"
                style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)" }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold" style={{ color: "var(--text-primary)" }}>
                    {DAY_LABELS[day]}
                  </span>
                  <Calendar className="w-3.5 h-3.5" style={{ color: "var(--text-muted)" }} />
                </div>
                <p className="text-lg font-bold" style={{ color: "var(--text-primary)" }}>{d.sent}</p>
                <p className="text-xs" style={{ color: "var(--text-muted)" }}>gửi</p>
                <div className="mt-1.5 h-1 rounded-full" style={{ background: "var(--border-default)" }}>
                  <div
                    className="h-1 rounded-full"
                    style={{ width: `${openRate * 100}%`, background: "var(--primary-600)" }}
                  />
                </div>
                <p className="text-xs mt-1" style={{ color: "var(--text-secondary)" }}>
                  {pct(openRate)} mở · {d.converted} chuyển đổi
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Cron Schedule Info */}
      <div
        className="rounded-xl p-4 flex items-start gap-3"
        style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)" }}
      >
        <Clock className="w-5 h-5 shrink-0 mt-0.5" style={{ color: "var(--primary-600)" }} />
        <div>
          <p className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
            Cron Job — Chạy mỗi giờ
          </p>
          <p className="text-xs mt-1" style={{ color: "var(--text-secondary)" }}>
            <strong>Vercel:</strong>{" "}
            <code
              className="px-1.5 py-0.5 rounded text-xs"
              style={{ background: "var(--bg-surface)", fontFamily: "monospace" }}
            >
              vercel.json → crons: [{'"'}path{'"'}: {'"'}/api/cron/followup{'"'}, {'"'}schedule{'"'}: {'"'}0 * * * *{'"'}]
            </code>
            <br />
            <strong>Ubuntu PM2:</strong>{" "}
            <code
              className="px-1.5 py-0.5 rounded text-xs mt-1 inline-block"
              style={{ background: "var(--bg-surface)", fontFamily: "monospace" }}
            >
              0 * * * * curl -H {'"'}Authorization: Bearer $CRON_SECRET{'"'} https://sgsland.vn/api/cron/followup
            </code>
          </p>
        </div>
      </div>

      {/* Sequences List */}
      <div>
        {/* Filters */}
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <Filter className="w-4 h-4" style={{ color: "var(--text-muted)" }} />
          <div className="flex items-center gap-1">
            {(["all", "active", "completed", "cancelled"] as const).map((s) => (
              <button
                key={s}
                onClick={() => setFilterStatus(s)}
                className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                style={{
                  background: filterStatus === s ? "var(--primary-600)" : "var(--bg-elevated)",
                  color: filterStatus === s ? "#fff" : "var(--text-secondary)",
                  border: filterStatus === s ? "none" : "1px solid var(--border-default)",
                }}
              >
                {s === "all" ? "Tất cả" : s === "active" ? "Đang chạy" : s === "completed" ? "Hoàn thành" : "Đã hủy"}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1">
            {(["all", "zalo", "sms", "email", "chat"] as const).map((c) => (
              <button
                key={c}
                onClick={() => setFilterChannel(c)}
                className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all capitalize"
                style={{
                  background: filterChannel === c ? (c === "all" ? "var(--primary-600)" : `${CHANNEL_COLORS[c as Channel]}18`) : "var(--bg-elevated)",
                  color: filterChannel === c ? (c === "all" ? "#fff" : CHANNEL_COLORS[c as Channel]) : "var(--text-secondary)",
                  border: filterChannel === c ? `1px solid ${c === "all" ? "var(--primary-600)" : CHANNEL_COLORS[c as Channel]}` : "1px solid var(--border-default)",
                }}
              >
                {c === "all" ? "Mọi kênh" : c.toUpperCase()}
              </button>
            ))}
          </div>
          <span className="ml-auto text-xs" style={{ color: "var(--text-muted)" }}>
            {filteredSequences.length} sequences
          </span>
        </div>

        {/* List */}
        {filteredSequences.length === 0 ? (
          <div
            className="text-center py-12 rounded-xl"
            style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)" }}
          >
            <MessageCircle className="w-10 h-10 mx-auto mb-3" style={{ color: "var(--text-muted)" }} />
            <p style={{ color: "var(--text-secondary)" }}>Không có follow-up sequence nào</p>
            <p className="text-sm mt-1" style={{ color: "var(--text-muted)" }}>
              Sequences sẽ tự động tạo khi khách để lại thông tin trong chat widget
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {filteredSequences.map((seq) => (
              <SequenceRow
                key={seq.id}
                seq={seq}
                onCancel={handleCancelSequence}
                onRefresh={fetchData}
              />
            ))}
          </div>
        )}
      </div>

      {/* Templates Reference */}
      <div>
        <h2 className="text-sm font-semibold mb-3" style={{ color: "var(--text-primary)" }}>
          Templates Mẫu
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            { day: "d1", label: "Ngày 1 — Chào hỏi thân thiện", preview: "Xin chào [Tên]! 👋 Tôi là SGS AI từ SGS LAND. Hôm qua bạn hỏi về [dự án/khu vực]. Đây là 3 BĐS phù hợp nhất với bạn..." },
            { day: "d3", label: "Ngày 3 — Thông tin thị trường", preview: "Chào [Tên]! 📊 Tin mới thị trường BĐS tuần này: Long Thành +22%, Aqua City mở bán block mới, lãi suất vay từ 6.9%..." },
            { day: "d5", label: "Ngày 5 — Tạo urgency", preview: "Xin chào [Tên]! 🏠 Chúng tôi có 12 BĐS mới phù hợp ngân sách bạn. Một số căn đang có ưu đãi hết hạn cuối tháng..." },
            { day: "d7", label: "Ngày 7 — Tin nhắn cuối", preview: "Chào [Tên], Đây là tin nhắn cuối để không làm phiền bạn. SGS LAND luôn sẵn sàng hỗ trợ 24/7. Reply STOP để hủy..." },
          ].map((t) => (
            <div
              key={t.day}
              className="rounded-xl p-4"
              style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)" }}
            >
              <div className="flex items-center gap-2 mb-2">
                <span
                  className="w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center text-white"
                  style={{ background: "var(--primary-600)" }}
                >
                  {t.day.replace("d", "")}
                </span>
                <p className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>{t.label}</p>
              </div>
              <p className="text-xs leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                {t.preview}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
