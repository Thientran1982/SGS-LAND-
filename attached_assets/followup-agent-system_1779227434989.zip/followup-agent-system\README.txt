﻿# Follow-Up Agent System — SGS LAND
## Tự động nhắn lại khách D+1, D+3, D+5, D+7

### Kênh hỗ trợ: Zalo OA | SMS (SpeedSMS) | Email | Chat

---

## CẤU TRÚC FILE

### sgsland-nextjs/ (Next.js frontend)
app/api/followup/schedule/route.ts   — POST: lên lịch sequence
app/api/followup/send/route.ts       — POST: multi-channel dispatcher
app/api/followup/cancel/route.ts     — POST: hủy sequence
app/api/cron/followup/route.ts       — GET: cron job mỗi giờ
app/(private)/sequences/page.tsx     — UI dashboard quản lý
components/public/AiChatWidget.tsx   — Widget (auto-schedule sau lead capture)
lib/api.ts                           — followupApi methods
types/index.ts                       — FollowUp* TypeScript types
vercel.json                          — Cron config cho Vercel
ecosystem.config.js                  — PM2 config (Ubuntu)
scripts/cron-followup.sh             — Shell script cron job

### sgsland-mcp/ (MCP Server)
src/tools/followup.ts                — 5 MCP tools (Agent 9)
src/index.ts                         — Đăng ký tools (9 Agents | 32 Tools)

---

## SETUP

### 1. Thêm biến môi trường (.env.local)
CRON_SECRET=your-random-secret-here
ZALO_OA_ACCESS_TOKEN=your-zalo-oa-token
SMS_API_KEY=your-speedsms-key

### 2. Vercel (tự động)
vercel.json đã config cron chạy mỗi giờ: "0 * * * *"

### 3. Ubuntu/PM2
pm2 start ecosystem.config.js --env production
# Hoặc thêm crontab thủ công:
crontab -e
0 * * * * /var/www/sgsland-nextjs/scripts/cron-followup.sh

---

## FLOW HOẠT ĐỘNG

1. Khách chat → để lại SĐT qua Lead Capture form
2. AiChatWidget.tsx gọi POST /api/followup/schedule
3. Backend lưu D+1, D+3, D+5, D+7 vào queue
4. Mỗi giờ: GET /api/cron/followup → tìm items đến hạn
5. Gọi POST /api/followup/send → dispatch Zalo/SMS/Email
6. Khách chuyển đổi → POST /api/followup/cancel (reason: converted)

---

## TEMPLATES
D+1: Chào hỏi + 3 BĐS phù hợp
D+3: Tin thị trường Long Thành, Aqua City
D+5: BĐS mới + urgency cuối tháng
D+7: Tin cuối + Reply STOP để hủy

Commit: 500981d (nextjs) | 98c8a1d (mcp)
