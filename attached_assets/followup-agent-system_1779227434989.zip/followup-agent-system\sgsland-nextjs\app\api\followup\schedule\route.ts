// POST /api/followup/schedule
// Proxy → backend + local queue logic
import { NextRequest, NextResponse } from "next/server";

const BACKEND = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as Record<string, unknown>;

    // Forward to backend
    const res = await fetch(`${BACKEND}/api/followup/schedule`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8000),
    });

    if (!res.ok) {
      // Backend down — return optimistic success so widget doesn't block
      const sequence_id = `seq_${Date.now().toString(36)}`;
      return NextResponse.json({
        success: true,
        offline: true,
        sequence_id,
        message: "Đã ghi nhận follow-up (offline mode). Sẽ xử lý khi backend khả dụng.",
      });
    }

    const data = await res.json();
    return NextResponse.json({ success: true, ...data });
  } catch {
    return NextResponse.json(
      { success: false, error: "Schedule failed" },
      { status: 500 }
    );
  }
}
