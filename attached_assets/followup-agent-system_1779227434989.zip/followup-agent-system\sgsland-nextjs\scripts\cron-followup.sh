#!/bin/bash
# ============================================================
# Follow-Up Cron Script — chạy mỗi giờ qua PM2
# Cấu hình: pm2 start ecosystem.config.js --env production
# Hoặc thêm vào crontab: 0 * * * * /var/www/sgsland-nextjs/scripts/cron-followup.sh
# ============================================================

SITE_URL="${SITE_URL:-https://sgsland.vn}"
CRON_SECRET="${CRON_SECRET:-}"
LOG_FILE="/var/log/pm2/sgsland-followup-cron.log"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] ▶ Running follow-up cron..." >> "$LOG_FILE"

RESPONSE=$(curl -s -w "\n%{http_code}" \
  -H "Authorization: Bearer $CRON_SECRET" \
  -H "x-internal: $CRON_SECRET" \
  "${SITE_URL}/api/cron/followup")

HTTP_CODE=$(echo "$RESPONSE" | tail -1)
BODY=$(echo "$RESPONSE" | head -1)

if [ "$HTTP_CODE" -eq 200 ]; then
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✅ Cron OK: $BODY" >> "$LOG_FILE"
else
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ Cron FAILED (HTTP $HTTP_CODE): $BODY" >> "$LOG_FILE"
fi
