#!/usr/bin/env node
// ============================================================
// SGS LAND MCP Server — Entry Point
// 6 AI Agents | 16 Tools | Real Estate Platform Vietnam
// https://sgsland.vn | Version 1.0.0
// ============================================================
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { listingTools } from "./tools/listings.js";
import { valuationTools } from "./tools/valuation.js";
import { legalTools } from "./tools/legal.js";
import { marketTools } from "./tools/market.js";
import { projectTools } from "./tools/projects.js";
import { crmTools } from "./tools/crm.js";
import { livechatTools } from "./tools/livechat.js";
import { dynamicTools } from "./tools/dynamic.js";
import { followupTools } from "./tools/followup.js";

// ─── Create MCP Server ────────────────────────────────────
const server = new McpServer({
  name: "sgsland-mcp",
  version: "1.0.0",
});

// ─── Register All Tools ───────────────────────────────────

// 🏠 AGENT 1: Marketplace Listing Agent (4 tools)
server.tool(
  "search_listings",
  "Tìm kiếm BĐS trên SGS LAND marketplace. Lọc theo khu vực, loại, giá, phòng ngủ, pháp lý.",
  listingTools.search_listings.schema.shape,
  listingTools.search_listings.handler
);
server.tool(
  "get_listing_detail",
  "Lấy chi tiết đầy đủ một BĐS theo mã code (VD: LST887539).",
  listingTools.get_listing_detail.schema.shape,
  listingTools.get_listing_detail.handler
);
server.tool(
  "check_duplicate",
  "Phát hiện listing trùng lặp theo vị trí, diện tích, phòng ngủ.",
  listingTools.check_duplicate.schema.shape,
  listingTools.check_duplicate.handler
);
server.tool(
  "get_market_stats",
  "Thống kê tổng quan: số lượng BĐS theo loại, trạng thái, khu vực.",
  listingTools.get_market_stats.schema.shape,
  listingTools.get_market_stats.handler
);

// 💰 AGENT 2: AVM Valuation Agent (3 tools)
server.tool(
  "get_valuation",
  "Định giá BĐS bằng AI SGS-AVM v2.1 (9 hệ số, MAPE ±4.8%, chuẩn TĐGVN/IVS).",
  valuationTools.get_valuation.schema.shape,
  valuationTools.get_valuation.handler
);
server.tool(
  "get_valuation_methodology",
  "Giải thích phương pháp định giá AI: 9 hệ số, trọng số, income approach.",
  valuationTools.get_valuation_methodology.schema.shape,
  valuationTools.get_valuation_methodology.handler
);
server.tool(
  "compare_price_vs_market",
  "So sánh giá BĐS với chỉ số thị trường khu vực. Đánh giá over/under-priced.",
  valuationTools.compare_price_vs_market.schema.shape,
  valuationTools.compare_price_vs_market.handler
);

// ⚖️ AGENT 3: Legal Compliance Bot (3 tools)
server.tool(
  "check_legal_status",
  "Kiểm tra pháp lý 2 lớp (AI + chuyên viên). Luật Đất Đai 2024, KDBĐS 2023.",
  legalTools.check_legal_status.schema.shape,
  legalTools.check_legal_status.handler
);
server.tool(
  "check_planning",
  "Tra cứu quy hoạch BĐS theo GeoJSON Sở TN&MT. Cảnh báo quy hoạch vướng.",
  legalTools.check_planning.schema.shape,
  legalTools.check_planning.handler
);
server.tool(
  "legal_qa",
  "Hỏi đáp pháp lý BĐS: sang tên, thuế phí, sổ hồng/đỏ, thế chấp, Luật 2024.",
  legalTools.legal_qa.schema.shape,
  legalTools.legal_qa.handler
);

// 📊 AGENT 4: Market Intelligence Agent (3 tools)
server.tool(
  "get_price_index",
  "Chỉ số giá BĐS Đông Nam Bộ: TP.HCM, Đồng Nai, Bình Dương. Cập nhật tuần.",
  marketTools.get_price_index.schema.shape,
  marketTools.get_price_index.handler
);
server.tool(
  "get_longthanh_market",
  "Phân tích chuyên sâu thị trường Long Thành — hành lang sân bay. 9 quý data.",
  marketTools.get_longthanh_market.schema.shape,
  marketTools.get_longthanh_market.handler
);
server.tool(
  "analyze_investment",
  "Phân tích ROI, rental yield, dòng tiền đầu tư BĐS 5-10 năm.",
  marketTools.analyze_investment.schema.shape,
  marketTools.analyze_investment.handler
);

// 🏙️ AGENT 5: Project Analyzer Agent (3 tools)
server.tool(
  "get_project_info",
  "Chi tiết dự án BĐS: Aqua City, Vinhomes, Masterise, Novaland và 8 dự án khác.",
  projectTools.get_project_info.schema.shape,
  projectTools.get_project_info.handler
);
server.tool(
  "compare_projects",
  "So sánh side-by-side 2-4 dự án BĐS theo 12 tiêu chí đầu tư.",
  projectTools.compare_projects.schema.shape,
  projectTools.compare_projects.handler
);
server.tool(
  "search_projects",
  "Tìm dự án theo tiêu chí: khu vực, chủ đầu tư, loại sản phẩm, ngân sách, pháp lý.",
  projectTools.search_projects.schema.shape,
  projectTools.search_projects.handler
);

// 👥 AGENT 6: CRM B2B Agent (3 tools)
server.tool(
  "score_lead",
  "Chấm điểm lead BĐS (Explainable AI, 6 yếu tố, 100 điểm). Hạng A/B/C/D.",
  crmTools.score_lead.schema.shape,
  crmTools.score_lead.handler
);
server.tool(
  "route_lead",
  "Phân công lead cho broker phù hợp theo zone, ngân sách, tier, round-robin.",
  crmTools.route_lead.schema.shape,
  crmTools.route_lead.handler
);
server.tool(
  "get_broker_stats",
  "Thống kê hiệu suất broker: rating, conversion, doanh số, churn risk.",
  crmTools.get_broker_stats.schema.shape,
  crmTools.get_broker_stats.handler
);

// 💬 AGENT 7: Live Chat Agent Engine (3 tools)
server.tool(
  "handle_live_chat",
  "Xử lý tin nhắn live chat với context-awareness, intent classifier, knowledge base grounding. Trả lời đúng dựa trên dữ liệu thực SGS LAND.",
  livechatTools.handle_live_chat.schema.shape,
  livechatTools.handle_live_chat.handler
);
server.tool(
  "analyze_chat_session",
  "Phân tích toàn bộ phiên chat: intent history, context tích lũy, gợi ý next action cho broker.",
  livechatTools.analyze_chat_session.schema.shape,
  livechatTools.analyze_chat_session.handler
);
server.tool(
  "get_platform_knowledge",
  "Tra cứu knowledge base SGS LAND: khu vực giá, dự án, ngân hàng, FAQ pháp lý, thống kê nền tảng.",
  livechatTools.get_platform_knowledge.schema.shape,
  livechatTools.get_platform_knowledge.handler
);
server.tool(
  "get_project_listings",
  "Lấy danh sách căn hộ theo dự án (Cosmo=mcc, Aqua City=aqua-city...). Lọc theo PN, giá, tháp. Masteri Cosmo Central có 20 căn thực tế.",
  livechatTools.get_project_listings.schema.shape,
  livechatTools.get_project_listings.handler
);

// 💬 AGENT 7 — Cơ chế 1: Lead Capture (tự động thu thập thông tin khách)
server.tool(
  "capture_lead",
  "Thu thập thông tin lead từ chat: tên, SĐT, email, ngân sách, khu vực, dự án quan tâm. Tự động tính lead score và lưu vào CRM. Kích hoạt khi khách cung cấp thông tin liên hệ.",
  livechatTools.capture_lead.schema.shape,
  livechatTools.capture_lead.handler
);

// 💬 AGENT 7 — Cơ chế 2: Smart Escalation (chuyển sang người)
server.tool(
  "escalate_to_human",
  "Chuyển cuộc chat sang tư vấn viên người thật. Kích hoạt khi: AI confidence thấp, khách yêu cầu gặp người, câu hỏi pháp lý/đàm phán phức tạp, lead có ngân sách >10 tỷ, hoặc khách tỏ ra bực bội.",
  livechatTools.escalate_to_human.schema.shape,
  livechatTools.escalate_to_human.handler
);

// 💬 AGENT 7 — Cơ chế 3: Proactive Property Suggestions (gợi ý chủ động)
server.tool(
  "suggest_properties",
  "Gợi ý BĐS phù hợp dựa trên context chat: khu vực, loại BĐS, ngân sách, số phòng ngủ, mục đích (ở/đầu tư/cho thuê). Fetch real-time từ marketplace và trả về property cards có link.",
  livechatTools.suggest_properties.schema.shape,
  livechatTools.suggest_properties.handler
);

// 💬 AGENT 7 — Tool 4: Book Viewing Appointment (đặt lịch xem nhà)
server.tool(
  "book_viewing_appointment",
  "Đặt lịch xem nhà/dự án cho khách. Tạo appointment ID, lưu vào CRM, gửi xác nhận qua chat. Hỗ trợ parse ngày tự nhiên (ngày mai, cuối tuần, thứ 6...).",
  livechatTools.book_viewing_appointment.schema.shape,
  livechatTools.book_viewing_appointment.handler
);

// 🔄 AGENT 8: Dynamic Data Sync (4 tools)
server.tool(
  "refresh_knowledge_base",
  "Sync dữ liệu mới nhất từ platform về KB agents. Dùng khi có dự án/sản phẩm mới. Force=true để xóa cache hoàn toàn.",
  dynamicTools.refresh_knowledge_base.schema.shape,
  dynamicTools.refresh_knowledge_base.handler
);
server.tool(
  "search_listings_dynamic",
  "Tìm kiếm BĐS real-time cross cả marketplace + mini-site projects. Luôn có dữ liệu mới nhất.",
  dynamicTools.search_listings_dynamic.schema.shape,
  dynamicTools.search_listings_dynamic.handler
);
server.tool(
  "get_cache_status",
  "Kiểm tra trạng thái cache KB: số BĐS, TTL còn lại, dự án đang theo dõi, last refresh time.",
  dynamicTools.get_cache_status.schema.shape,
  dynamicTools.get_cache_status.handler
);
server.tool(
  "get_project_dynamic",
  "Lấy thông tin + danh sách căn của bất kỳ dự án mini-site nào theo code. Tự động fetch nếu chưa cache.",
  dynamicTools.get_project_dynamic.schema.shape,
  dynamicTools.get_project_dynamic.handler
);

// 🔔 AGENT 9: Follow-Up Sequence Agent (5 tools)
server.tool(
  "schedule_followup",
  "Lên lịch tự động nhắn lại khách D+1, D+3, D+5, D+7 qua Zalo OA / SMS / Email sau khi capture lead từ chat. Chọn kênh tốt nhất theo thông tin có.",
  followupTools.schedule_followup.schema.shape,
  followupTools.schedule_followup.handler
);
server.tool(
  "send_followup_message",
  "Gửi ngay một follow-up message cụ thể (D1/D3/D5/D7) qua kênh chỉ định. Dùng trong cron job hoặc khi broker muốn gửi thủ công.",
  followupTools.send_followup_message.schema.shape,
  followupTools.send_followup_message.handler
);
server.tool(
  "get_followup_schedule",
  "Xem lịch follow-up đang pending/đã gửi/lỗi của một lead hoặc session. Dùng để kiểm tra trạng thái sequence.",
  followupTools.get_followup_schedule.schema.shape,
  followupTools.get_followup_schedule.handler
);
server.tool(
  "cancel_followup",
  "Hủy toàn bộ hoặc một phần follow-up sequence. Kích hoạt khi: khách đã chuyển đổi, yêu cầu unsubscribe (STOP), hoặc broker hủy thủ công.",
  followupTools.cancel_followup.schema.shape,
  followupTools.cancel_followup.handler
);
server.tool(
  "get_followup_stats",
  "Thống kê hiệu quả follow-up: tỷ lệ mở, reply, chuyển đổi. Phân tích theo ngày D1/D3/D5/D7 và kênh Zalo/SMS/Email.",
  followupTools.get_followup_stats.schema.shape,
  followupTools.get_followup_stats.handler
);

// ─── Start Server ─────────────────────────────────────────
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("✅ SGS LAND MCP Server started — 9 Agents | 32 Tools");
  console.error("📡 Platform: https://sgsland.vn");
  console.error("🤖 Agents: AVM | Listing | Legal | Market | Project | CRM | LiveChat");
}

main().catch((err) => {
  console.error("❌ SGS LAND MCP Server error:", err);
  process.exit(1);
});
