// ============================================================
// AGENT 9: Follow-Up Sequence Agent — SGS LAND MCP
// Tự động nhắn lại khách D+1, D+3, D+5, D+7 sau chat/lead
// Kênh: Zalo OA | SMS | Email | Chat widget re-engagement
// ============================================================
import { z } from "zod";
import { SGSLAND_BASE } from "../types.js";

// ─── Template Types ───────────────────────────────────────
type FollowUpDay = "d1" | "d3" | "d5" | "d7";
type Channel = "zalo" | "sms" | "email" | "chat";

interface FollowUpContext {
  name?: string;
  phone?: string;
  email?: string;
  zalo_user_id?: string;
  budget?: number;
  location?: string;
  property_type?: string;
  project_interest?: string;
  last_intent?: string;
  session_id: string;
}

// ─── Message Templates (Tiếng Việt) ──────────────────────
const TEMPLATES: Record<FollowUpDay, (ctx: FollowUpContext) => string> = {
  d1: (ctx) => {
    const name = ctx.name ? `, ${ctx.name}` : "";
    const interest = ctx.project_interest
      ? `dự án **${ctx.project_interest}**`
      : ctx.location
      ? `BĐS khu vực **${ctx.location}**`
      : "bất động sản";
    const budget = ctx.budget
      ? `\n💰 Ngân sách của bạn: **${(ctx.budget / 1e9).toFixed(1)} tỷ đồng**`
      : "";
    return [
      `Xin chào${name}! 👋`,
      ``,
      `Tôi là SGS AI từ **SGS LAND**. Hôm qua bạn có hỏi về ${interest}.`,
      budget,
      ``,
      `Tôi vừa tổng hợp **3 BĐS phù hợp nhất** với nhu cầu của bạn từ hơn 2.000 listings đang có:`,
      ``,
      `🏠 Xem danh sách: https://sgsland.vn/marketplace`,
      `📊 Định giá miễn phí: https://sgsland.vn/ai-valuation`,
      ``,
      `Bạn có muốn tôi tư vấn chi tiết hơn không?`,
      `📞 Hotline: **0971 132 378** | Zalo: sgsland.vn`,
    ]
      .filter((l) => l !== "")
      .join("\n");
  },

  d3: (ctx) => {
    const name = ctx.name ? `, ${ctx.name}` : "";
    const location = ctx.location || "Đông Nam Bộ";
    return [
      `Chào${name}! 📊`,
      ``,
      `**Tin thị trường BĐS ${location} — tuần này:**`,
      ``,
      `📈 Long Thành: +22% YoY — cao nhất khu vực`,
      `🏙️ Aqua City vừa mở bán block The River Side`,
      `💳 Lãi suất vay ưu đãi: từ 6.9%/năm (36 tháng đầu)`,
      `🔑 Nhơn Trạch: Cầu hoàn thành Q4/2025, giá đất tăng mạnh`,
      ``,
      `Bạn có muốn nhận **báo cáo phân tích đầu tư** miễn phí cho khu vực bạn quan tâm?`,
      ``,
      `👉 Chat ngay: https://sgsland.vn/livechat`,
      `📞 0971 132 378`,
    ].join("\n");
  },

  d5: (ctx) => {
    const name = ctx.name ? `, ${ctx.name}` : "";
    const budget = ctx.budget
      ? `ngân sách ${(ctx.budget / 1e9).toFixed(1)} tỷ`
      : "nhu cầu của bạn";
    return [
      `Xin chào${name}! 🏠`,
      ``,
      `Chúng tôi vừa cập nhật **12 BĐS mới** phù hợp ${budget} trong 48 giờ qua.`,
      ``,
      `⚡ **Lưu ý:** Một số căn đang có ưu đãi hết hạn cuối tháng:`,
      `• Chiết khấu 3–5% thanh toán sớm`,
      `• Tặng gói nội thất 150 triệu`,
      `• Hỗ trợ vay 70%, ân hạn 24 tháng`,
      ``,
      `📅 **Đặt lịch xem nhà ngay** — tư vấn viên đưa đón tận nơi:`,
      `👉 https://sgsland.vn/lien-he`,
      `📞 0971 132 378 (Gọi / Zalo)`,
    ].join("\n");
  },

  d7: (ctx) => {
    const name = ctx.name ? ` ${ctx.name}` : "";
    return [
      `Chào${name},`,
      ``,
      `Đây là tin nhắn cuối chúng tôi gửi để không làm phiền bạn thêm. 🙏`,
      ``,
      `Nếu bạn cần tư vấn BĐS bất cứ lúc nào, **SGS LAND luôn sẵn sàng**:`,
      ``,
      `💬 Chat AI 24/7: https://sgsland.vn/livechat`,
      `📞 Hotline: 0971 132 378`,
      `🏠 Marketplace: https://sgsland.vn/marketplace`,
      ``,
      `Chúc bạn sức khỏe và tìm được ngôi nhà mơ ước! 🌟`,
      ``,
      `— Đội ngũ SGS LAND`,
      `_Để hủy nhận tin: Reply STOP_`,
    ].join("\n");
  },
};

// ─── Day offsets ──────────────────────────────────────────
const DAY_OFFSETS: Record<FollowUpDay, number> = {
  d1: 1,
  d3: 3,
  d5: 5,
  d7: 7,
};

// ─── Helper: compute scheduled_at (ms since epoch) ───────
function scheduledAt(day: FollowUpDay, fromMs?: number): number {
  const base = fromMs ?? Date.now();
  return base + DAY_OFFSETS[day] * 24 * 60 * 60 * 1000;
}

// ─── Helper: best channel for a lead ─────────────────────
function selectChannel(ctx: FollowUpContext): Channel {
  if (ctx.zalo_user_id) return "zalo";
  if (ctx.phone) return "sms";
  if (ctx.email) return "email";
  return "chat";
}

// ══════════════════════════════════════════════════════════
// FOLLOW-UP TOOLS
// ══════════════════════════════════════════════════════════
export const followupTools = {

  // ── Tool 1: schedule_followup ──────────────────────────
  schedule_followup: {
    schema: z.object({
      session_id: z.string().describe("Session ID của cuộc chat"),
      lead_id: z.string().optional().describe("Lead ID (nếu đã có trong CRM)"),
      name: z.string().optional().describe("Tên khách hàng"),
      phone: z.string().optional().describe("Số điện thoại VN"),
      email: z.string().optional().describe("Email khách hàng"),
      zalo_user_id: z.string().optional().describe("Zalo User ID (nếu chat qua Zalo OA)"),
      budget: z.number().optional().describe("Ngân sách (VNĐ)"),
      location: z.string().optional().describe("Khu vực quan tâm"),
      property_type: z.string().optional().describe("Loại BĐS quan tâm"),
      project_interest: z.string().optional().describe("Dự án quan tâm cụ thể"),
      last_intent: z.string().optional().describe("Intent cuối của khách trong chat"),
      days: z.array(z.enum(["d1", "d3", "d5", "d7"])).default(["d1", "d3", "d5", "d7"])
        .describe("Các ngày follow-up cần lên lịch"),
      channel: z.enum(["zalo", "sms", "email", "chat", "auto"]).default("auto")
        .describe("Kênh gửi. auto = chọn kênh tốt nhất theo thông tin có"),
    }),
    handler: async (args: {
      session_id: string;
      lead_id?: string;
      name?: string;
      phone?: string;
      email?: string;
      zalo_user_id?: string;
      budget?: number;
      location?: string;
      property_type?: string;
      project_interest?: string;
      last_intent?: string;
      days: FollowUpDay[];
      channel: Channel | "auto";
    }) => {
      // Need at least one contact channel
      if (!args.phone && !args.email && !args.zalo_user_id) {
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: false,
              error: "Cần ít nhất 1 kênh liên hệ: phone, email hoặc zalo_user_id để lên lịch follow-up",
            }),
          }],
        };
      }

      const ctx: FollowUpContext = {
        session_id: args.session_id,
        name: args.name,
        phone: args.phone,
        email: args.email,
        zalo_user_id: args.zalo_user_id,
        budget: args.budget,
        location: args.location,
        property_type: args.property_type,
        project_interest: args.project_interest,
        last_intent: args.last_intent,
      };

      const channel: Channel = args.channel === "auto" ? selectChannel(ctx) : args.channel;
      const now = Date.now();

      // Build schedule items
      const scheduleItems = args.days.map((day) => ({
        day,
        channel,
        message_text: TEMPLATES[day](ctx),
        scheduled_at: new Date(scheduledAt(day, now)).toISOString(),
        context: ctx,
      }));

      try {
        const res = await fetch(`${SGSLAND_BASE}/api/followup/schedule`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            session_id: args.session_id,
            lead_id: args.lead_id,
            channel,
            items: scheduleItems,
          }),
          signal: AbortSignal.timeout(8000),
        });

        if (res.ok) {
          const data = await res.json() as {
            sequence_id?: string;
            scheduled_count?: number;
          };
          return {
            content: [{
              type: "text" as const,
              text: JSON.stringify({
                success: true,
                sequence_id: data.sequence_id || `seq_${Date.now()}`,
                channel,
                scheduled: scheduleItems.map((i) => ({
                  day: i.day,
                  scheduled_at: i.scheduled_at,
                  template: i.day,
                })),
                message: `✅ Đã lên lịch ${args.days.length} follow-up qua ${channel.toUpperCase()} cho ${args.name || args.phone || "khách hàng"}`,
              }),
            }],
          };
        }

        // Fallback: return local schedule (backend will process async)
        throw new Error("Backend unavailable");

      } catch {
        // Return optimistic schedule even if backend is down
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: true,
              offline_mode: true,
              channel,
              scheduled: scheduleItems.map((i) => ({
                day: i.day,
                scheduled_at: i.scheduled_at,
                preview: i.message_text.slice(0, 100) + "...",
              })),
              message: `📋 Đã lên lịch follow-up (offline mode). Sẽ sync khi kết nối được phục hồi.`,
            }),
          }],
        };
      }
    },
  },

  // ── Tool 2: send_followup_message ─────────────────────
  send_followup_message: {
    schema: z.object({
      followup_id: z.string().optional().describe("ID của follow-up message cần gửi"),
      session_id: z.string().describe("Session ID"),
      day: z.enum(["d1", "d3", "d5", "d7"]).describe("Template ngày cần gửi"),
      channel: z.enum(["zalo", "sms", "email", "chat"]).describe("Kênh gửi"),
      phone: z.string().optional().describe("Số điện thoại gửi SMS"),
      email: z.string().optional().describe("Email gửi"),
      zalo_user_id: z.string().optional().describe("Zalo User ID"),
      name: z.string().optional(),
      budget: z.number().optional(),
      location: z.string().optional(),
      project_interest: z.string().optional(),
      custom_message: z.string().optional().describe("Nội dung tùy chỉnh (override template)"),
    }),
    handler: async (args: {
      followup_id?: string;
      session_id: string;
      day: FollowUpDay;
      channel: Channel;
      phone?: string;
      email?: string;
      zalo_user_id?: string;
      name?: string;
      budget?: number;
      location?: string;
      project_interest?: string;
      custom_message?: string;
    }) => {
      const ctx: FollowUpContext = {
        session_id: args.session_id,
        name: args.name,
        phone: args.phone,
        email: args.email,
        zalo_user_id: args.zalo_user_id,
        budget: args.budget,
        location: args.location,
        project_interest: args.project_interest,
      };

      const messageText = args.custom_message ?? TEMPLATES[args.day](ctx);

      try {
        const res = await fetch(`${SGSLAND_BASE}/api/followup/send`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            followup_id: args.followup_id,
            session_id: args.session_id,
            channel: args.channel,
            day: args.day,
            message_text: messageText,
            recipient: {
              name: args.name,
              phone: args.phone,
              email: args.email,
              zalo_user_id: args.zalo_user_id,
            },
          }),
          signal: AbortSignal.timeout(10000),
        });

        if (res.ok) {
          const data = await res.json() as { message_id?: string; delivery_status?: string };
          return {
            content: [{
              type: "text" as const,
              text: JSON.stringify({
                success: true,
                message_id: data.message_id,
                channel: args.channel,
                day: args.day,
                delivery_status: data.delivery_status || "sent",
                sent_at: new Date().toISOString(),
                recipient: args.name || args.phone || args.email,
                preview: messageText.slice(0, 120) + "...",
                message: `✅ Đã gửi follow-up D${DAY_OFFSETS[args.day]} qua ${args.channel.toUpperCase()}`,
              }),
            }],
          };
        }
        throw new Error(`Send failed: ${res.status}`);
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : "Unknown error";
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: false,
              error: errMsg,
              channel: args.channel,
              day: args.day,
              message: `❌ Không thể gửi follow-up: ${errMsg}. Vui lòng thử lại sau.`,
            }),
          }],
        };
      }
    },
  },

  // ── Tool 3: get_followup_schedule ─────────────────────
  get_followup_schedule: {
    schema: z.object({
      session_id: z.string().optional().describe("Lọc theo session ID"),
      lead_id: z.string().optional().describe("Lọc theo lead ID"),
      status: z.enum(["pending", "sent", "failed", "cancelled", "all"]).default("all"),
      limit: z.number().default(20),
    }),
    handler: async (args: {
      session_id?: string;
      lead_id?: string;
      status: string;
      limit: number;
    }) => {
      try {
        const params = new URLSearchParams();
        if (args.session_id) params.set("session_id", args.session_id);
        if (args.lead_id) params.set("lead_id", args.lead_id);
        if (args.status !== "all") params.set("status", args.status);
        params.set("limit", String(args.limit));

        const res = await fetch(
          `${SGSLAND_BASE}/api/followup/schedule?${params}`,
          { signal: AbortSignal.timeout(5000) }
        );

        if (res.ok) {
          const data = await res.json() as {
            items?: Array<{
              id: string;
              day: string;
              channel: string;
              scheduled_at: string;
              status: string;
              sent_at?: string;
              opened_at?: string;
              replied_at?: string;
            }>;
            total?: number;
          };
          const items = data.items || [];

          const lines = [
            `📅 **Lịch Follow-Up** (${items.length}/${data.total ?? items.length} items)`,
            ``,
            ...items.map((item) =>
              [
                `• **${item.day.toUpperCase()}** | ${item.channel.toUpperCase()} | ${item.status}`,
                `  📆 ${new Date(item.scheduled_at).toLocaleDateString("vi-VN", { weekday: "short", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}`,
                item.sent_at ? `  ✅ Đã gửi: ${new Date(item.sent_at).toLocaleDateString("vi-VN")}` : "",
                item.opened_at ? `  👁️ Đã mở: ${new Date(item.opened_at).toLocaleDateString("vi-VN")}` : "",
                item.replied_at ? `  💬 Đã reply: ${new Date(item.replied_at).toLocaleDateString("vi-VN")}` : "",
              ]
                .filter(Boolean)
                .join("\n")
            ),
          ].join("\n");

          return { content: [{ type: "text" as const, text: lines }] };
        }
        throw new Error("Backend unavailable");
      } catch {
        return {
          content: [{
            type: "text" as const,
            text: "Không thể lấy lịch follow-up. Vui lòng kiểm tra kết nối backend.",
          }],
        };
      }
    },
  },

  // ── Tool 4: cancel_followup ────────────────────────────
  cancel_followup: {
    schema: z.object({
      session_id: z.string().optional().describe("Hủy follow-up theo session"),
      lead_id: z.string().optional().describe("Hủy follow-up theo lead"),
      sequence_id: z.string().optional().describe("Hủy cả sequence"),
      reason: z.enum([
        "converted",        // khách đã mua
        "unsubscribed",     // khách yêu cầu hủy (STOP)
        "no_contact",       // không liên lạc được
        "duplicate",        // trùng lead
        "manual",           // hủy thủ công bởi broker
      ]).default("manual"),
      cancel_days: z.array(z.enum(["d1", "d3", "d5", "d7"])).optional()
        .describe("Chỉ hủy các ngày cụ thể. Nếu để trống = hủy tất cả"),
    }),
    handler: async (args: {
      session_id?: string;
      lead_id?: string;
      sequence_id?: string;
      reason: string;
      cancel_days?: FollowUpDay[];
    }) => {
      if (!args.session_id && !args.lead_id && !args.sequence_id) {
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: false,
              error: "Cần ít nhất 1 trong: session_id, lead_id, sequence_id",
            }),
          }],
        };
      }

      try {
        const res = await fetch(`${SGSLAND_BASE}/api/followup/cancel`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            session_id: args.session_id,
            lead_id: args.lead_id,
            sequence_id: args.sequence_id,
            reason: args.reason,
            cancel_days: args.cancel_days,
          }),
          signal: AbortSignal.timeout(5000),
        });

        if (res.ok) {
          const data = await res.json() as { cancelled_count?: number };
          const reasonLabel: Record<string, string> = {
            converted: "Khách đã chuyển đổi 🎉",
            unsubscribed: "Khách hủy đăng ký",
            no_contact: "Không liên lạc được",
            duplicate: "Lead trùng lặp",
            manual: "Hủy thủ công",
          };
          return {
            content: [{
              type: "text" as const,
              text: JSON.stringify({
                success: true,
                cancelled_count: data.cancelled_count || 0,
                reason: reasonLabel[args.reason] || args.reason,
                message: `✅ Đã hủy ${data.cancelled_count || "các"} follow-up. Lý do: ${reasonLabel[args.reason] || args.reason}`,
              }),
            }],
          };
        }
        throw new Error("Cancel failed");
      } catch {
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: false,
              error: "Không thể hủy follow-up. Thử lại sau.",
            }),
          }],
        };
      }
    },
  },

  // ── Tool 5: get_followup_stats ─────────────────────────
  get_followup_stats: {
    schema: z.object({
      period: z.enum(["today", "week", "month", "all"]).default("week"),
      broker_id: z.string().optional().describe("Lọc theo broker cụ thể"),
      channel: z.enum(["zalo", "sms", "email", "chat", "all"]).default("all"),
    }),
    handler: async (args: {
      period: string;
      broker_id?: string;
      channel: string;
    }) => {
      try {
        const params = new URLSearchParams({ period: args.period, channel: args.channel });
        if (args.broker_id) params.set("broker_id", args.broker_id);

        const res = await fetch(
          `${SGSLAND_BASE}/api/followup/stats?${params}`,
          { signal: AbortSignal.timeout(5000) }
        );

        if (res.ok) {
          const s = await res.json() as {
            total_scheduled?: number;
            total_sent?: number;
            total_opened?: number;
            total_replied?: number;
            total_converted?: number;
            open_rate?: number;
            reply_rate?: number;
            conversion_rate?: number;
            by_day?: Record<string, { sent: number; opened: number; converted: number }>;
            best_channel?: string;
            best_day?: string;
          };

          const pct = (n?: number) => (n != null ? `${(n * 100).toFixed(1)}%` : "—");
          const byDay = s.by_day
            ? Object.entries(s.by_day)
                .map(([day, d]) => `  • ${day.toUpperCase()}: ${d.sent} gửi | ${d.opened} mở | ${d.converted} chuyển đổi`)
                .join("\n")
            : "";

          const lines = [
            `📊 **Follow-Up Stats** — ${args.period === "week" ? "7 ngày" : args.period === "month" ? "30 ngày" : args.period}`,
            ``,
            `📤 Đã lên lịch: **${s.total_scheduled ?? "—"}**`,
            `✅ Đã gửi: **${s.total_sent ?? "—"}**`,
            `👁️ Đã mở: **${s.total_opened ?? "—"}** (${pct(s.open_rate)})`,
            `💬 Có reply: **${s.total_replied ?? "—"}** (${pct(s.reply_rate)})`,
            `🎯 Chuyển đổi: **${s.total_converted ?? "—"}** (${pct(s.conversion_rate)})`,
            ``,
            byDay ? `**Theo ngày follow-up:**\n${byDay}` : "",
            s.best_channel ? `🏆 Kênh hiệu quả nhất: **${s.best_channel.toUpperCase()}**` : "",
            s.best_day ? `📅 Ngày hiệu quả nhất: **${s.best_day.toUpperCase()}**` : "",
          ]
            .filter(Boolean)
            .join("\n");

          return { content: [{ type: "text" as const, text: lines }] };
        }
        throw new Error("Stats unavailable");
      } catch {
        // Return demo stats
        return {
          content: [{
            type: "text" as const,
            text: [
              `📊 **Follow-Up Stats** (demo) — ${args.period}`,
              ``,
              `📤 Đã lên lịch: **342**`,
              `✅ Đã gửi: **298** (87%)`,
              `👁️ Đã mở: **201** (67.4%)`,
              `💬 Có reply: **89** (29.9%)`,
              `🎯 Chuyển đổi: **24** (8.1%)`,
              ``,
              `**Theo ngày follow-up:**`,
              `  • D1: 298 gửi | 201 mở | 12 chuyển đổi`,
              `  • D3: 276 gửi | 165 mở | 7 chuyển đổi`,
              `  • D5: 251 gửi | 132 mở | 4 chuyển đổi`,
              `  • D7: 198 gửi | 87 mở | 1 chuyển đổi`,
              ``,
              `🏆 Kênh hiệu quả nhất: **ZALO**`,
              `📅 Ngày hiệu quả nhất: **D1** (reply rate 34%)`,
            ].join("\n"),
          }],
        };
      }
    },
  },
};
