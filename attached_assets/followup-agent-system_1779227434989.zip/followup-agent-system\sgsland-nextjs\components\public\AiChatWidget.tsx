"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  MessageCircle,
  X,
  Send,
  Bot,
  Minimize2,
  Phone,
  User,
  CheckCircle,
  AlertCircle,
  Calendar,
  Home,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────
interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  ts: number;
  type?: "lead_form" | "escalation" | "suggestion" | "booking";
}

interface LeadForm {
  name: string;
  phone: string;
  note: string;
}

// ─── Constants ────────────────────────────────────────────
const SESSION_KEY = "sgs_chat_session_id";
const HISTORY_KEY = "sgs_chat_history";

const QUICK_REPLIES = [
  "🏠 Tìm căn hộ 2 phòng ngủ",
  "💰 Vay ngân hàng mua nhà",
  "⚖️ Kiểm tra pháp lý sổ hồng",
  "📊 Thị trường Long Thành 2025",
  "🏙️ Dự án Aqua City Novaland",
];

const ACTION_BUTTONS = [
  { icon: Calendar, label: "Đặt lịch xem nhà", msg: "Tôi muốn đặt lịch xem nhà" },
  { icon: Phone, label: "Được gọi lại", msg: "Tôi muốn được tư vấn viên gọi lại" },
  { icon: Home, label: "Xem dự án nổi bật", msg: "Cho tôi xem các dự án BĐS nổi bật" },
];

const ESCALATION_KEYWORDS = [
  "nói chuyện người thật",
  "gặp tư vấn viên",
  "chuyển cho người",
  "không hiểu",
  "sai rồi",
  "tệ quá",
  "chán",
  "vô dụng",
  "không giúp được",
  "human",
  "manager",
  "quản lý",
  "khiếu nại",
  "phàn nàn",
];

const LEAD_INTENT_PHRASES = [
  "để lại số điện thoại",
  "để lại thông tin",
  "cung cấp số điện thoại",
  "cung cấp thông tin liên hệ",
  "tư vấn viên sẽ liên hệ",
  "chúng tôi sẽ gọi lại",
  "điền thông tin",
  "đăng ký tư vấn",
  "nhận tư vấn",
];

const WELCOME: Message = {
  id: "welcome",
  role: "assistant",
  content:
    "Xin chào! Tôi là **SGS AI** — trợ lý bất động sản thông minh của SGS LAND.\n\nTôi có thể giúp bạn:\n• 🏠 Tìm kiếm bất động sản phù hợp\n• 💰 Định giá & phân tích đầu tư\n• ⚖️ Tư vấn pháp lý, sổ hồng\n• 📊 Thị trường Đông Nam Bộ\n\nBạn đang quan tâm đến BĐS nào?",
  ts: Date.now(),
};

// ─── Helper: detect lead capture intent in AI reply ───────
function detectLeadIntent(text: string): boolean {
  const lower = text.toLowerCase();
  return LEAD_INTENT_PHRASES.some((phrase) => lower.includes(phrase));
}

// ─── Helper: detect escalation needed from user message ───
function detectEscalationNeeded(text: string): boolean {
  const lower = text.toLowerCase();
  return ESCALATION_KEYWORDS.some((kw) => lower.includes(kw));
}

// ─── Helper: simple markdown → HTML ──────────────────────
function renderContent(text: string): string {
  return text
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    .replace(/\n/g, "<br/>");
}

// ─── Typing dots animation ────────────────────────────────
function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-3 py-3">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="w-2 h-2 rounded-full inline-block"
          style={{
            background: "var(--text-tertiary)",
            animation: "sgs-bounce 1.2s infinite",
            animationDelay: `${i * 0.2}s`,
          }}
        />
      ))}
      <style>{`
        @keyframes sgs-bounce {
          0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
          40% { transform: translateY(-6px); opacity: 1; }
        }
      `}</style>
    </div>
  );
}

// ─── Lead Capture inline form ─────────────────────────────
interface LeadFormCardProps {
  onSubmit: (form: LeadForm) => void;
  onDismiss: () => void;
  submitted: boolean;
}

function LeadFormCard({ onSubmit, onDismiss, submitted }: LeadFormCardProps) {
  const [form, setForm] = useState<LeadForm>({ name: "", phone: "", note: "" });
  const [err, setErr] = useState("");

  const handleSubmit = () => {
    if (!form.phone.match(/^(0|\+84)[0-9]{8,9}$/)) {
      setErr("Vui lòng nhập số điện thoại hợp lệ (VD: 0971132378)");
      return;
    }
    setErr("");
    onSubmit(form);
  };

  if (submitted) {
    return (
      <div
        className="mx-2 my-1 p-3 rounded-xl flex items-center gap-2"
        style={{ background: "var(--success-subtle, #ecfdf5)", border: "1px solid #10b981" }}
      >
        <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
        <p className="text-sm" style={{ color: "var(--text-primary)" }}>
          Cảm ơn! Tư vấn viên sẽ liên hệ bạn trong <strong>15 phút</strong>.
        </p>
      </div>
    );
  }

  return (
    <div
      className="mx-2 my-1 p-3 rounded-xl space-y-2"
      style={{ background: "var(--bg-elevated)", border: "1px solid var(--primary-200, #bfdbfe)" }}
    >
      <p className="text-xs font-semibold" style={{ color: "var(--primary-600)" }}>
        📋 Để lại thông tin — nhận tư vấn trong 15 phút
      </p>
      <input
        className="w-full text-sm px-2.5 py-1.5 rounded-lg outline-none"
        style={{ background: "var(--bg-surface)", border: "1px solid var(--border-default)", color: "var(--text-primary)" }}
        placeholder="Họ tên (tùy chọn)"
        value={form.name}
        onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
      />
      <input
        className="w-full text-sm px-2.5 py-1.5 rounded-lg outline-none"
        style={{ background: "var(--bg-surface)", border: `1px solid ${err ? "#ef4444" : "var(--border-default)"}`, color: "var(--text-primary)" }}
        placeholder="Số điện thoại *"
        value={form.phone}
        onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
      />
      {err && <p className="text-xs text-red-500">{err}</p>}
      <input
        className="w-full text-sm px-2.5 py-1.5 rounded-lg outline-none"
        style={{ background: "var(--bg-surface)", border: "1px solid var(--border-default)", color: "var(--text-primary)" }}
        placeholder="Ghi chú (ngân sách, khu vực...)"
        value={form.note}
        onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))}
      />
      <div className="flex gap-2">
        <button
          onClick={handleSubmit}
          className="flex-1 py-1.5 rounded-lg text-sm font-medium text-white transition-opacity hover:opacity-90"
          style={{ background: "var(--primary-600)" }}
        >
          Gửi thông tin
        </button>
        <button
          onClick={onDismiss}
          className="px-3 py-1.5 rounded-lg text-sm transition-colors"
          style={{ color: "var(--text-secondary)", border: "1px solid var(--border-default)" }}
        >
          Bỏ qua
        </button>
      </div>
    </div>
  );
}

// ─── Main Widget ──────────────────────────────────────────
export function AiChatWidget() {
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [unread, setUnread] = useState(0);

  // Cơ chế 1: Lead Capture
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadSubmitted, setLeadSubmitted] = useState(false);

  // Cơ chế 2: Smart Escalation
  const [escalated, setEscalated] = useState(false);

  // Cơ chế 3: Proactive
  const [showQuickReplies, setShowQuickReplies] = useState(true);

  // Session
  const sessionIdRef = useRef<string>("");

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // ── Init session & restore history ────────────────────
  useEffect(() => {
    try {
      let sid = sessionStorage.getItem(SESSION_KEY);
      if (!sid) {
        sid = `sess_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        sessionStorage.setItem(SESSION_KEY, sid);
      }
      sessionIdRef.current = sid;

      const saved = sessionStorage.getItem(HISTORY_KEY);
      if (saved) {
        const parsed: Message[] = JSON.parse(saved);
        if (parsed.length > 0) {
          setMessages([WELCOME, ...parsed]);
          setShowQuickReplies(false);
        }
      }
    } catch {
      // sessionStorage not available (SSR guard)
    }
  }, []);

  // ── Persist history ────────────────────────────────────
  useEffect(() => {
    try {
      const toSave = messages.filter((m) => m.id !== "welcome").slice(-30);
      if (toSave.length > 0) {
        sessionStorage.setItem(HISTORY_KEY, JSON.stringify(toSave));
      }
    } catch {
      // ignore
    }
  }, [messages]);

  // ── Auto-scroll ────────────────────────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, showLeadForm, escalated, loading]);

  // ── Focus input when opened ────────────────────────────
  useEffect(() => {
    if (open && !minimized) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open, minimized]);

  const handleOpen = () => {
    setOpen(true);
    setMinimized(false);
    setUnread(0);
  };

  // ── Lead submit handler ────────────────────────────────
  const handleLeadSubmit = useCallback(async (form: LeadForm) => {
    setLeadSubmitted(true);
    setShowLeadForm(false);

    // Push capture_lead to CRM + schedule follow-up sequence
    try {
      await Promise.allSettled([
        // 1. Capture lead in CRM
        fetch("/api/ai/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: `[SYSTEM:capture_lead] name="${form.name}" phone="${form.phone}" note="${form.note}" session="${sessionIdRef.current}"`,
            history: [],
            intent: "capture_lead",
          }),
        }),
        // 2. Auto-schedule D+1, D+3, D+5, D+7 follow-up
        fetch("/api/followup/schedule", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            session_id: sessionIdRef.current,
            name: form.name || undefined,
            phone: form.phone || undefined,
            notes: form.note || undefined,
            channel: "auto",
            days: ["d1", "d3", "d5", "d7"],
          }),
        }),
      ]);
    } catch {
      // non-blocking, best-effort
    }

    // Confirmation message in chat
    setMessages((prev) => [
      ...prev,
      {
        id: `lead_confirm_${Date.now()}`,
        role: "assistant",
        content: `✅ Đã nhận thông tin của bạn${form.name ? `, **${form.name}**` : ""}! Tư vấn viên SGS LAND sẽ gọi lại số **${form.phone}** trong vòng 15 phút.\n\nBạn có muốn tiếp tục hỏi thêm gì không?`,
        ts: Date.now(),
      },
    ]);
  }, []);

  // ── Escalation handler ─────────────────────────────────
  const handleEscalation = useCallback(() => {
    setEscalated(true);
    setShowLeadForm(true);
    setMessages((prev) => [
      ...prev,
      {
        id: `escalation_${Date.now()}`,
        role: "assistant",
        content:
          "Tôi hiểu bạn muốn nói chuyện với tư vấn viên thật. Để lại số điện thoại — chúng tôi sẽ **kết nối ngay** cho bạn! ⚡",
        ts: Date.now(),
        type: "escalation",
      },
    ]);
  }, []);

  // ── Main send ──────────────────────────────────────────
  const handleSend = async (text?: string) => {
    const msgText = (text ?? input).trim();
    if (!msgText || loading) return;

    // Dismiss quick replies after first message
    setShowQuickReplies(false);

    // Cơ chế 2: check escalation BEFORE sending
    if (detectEscalationNeeded(msgText) && !escalated) {
      const userMsg: Message = {
        id: Date.now().toString(),
        role: "user",
        content: msgText,
        ts: Date.now(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      handleEscalation();
      return;
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: msgText,
      ts: Date.now(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: msgText,
          session_id: sessionIdRef.current,
          history: messages
            .filter((m) => m.role !== "system" && m.id !== "welcome")
            .slice(-10)
            .map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      if (!res.ok) throw new Error("API error");
      const data = await res.json();

      const reply: string =
        data.reply || "Xin lỗi, tôi chưa hiểu câu hỏi của bạn. Bạn có thể hỏi lại không?";

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: reply,
        ts: Date.now(),
      };
      setMessages((prev) => [...prev, aiMsg]);

      // Cơ chế 1: detect lead intent in reply
      if (detectLeadIntent(reply) && !leadSubmitted && !showLeadForm) {
        setShowLeadForm(true);
      }

      // Unread badge when minimized/closed
      if (minimized || !open) setUnread((n) => n + 1);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content:
            "Xin lỗi, có lỗi kết nối. Vui lòng thử lại hoặc gọi hotline **0971 132 378**.",
          ts: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // User messages count (for action buttons threshold)
  const userMsgCount = messages.filter((m) => m.role === "user").length;
  const showActionButtons = userMsgCount >= 3 && !escalated;

  return (
    <>
      {/* Chat panel */}
      {open && (
        <div
          className={`fixed bottom-24 right-4 sm:right-6 z-50 flex flex-col rounded-2xl shadow-2xl overflow-hidden transition-all duration-300 ${
            minimized ? "h-14" : "h-[560px]"
          }`}
          style={{
            width: "min(400px, calc(100vw - 32px))",
            background: "var(--bg-surface)",
            border: "1px solid var(--border-default)",
          }}
        >
          {/* ── Header ────────────────────────────────── */}
          <div
            className="flex items-center gap-3 px-4 py-3 shrink-0 cursor-pointer"
            style={{ background: "var(--primary-600)" }}
            onClick={() => setMinimized((v) => !v)}
          >
            {/* Avatar with online dot */}
            <div className="relative w-8 h-8">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 rounded-full border-2 border-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white leading-tight">SGS AI Assistant</p>
              <p className="text-xs text-white/70">Online · Phản hồi tức thì</p>
            </div>
            <div className="flex items-center gap-1">
              <a
                href="tel:0971132378"
                onClick={(e) => e.stopPropagation()}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
                title="Gọi hotline"
              >
                <Phone className="w-4 h-4" />
              </a>
              <button
                onClick={(e) => { e.stopPropagation(); setMinimized((v) => !v); }}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); setOpen(false); }}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ── Body ──────────────────────────────────── */}
          {!minimized && (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto thin-scrollbar p-4 space-y-3">
                {messages.map((msg) => {
                  if (msg.role === "system") return null;
                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                    >
                      {msg.role === "assistant" && (
                        <div
                          className="w-7 h-7 rounded-full shrink-0 flex items-center justify-center mt-0.5"
                          style={{ background: "var(--primary-subtle)" }}
                        >
                          <Bot className="w-3.5 h-3.5" style={{ color: "var(--primary-600)" }} />
                        </div>
                      )}
                      {msg.role === "user" && (
                        <div
                          className="w-7 h-7 rounded-full shrink-0 flex items-center justify-center mt-0.5"
                          style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)" }}
                        >
                          <User className="w-3.5 h-3.5" style={{ color: "var(--text-secondary)" }} />
                        </div>
                      )}
                      <div
                        className="max-w-[78%] px-3 py-2.5 rounded-2xl text-sm leading-relaxed"
                        style={
                          msg.role === "user"
                            ? {
                                background: "var(--primary-600)",
                                color: "#fff",
                                borderBottomRightRadius: "4px",
                              }
                            : {
                                background: msg.type === "escalation" ? "var(--warning-subtle, #fffbeb)" : "var(--bg-elevated)",
                                color: "var(--text-primary)",
                                borderBottomLeftRadius: "4px",
                                border: `1px solid ${msg.type === "escalation" ? "#f59e0b" : "var(--border-default)"}`,
                              }
                        }
                        dangerouslySetInnerHTML={{ __html: renderContent(msg.content) }}
                      />
                    </div>
                  );
                })}

                {/* Typing indicator */}
                {loading && (
                  <div className="flex gap-2">
                    <div
                      className="w-7 h-7 rounded-full shrink-0 flex items-center justify-center"
                      style={{ background: "var(--primary-subtle)" }}
                    >
                      <Bot className="w-3.5 h-3.5" style={{ color: "var(--primary-600)" }} />
                    </div>
                    <div
                      className="rounded-2xl"
                      style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)", borderBottomLeftRadius: "4px" }}
                    >
                      <TypingDots />
                    </div>
                  </div>
                )}

                {/* Cơ chế 1: Lead Capture form */}
                {showLeadForm && (
                  <LeadFormCard
                    onSubmit={handleLeadSubmit}
                    onDismiss={() => setShowLeadForm(false)}
                    submitted={leadSubmitted}
                  />
                )}

                {/* Escalation notice (if escalated + form already dismissed) */}
                {escalated && !showLeadForm && !leadSubmitted && (
                  <div
                    className="mx-2 p-3 rounded-xl flex items-start gap-2"
                    style={{ background: "var(--warning-subtle, #fffbeb)", border: "1px solid #f59e0b" }}
                  >
                    <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-amber-700">Kết nối tư vấn viên</p>
                      <p className="text-xs text-amber-600 mt-0.5">
                        Gọi ngay:{" "}
                        <a href="tel:0971132378" className="font-bold underline">
                          0971 132 378
                        </a>
                      </p>
                    </div>
                  </div>
                )}

                {/* Cơ chế 3: Quick replies (on first open) */}
                {showQuickReplies && messages.length === 1 && (
                  <div className="space-y-1.5">
                    <p className="text-xs px-1" style={{ color: "var(--text-muted)" }}>
                      Câu hỏi thường gặp:
                    </p>
                    {QUICK_REPLIES.map((qr) => (
                      <button
                        key={qr}
                        onClick={() => handleSend(qr)}
                        className="block w-full text-left text-sm px-3 py-2 rounded-xl transition-all hover:opacity-80"
                        style={{
                          background: "var(--bg-elevated)",
                          border: "1px solid var(--primary-200, #bfdbfe)",
                          color: "var(--primary-700, #1d4ed8)",
                        }}
                      >
                        {qr}
                      </button>
                    ))}
                  </div>
                )}

                {/* Cơ chế 3: Action buttons after 3+ messages */}
                {showActionButtons && !loading && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {ACTION_BUTTONS.map(({ icon: Icon, label, msg }) => (
                      <button
                        key={label}
                        onClick={() => handleSend(msg)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all hover:opacity-80"
                        style={{
                          background: "var(--primary-subtle)",
                          border: "1px solid var(--primary-200, #bfdbfe)",
                          color: "var(--primary-700, #1d4ed8)",
                        }}
                      >
                        <Icon className="w-3 h-3" />
                        {label}
                      </button>
                    ))}
                  </div>
                )}

                <div ref={bottomRef} />
              </div>

              {/* ── Input area ────────────────────────── */}
              <div
                className="px-3 py-3 border-t shrink-0"
                style={{ borderColor: "var(--border-default)" }}
              >
                <div
                  className="flex items-end gap-2 rounded-xl border px-3 py-2"
                  style={{
                    borderColor: "var(--border-default)",
                    background: "var(--bg-elevated)",
                  }}
                >
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKey}
                    placeholder="Hỏi về BĐS, giá cả, pháp lý..."
                    rows={1}
                    className="flex-1 resize-none text-sm bg-transparent outline-none leading-relaxed max-h-28"
                    style={{ color: "var(--text-primary)" }}
                  />
                  <button
                    onClick={() => handleSend()}
                    disabled={!input.trim() || loading}
                    className="p-1.5 rounded-lg shrink-0 transition-all disabled:opacity-40"
                    style={{
                      background: input.trim() ? "var(--primary-600)" : "transparent",
                    }}
                  >
                    <Send className="w-4 h-4 text-white" />
                  </button>
                </div>
                <p
                  className="text-center text-xs mt-1.5"
                  style={{ color: "var(--text-muted)" }}
                >
                  Powered by SGS AI — Luôn xác minh thông tin với tư vấn viên
                </p>
              </div>
            </>
          )}
        </div>
      )}

      {/* ── FAB Button ────────────────────────────────── */}
      <button
        onClick={handleOpen}
        className="fixed bottom-6 right-4 sm:right-6 z-50 w-14 h-14 rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-105 active:scale-95"
        style={{ background: "var(--primary-600)" }}
        aria-label="Chat với SGS AI"
      >
        {open ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <MessageCircle className="w-6 h-6 text-white" />
        )}
        {unread > 0 && !open && (
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white text-xs font-bold flex items-center justify-center">
            {unread}
          </span>
        )}
      </button>
    </>
  );
}
