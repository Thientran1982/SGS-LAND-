// ============================================================
// GET /api/cron/followup
// Cron job: chạy mỗi giờ — tìm follow-up đến hạn và gửi
// Vercel Cron: "0 * * * *" (hourly) — config trong vercel.json
// PM2 / Ubuntu: crontab -e → 0 * * * * curl https://sgsland.vn/api/cron/followup
// ============================================================
import { NextRequest, NextResponse } from "next/server";

const BACKEND = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000";
const CRON_SECRET = process.env.CRON_SECRET ?? "";
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://sgsland.vn";

interface FollowUpQueueItem {
  id: string;
  session_id: string;
  lead_id?: string;
  day: "d1" | "d3" | "d5" | "d7";
  channel: "zalo" | "sms" | "email" | "chat";
  message_text: string;
  scheduled_at: string;
  recipient: {
    name?: string;
    phone?: string;
    email?: string;
    zalo_user_id?: string;
  };
}

export async function GET(req: NextRequest) {
  // ── Auth: cron secret or internal IP ───────────────────
  const authHeader = req.headers.get("authorization");
  const isVercelCron = req.headers.get("x-vercel-cron") === "1";
  const isInternal = req.headers.get("x-internal") === CRON_SECRET;

  if (!isVercelCron && !isInternal) {
    if (CRON_SECRET && authHeader !== `Bearer ${CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  const startTime = Date.now();
  const results = {
    processed: 0,
    sent: 0,
    failed: 0,
    skipped: 0,
    errors: [] as string[],
  };

  try {
    // ── 1. Fetch pending queue from backend ────────────
    const now = new Date().toISOString();
    const queueRes = await fetch(
      `${BACKEND}/api/followup/queue?due_before=${encodeURIComponent(now)}&limit=100`,
      { signal: AbortSignal.timeout(10000) }
    );

    if (!queueRes.ok) {
      return NextResponse.json(
        { error: "Backend queue unavailable", status: queueRes.status },
        { status: 502 }
      );
    }

    const queue = await queueRes.json() as FollowUpQueueItem[];

    if (queue.length === 0) {
      return NextResponse.json({
        success: true,
        message: "No pending follow-ups",
        processed_at: now,
        duration_ms: Date.now() - startTime,
      });
    }

    // ── 2. Process each due item ───────────────────────
    const sendPromises = queue.map(async (item) => {
      results.processed++;

      try {
        // Call internal send route
        const sendRes = await fetch(`${SITE_URL}/api/followup/send`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-internal": CRON_SECRET,
          },
          body: JSON.stringify({
            followup_id: item.id,
            session_id: item.session_id,
            channel: item.channel,
            day: item.day,
            message_text: item.message_text,
            recipient: item.recipient,
          }),
          signal: AbortSignal.timeout(15000),
        });

        const data = await sendRes.json() as { success?: boolean; error?: string };

        if (data.success) {
          results.sent++;
        } else {
          results.failed++;
          results.errors.push(`Item ${item.id}: ${data.error ?? "Unknown"}`);

          // Mark as failed in backend
          await fetch(`${BACKEND}/api/followup/items/${item.id}/failed`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              failed_at: new Date().toISOString(),
              error: data.error ?? "Send failed",
            }),
            signal: AbortSignal.timeout(5000),
          }).catch(() => null);
        }
      } catch (err) {
        results.failed++;
        const msg = err instanceof Error ? err.message : "Unknown error";
        results.errors.push(`Item ${item.id}: ${msg}`);
      }
    });

    // Process all items concurrently (max 10 at a time to avoid rate limits)
    const BATCH_SIZE = 10;
    for (let i = 0; i < sendPromises.length; i += BATCH_SIZE) {
      await Promise.allSettled(sendPromises.slice(i, i + BATCH_SIZE));
    }

    // ── 3. Log to backend ──────────────────────────────
    await fetch(`${BACKEND}/api/followup/cron-log`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ran_at: now,
        duration_ms: Date.now() - startTime,
        ...results,
      }),
      signal: AbortSignal.timeout(3000),
    }).catch(() => null); // non-blocking

    return NextResponse.json({
      success: true,
      ...results,
      queue_size: queue.length,
      duration_ms: Date.now() - startTime,
      ran_at: now,
    });

  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json(
      { success: false, error: msg, ...results },
      { status: 500 }
    );
  }
}
