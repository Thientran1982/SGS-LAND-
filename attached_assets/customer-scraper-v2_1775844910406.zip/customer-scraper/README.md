# SGSLand Customer Scraper v2.0

Thu thập leads (tên + SĐT + email) từ 10 nguồn BĐS.

## Nguồn dữ liệu

| Nguồn | Phương pháp | Có SĐT | Cần proxy |
|-------|------------|--------|-----------|
| ChợTốt | API public | ✅ Có | ❌ Không |
| Novaland | Form/HTML | ⚠️ Trang | ✅ Cần |
| Vinhomes | Form/HTML | ⚠️ Trang | ✅ Cần |
| Masterise | Form/HTML | ⚠️ Trang | ✅ Cần |
| SunGroup | Form/HTML | ⚠️ Trang | ✅ Cần |
| SonKim | Form/HTML | ⚠️ Trang | ✅ Cần |
| GlobalCity | Form/HTML | ⚠️ Trang | ✅ Cần |
| AquaCity | Form/HTML | ⚠️ Trang | ✅ Cần |
| NamLong | Form/HTML | ⚠️ Trang | ✅ Cần |
| Izumi | Form/HTML | ⚠️ Trang | ✅ Cần |

## Cài đặt

```bash
npm install
```

## Cách chạy

### Chỉ ChợTốt (không cần proxy, có SĐT thực)
```bash
npm run chotot
# hoặc
npm run start -- --source=chotot
```

### Tất cả với ScraperAPI (khuyến nghị)
```bash
SCRAPER_API_KEY=your_key npm run all
```

### Tất cả với Playwright
```bash
npm run install-pw  # cài Chromium (1 lần)
npm run all-pw
```

### Push về SGSLand CRM
```bash
SCRAPER_API_KEY=key SGS_TOKEN=token npm run push-crm
```

## Output

Files lưu tại `./output/`:
- `leads_*.json` — full data
- `leads_*.csv` — Excel-ready (UTF-8 BOM)
- `report_*.md` — báo cáo

## ChợTốt API (đã xác nhận hoạt động)

```
List:   GET gateway.chotot.com/v1/public/ad-listing?cg=1020&region_v2=13&limit=50&st=k&f=p
Detail: GET gateway.chotot.com/v2/public/ad-listing/{ad_id}.json  ← có phone
```

cg codes: 1020=căn hộ, 1040=đất nền, 1000=nhà đất
region_v2: 13=HCM, 19=Bình Dương, 60=Đồng Nai
