// ================================================================
// ADAPTER: ChợTốt (chotot.com)
//
// API PUBLIC — không cần auth, không cần proxy
// ✅ Lấy được: account_name, phone (từ detail), price, area, location
//
// ENDPOINTS đã xác nhận:
//   List: GET gateway.chotot.com/v1/public/ad-listing
//   Detail (có phone): GET gateway.chotot.com/v2/public/ad-listing/{id}.json
//   Profile: GET gateway.chotot.com/v1/public/profile/{account_oid}
//
// PARAMS:
//   cg=1020   căn hộ chung cư
//   cg=1040   đất nền
//   cg=1000   nhà đất (tất cả)
//   cg=1060   nhà trọ, phòng trọ
//   cg=1080   văn phòng, mặt bằng
//   region_v2 13=HCM, 12=HN, 14=ĐN, 19=BĐ, 60=ĐNai, 15=HP
//   limit     max 50
//   st        k=bán, s=thuê
//   f         p=cá nhân, c=chuyên nghiệp
// ================================================================

import {
  Lead, SourceId, ScraperConfig, ScrapeResult,
  normalizePhone, makeId
} from '../core/types.js';
import { fetchJSON, sleep } from '../core/fetcher.js';

// Region codes ChợTốt
const REGIONS: Record<string, string> = {
  HCM:       '13',
  HN:        '12',
  DaNang:    '14',
  BinhDuong: '19',
  DongNai:   '60',
  HaiPhong:  '15',
  CanTho:    '29',
  VungTau:   '50',
};

// Category codes ChợTốt
const CATEGORIES: Record<string, { code: string; label: string }> = {
  nha_dat:    { code: '1000', label: 'Nhà đất' },
  can_ho:     { code: '1020', label: 'Căn hộ chung cư' },
  dat_nen:    { code: '1040', label: 'Đất nền' },
  nha_tro:    { code: '1060', label: 'Nhà trọ, phòng trọ' },
  van_phong:  { code: '1080', label: 'Văn phòng, mặt bằng' },
  bien_thu:   { code: '1010', label: 'Biệt thự, nhà liền kề' },
  nha_mat_pho:{ code: '1030', label: 'Nhà mặt phố' },
};

interface ChototAd {
  ad_id:        number;
  list_id:      number;
  account_id:   number;
  account_oid:  string;
  account_name: string;
  subject:      string;
  body:         string;
  category:     number;
  area_name:    string;
  region:       number;
  region_name:  string;
  ward_name:    string;
  company_ad:   boolean;
  type:         string;      // 's'=sell, 'k'=buy
  price:        number;
  price_string: string;
  image:        string;
  number_of_images: number;
  area:         number;      // m²
  date:         string;
  region_v2:    number;
  area_v2:      number;
  ward:         number;
}

interface ChototDetail extends ChototAd {
  phone:        string;
  contact_name: string;
  email?:       string;
  params?:      { label: string; value: string }[];
}

export class ChototAdapter {
  private cfg: ScraperConfig;
  private baseList   = 'https://gateway.chotot.com/v1/public/ad-listing';
  private baseDetail = 'https://gateway.chotot.com/v2/public/ad-listing';
  private baseProfile= 'https://gateway.chotot.com/v1/public/profile';

  constructor(cfg: ScraperConfig) { this.cfg = cfg; }

  // Lấy danh sách theo region + category
  private buildListUrl(
    regionCode: string,
    categoryCode: string,
    page = 1,
    limit = 50
  ): string {
    const p = new URLSearchParams({
      cg:         categoryCode,
      region_v2:  regionCode,
      limit:      String(limit),
      offset:     String((page - 1) * limit),
      st:         'k',     // bán
      f:          'p',     // cá nhân (ít bot hơn)
      w:          '1',
    });
    return `${this.baseList}?${p}`;
  }

  // Lấy detail 1 ad — có SĐT
  async fetchDetail(adId: number): Promise<ChototDetail | null> {
    try {
      const url  = `${this.baseDetail}/${adId}.json`;
      const data = await fetchJSON<{ ad: ChototDetail }>(url, this.cfg);
      return data.ad || null;
    } catch {
      return null;
    }
  }

  // Lấy profile user — có thể có thêm SĐT + tên
  async fetchProfile(accountOid: string): Promise<any> {
    try {
      const url  = `${this.baseProfile}/${accountOid}`;
      return await fetchJSON(url, this.cfg);
    } catch {
      return null;
    }
  }

  // Normalize 1 ad thành Lead
  private normalize(ad: ChototDetail | ChototAd, detail?: ChototDetail): Lead {
    const src = detail || (ad as ChototDetail);
    const phone = normalizePhone(src.phone || (ad as ChototDetail).phone);

    // Build location string
    const locationParts = [ad.ward_name, ad.area_name, ad.region_name].filter(Boolean);

    // Detect property type from category
    const typeMap: Record<number, string> = {
      1000: 'Nhà đất', 1010: 'Biệt thự', 1020: 'Căn hộ',
      1030: 'Nhà mặt phố', 1040: 'Đất nền', 1060: 'Nhà trọ',
      1080: 'Văn phòng',
    };

    return {
      id:           makeId('chotot', ad.ad_id),
      source:       'chotot',
      originalId:   String(ad.ad_id),
      sourceUrl:    `https://www.chotot.com/${ad.ad_id}.htm`,
      name:         src.contact_name || ad.account_name || null,
      phone,
      phoneRaw:     src.phone || null,
      email:        src.email || null,
      projectName:  ad.subject || null,
      propertyType: typeMap[ad.category] || 'Nhà đất',
      budget:       ad.price || null,
      budgetText:   ad.price_string || null,
      location:     locationParts.join(', ') || null,
      area:         ad.area || null,
      postedAt:     ad.date || null,
      scrapedAt:    new Date().toISOString(),
      notes:        (ad.body || '').substring(0, 200) || null,
      images:       ad.image ? [ad.image] : [],
      rawData:      { ad_id: ad.ad_id, account_oid: ad.account_oid, category: ad.category },
    };
  }

  async scrape(options: {
    regions?:    string[];      // ['HCM', 'DongNai']
    categories?: string[];      // ['can_ho', 'dat_nen']
    maxPerCombo?: number;       // max ads per region+category
    enrichPhone?: boolean;      // fetch detail để lấy phone (chậm hơn)
    enrichCount?: number;       // bao nhiêu lead được enrich (default 20)
  } = {}): Promise<ScrapeResult> {
    const start    = Date.now();
    const errors:  string[] = [];
    const allLeads: Lead[] = [];

    const regions    = (options.regions || ['HCM', 'DongNai', 'BinhDuong'])
      .map(r => ({ name: r, code: REGIONS[r] || r }))
      .filter(r => r.code);

    const categories = (options.categories || ['can_ho', 'dat_nen', 'nha_dat'])
      .map(c => CATEGORIES[c])
      .filter(Boolean);

    const maxPer     = options.maxPerCombo || 50;
    const enrichPhone = options.enrichPhone !== false; // default true
    const enrichCount = options.enrichCount || 20;

    console.log(`\n[ChợTốt] Bắt đầu scrape...`);
    console.log(`  Regions: ${regions.map(r=>r.name).join(', ')}`);
    console.log(`  Categories: ${categories.map(c=>c.label).join(', ')}`);
    console.log(`  Enrich phone: ${enrichPhone} (${enrichCount} leads)`);

    // ── Phase 1: Lấy danh sách ──────────────────────────────────
    for (const region of regions) {
      for (const cat of categories) {
        await sleep(this.cfg.delayMs);
        const url = this.buildListUrl(region.code, cat.code, 1, Math.min(maxPer, 50));

        try {
          const data = await fetchJSON<{ total: number; ads: ChototAd[] }>(url, this.cfg);
          const ads  = data.ads || [];
          console.log(`  [${region.name}/${cat.label}] ${ads.length}/${data.total} ads`);

          for (const ad of ads) {
            allLeads.push(this.normalize(ad));
          }

          // Nếu total > 50, lấy thêm trang 2
          if (data.total > 50 && maxPer > 50) {
            await sleep(this.cfg.delayMs);
            const url2 = this.buildListUrl(region.code, cat.code, 2, 50);
            const d2   = await fetchJSON<{ ads: ChototAd[] }>(url2, this.cfg).catch(() => ({ ads: [] }));
            for (const ad of d2.ads || []) allLeads.push(this.normalize(ad));
          }

        } catch (e: any) {
          const msg = `${region.name}/${cat.label}: ${e.message}`;
          errors.push(msg);
          console.warn(`  [ChợTốt] ⚠️ ${msg}`);
        }
      }
    }

    // ── Phase 2: Enrich SĐT từ detail endpoint ──────────────────
    if (enrichPhone && allLeads.length > 0) {
      console.log(`\n[ChợTốt] Enriching SĐT cho ${Math.min(enrichCount, allLeads.length)} leads...`);
      const toEnrich = allLeads.slice(0, enrichCount);

      for (let i = 0; i < toEnrich.length; i++) {
        await sleep(this.cfg.delayMs / 2);
        const lead = toEnrich[i];
        const adId = Number(lead.originalId);

        try {
          const detail = await this.fetchDetail(adId);
          if (detail) {
            const phone = normalizePhone(detail.phone);
            lead.phone    = phone;
            lead.phoneRaw = detail.phone || null;
            lead.name     = detail.contact_name || detail.account_name || lead.name;
            lead.email    = detail.email || lead.email;

            if (phone) {
              console.log(`  ✅ [${i+1}/${toEnrich.length}] ${lead.name} → ${phone}`);
            }

            // Enrich từ params (diện tích, hướng, pháp lý...)
            if (detail.params) {
              const areaParam = detail.params.find(p => p.label.includes('Diện tích'));
              if (areaParam) {
                const areaNum = parseFloat(areaParam.value.replace(/[^\d.]/g, ''));
                if (!isNaN(areaNum)) lead.area = areaNum;
              }
            }
          }
        } catch (e: any) {
          console.warn(`  [ChợTốt] Detail ${adId}: ${e.message}`);
        }
      }
    }

    // Deduplicate by phone
    const seen = new Set<string>();
    const unique = allLeads.filter(l => {
      const key = l.phone || l.originalId;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    console.log(`\n[ChợTốt] Kết quả: ${unique.length} leads (${allLeads.length - unique.length} trùng lặp)`);
    console.log(`  Có SĐT: ${unique.filter(l=>l.phone).length}`);

    return {
      source:     'chotot',
      leads:      unique,
      total:      unique.length,
      failed:     allLeads.length - unique.length,
      durationMs: Date.now() - start,
      errors,
    };
  }
}
