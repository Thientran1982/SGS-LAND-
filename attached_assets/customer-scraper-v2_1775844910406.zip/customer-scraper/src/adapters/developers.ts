// ================================================================
// ADAPTERS: Các chủ đầu tư BĐS cao cấp
// Novaland, Vinhomes, Masterise, SunGroup, SonKim, GlobalCity,
// AquaCity, NamLong (Izumi)
//
// CƠ CHẾ:
// 1. Playwright navigate + intercept API calls (tốt nhất)
// 2. ScraperAPI với render=true → parse HTML + regex phone
// 3. Direct fetch (nếu không có anti-bot)
//
// MỖI TRANG: form đăng ký tư vấn → submit → intercept POST body
// → lấy name + phone + email + project interest của khách
//
// ⚠️ LƯU Ý: Các trang này thu thập leads từ KHÁCH HỎI TƯ VẤN,
//    không phải từ data người dùng — đây là public-facing form
// ================================================================

import {
  Lead, SourceId, ScraperConfig, ScrapeResult,
  normalizePhone, makeId
} from '../core/types.js';
import {
  fetchText, fetchJSON, fetchWithPlaywright,
  extractPhones, extractEmails, sleep
} from '../core/fetcher.js';

// ── Base class cho tất cả developer sites ──────────────────────
abstract class DeveloperAdapter {
  protected cfg: ScraperConfig;
  abstract readonly sourceId: SourceId;
  abstract readonly siteName: string;
  abstract readonly pages: string[];
  abstract readonly formApiPatterns: string[];  // URL patterns để intercept

  constructor(cfg: ScraperConfig) { this.cfg = cfg; }

  // Phương thức chính — override nếu cần custom logic
  async scrape(): Promise<ScrapeResult> {
    const start  = Date.now();
    const leads:  Lead[] = [];
    const errors: string[] = [];

    console.log(`\n[${this.siteName}] Bắt đầu scrape ${this.pages.length} trang...`);

    for (const pageUrl of this.pages) {
      await sleep(this.cfg.delayMs);
      try {
        const pageLeads = await this.scrapePage(pageUrl);
        leads.push(...pageLeads);
        if (pageLeads.length > 0) {
          console.log(`  ✅ [${this.siteName}] ${pageUrl} → ${pageLeads.length} contacts`);
          pageLeads.forEach(l => {
            if (l.phone) console.log(`     📱 ${l.name || 'N/A'}: ${l.phone}`);
          });
        } else {
          console.log(`  ⚠️ [${this.siteName}] ${pageUrl} → 0 contacts (cần proxy/Playwright)`);
        }
      } catch (e: any) {
        const msg = `${pageUrl}: ${e.message}`;
        errors.push(msg);
        console.warn(`  ❌ [${this.siteName}] ${msg}`);
      }
    }

    // Deduplicate
    const seen    = new Set<string>();
    const unique  = leads.filter(l => {
      const key = l.phone || l.originalId;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    return {
      source:     this.sourceId,
      leads:      unique,
      total:      unique.length,
      failed:     leads.length - unique.length,
      durationMs: Date.now() - start,
      errors,
    };
  }

  // Scrape 1 trang — dùng Playwright nếu có, fallback ScraperAPI
  protected async scrapePage(url: string): Promise<Lead[]> {
    if (this.cfg.usePlaywright) {
      return this.scrapeWithPlaywright(url);
    }
    if (this.cfg.scraperApiKey) {
      return this.scrapeWithProxy(url);
    }
    // Direct fetch — thường bị block
    try {
      const html = await fetchText(url, this.cfg, { render: false });
      return this.parseHTML(html, url);
    } catch (e: any) {
      throw new Error(`Direct fetch failed: ${e.message}. Cần ScraperAPI key hoặc Playwright.`);
    }
  }

  // Playwright: navigate + intercept form API calls
  protected async scrapeWithPlaywright(url: string): Promise<Lead[]> {
    const { html, networkData } = await fetchWithPlaywright(url, this.cfg, {
      interceptUrls: this.formApiPatterns,
      waitFor:       'form, .contact-form, [class*="form"]',
    });

    // Kiểm tra network data (form submissions từ JS)
    const fromNetwork: Lead[] = [];
    for (const req of networkData) {
      const extracted = this.parseNetworkData(req.data, req.url, url);
      fromNetwork.push(...extracted);
    }

    // Parse HTML để lấy phones visible trên trang
    const fromHTML = this.parseHTML(html, url);

    return [...fromNetwork, ...fromHTML];
  }

  // ScraperAPI với render=true
  protected async scrapeWithProxy(url: string): Promise<Lead[]> {
    const html = await fetchText(url, this.cfg, { render: true });
    return this.parseHTML(html, url);
  }

  // Parse phones/emails từ HTML
  protected parseHTML(html: string, pageUrl: string): Lead[] {
    const phones = extractPhones(html);
    const emails = extractEmails(html);
    const leads:  Lead[] = [];

    // Tìm tên trang / dự án từ <title>
    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const pageTitle  = titleMatch ? titleMatch[1].trim() : this.siteName;

    // Extract các số phone
    phones.forEach((phone, i) => {
      const normalized = normalizePhone(phone);
      if (!normalized) return;
      leads.push({
        id:           makeId(this.sourceId, `${phone}-${i}`),
        source:       this.sourceId,
        originalId:   `${phone}-${i}`,
        sourceUrl:    pageUrl,
        name:         null,
        phone:        normalized,
        phoneRaw:     phone,
        email:        emails[i] || null,
        projectName:  pageTitle,
        propertyType: null,
        budget:       null,
        budgetText:   null,
        location:     null,
        area:         null,
        postedAt:     null,
        scrapedAt:    new Date().toISOString(),
        notes:        `Extracted from page: ${pageUrl}`,
        images:       [],
        rawData:      { extractedFrom: 'html', pageUrl },
      });
    });

    return leads;
  }

  // Parse data từ network intercept (form submissions)
  protected parseNetworkData(data: any, apiUrl: string, pageUrl: string): Lead[] {
    if (!data) return [];
    const leads: Lead[] = [];

    // Common field names across Vietnamese RE sites
    const name  = data.full_name || data.fullName || data.name || data.ho_ten || data.contact_name;
    const phone = normalizePhone(
      data.phone || data.mobile || data.phone_number || data.dien_thoai || data.so_dien_thoai
    );
    const email = data.email || data.mail;
    const proj  = data.project || data.project_name || data.projectName || data.du_an;
    const note  = data.message || data.note || data.content || data.noi_dung;

    if (phone || email) {
      leads.push({
        id:           makeId(this.sourceId, phone || email || Date.now()),
        source:       this.sourceId,
        originalId:   phone || email || String(Date.now()),
        sourceUrl:    pageUrl,
        name:         name || null,
        phone,
        phoneRaw:     data.phone || data.mobile || null,
        email:        email || null,
        projectName:  proj || this.siteName,
        propertyType: data.type || data.property_type || null,
        budget:       null,
        budgetText:   data.budget || null,
        location:     data.address || data.location || null,
        area:         null,
        postedAt:     new Date().toISOString(),
        scrapedAt:    new Date().toISOString(),
        notes:        note ? String(note).substring(0, 200) : null,
        images:       [],
        rawData:      { apiUrl, ...data },
      });
    }

    return leads;
  }
}

// ── NOVALAND ─────────────────────────────────────────────────────
export class NovalandAdapter extends DeveloperAdapter {
  readonly sourceId     = 'novaland' as SourceId;
  readonly siteName     = 'Novaland';
  readonly pages        = [
    'https://www.novaland.com.vn/du-an/aqua-city',
    'https://www.novaland.com.vn/du-an/grand-manhattan',
    'https://www.novaland.com.vn/du-an/novaworld-phan-thiet',
    'https://www.novaland.com.vn/dang-ky',
  ];
  readonly formApiPatterns = [
    '/api/contact', '/api/lead', '/api/register',
    '/contact-form', '/dang-ky', '/register-interest'
  ];
}

// ── VINHOMES ─────────────────────────────────────────────────────
export class VinhomesAdapter extends DeveloperAdapter {
  readonly sourceId     = 'vinhomes' as SourceId;
  readonly siteName     = 'Vinhomes';
  readonly pages        = [
    'https://vinhomes.vn/grand-park',
    'https://vinhomes.vn/central-park',
    'https://vinhomes.vn/ocean-park',
  ];
  readonly formApiPatterns = [
    '/api/register', '/api/lead', '/vi/api/register-interest',
    '/api/contact-us', 'vinhomes.vn/api'
  ];
}

// ── MASTERISE HOMES ───────────────────────────────────────────────
export class MasteriseAdapter extends DeveloperAdapter {
  readonly sourceId     = 'masterise' as SourceId;
  readonly siteName     = 'Masterise Homes';
  readonly pages        = [
    'https://masterisehomes.com/du-an/the-global-city/',
    'https://masterisehomes.com/du-an/grand-marina/',
    'https://masterisehomes.com/du-an/masteri-centre-point/',
  ];
  readonly formApiPatterns = [
    '/wp-json/contact-form-7/v1/', '/api/contact',
    '/api/leads', 'masterise'
  ];
}

// ── SUN GROUP ────────────────────────────────────────────────────
export class SunGroupAdapter extends DeveloperAdapter {
  readonly sourceId     = 'sungroup' as SourceId;
  readonly siteName     = 'Sun Group';
  readonly pages        = [
    'https://sungroup.com.vn/du-an/',
    'https://sungroup.com.vn/bds/sun-premier-village-ba-na-hills/',
    'https://sungroup.com.vn/lien-he/',
  ];
  readonly formApiPatterns = [
    '/api/contact', '/api/lead', '/wp-json/',
    'sungroup.com.vn/api'
  ];
}

// ── SON KIM LAND ─────────────────────────────────────────────────
export class SonKimAdapter extends DeveloperAdapter {
  readonly sourceId     = 'sonkim' as SourceId;
  readonly siteName     = 'Son Kim Land';
  readonly pages        = [
    'https://sonkimland.com.vn/du-an/',
    'https://sonkimland.com.vn/lien-he/',
  ];
  readonly formApiPatterns = [
    '/api/contact', '/wp-json/', '/api/leads'
  ];
}

// ── THE GLOBAL CITY (Masterise) ──────────────────────────────────
export class GlobalCityAdapter extends DeveloperAdapter {
  readonly sourceId     = 'globalcity' as SourceId;
  readonly siteName     = 'The Global City';
  readonly pages        = [
    'https://theglobalcity.vn/',
    'https://theglobalcity.vn/lien-he/',
  ];
  readonly formApiPatterns = [
    '/api/register', '/api/contact', '/api/lead'
  ];
}

// ── AQUA CITY (Novaland) ─────────────────────────────────────────
export class AquaCityAdapter extends DeveloperAdapter {
  readonly sourceId     = 'aquacity' as SourceId;
  readonly siteName     = 'Aqua City';
  readonly pages        = [
    'https://aquacity.com.vn/',
    'https://aquacity.com.vn/lien-he/',
  ];
  readonly formApiPatterns = [
    '/api/register-interest', '/api/contact',
    '/wp-json/', 'aquacity.com.vn/api'
  ];
}

// ── NAM LONG LAND ────────────────────────────────────────────────
export class NamLongAdapter extends DeveloperAdapter {
  readonly sourceId     = 'namlong' as SourceId;
  readonly siteName     = 'Nam Long Land';
  readonly pages        = [
    'https://namlongland.com.vn/du-an/',
    'https://namlongland.com.vn/du-an/izumi-city/',
    'https://namlongland.com.vn/lien-he/',
  ];
  readonly formApiPatterns = [
    '/api/contact', '/api/lead', '/api/register',
    'namlongland.com.vn/api'
  ];
}

// ── IZUMI CITY ───────────────────────────────────────────────────
export class IzumiAdapter extends DeveloperAdapter {
  readonly sourceId     = 'izumi' as SourceId;
  readonly siteName     = 'Izumi City';
  readonly pages        = [
    'https://izumicity.com.vn/',
    'https://izumicity.com.vn/lien-he/',
  ];
  readonly formApiPatterns = [
    '/api/contact', '/api/leads', '/register',
    'izumicity.com.vn/api'
  ];
}
