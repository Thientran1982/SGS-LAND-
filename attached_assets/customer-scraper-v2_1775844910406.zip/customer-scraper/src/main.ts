#!/usr/bin/env node
// ================================================================
// MAIN — Multi-Source Customer Scraper v2.0
//
// Cách dùng:
//   npx tsx src/main.ts                    # chạy tất cả
//   npx tsx src/main.ts --source=chotot    # chỉ ChợTốt
//   npx tsx src/main.ts --push             # push về SGSLand CRM
//   npx tsx src/main.ts --pw               # dùng Playwright
//
// Env vars:
//   SCRAPER_API_KEY=xxx    ScraperAPI key (scraperapi.com free 5k/tháng)
//   USE_PLAYWRIGHT=true    Playwright headless browser
//   SGS_BASE_URL=...       SGSLand URL
//   SGS_TOKEN=...          SGSLand JWT token
// ================================================================

import type { Lead, ScraperConfig, MultiScrapeResult, ScrapeResult, SourceId } from './core/types.js';
import { sleep } from './core/fetcher.js';
import { ChototAdapter }    from './adapters/chotot.js';
import {
  NovalandAdapter, VinhomesAdapter, MasteriseAdapter,
  SunGroupAdapter, SonKimAdapter, GlobalCityAdapter,
  AquaCityAdapter, NamLongAdapter, IzumiAdapter,
} from './adapters/developers.js';
import { exportJSON, exportCSV, exportMarkdown, pushToSgsland } from './core/exporters.js';

// ── Parse CLI args ────────────────────────────────────────────
function parseArgs(): Record<string, string> {
  const args: Record<string, string> = {};
  for (const a of process.argv.slice(2)) {
    if (a.startsWith('--')) {
      const [k, v = 'true'] = a.slice(2).split('=');
      args[k] = v;
    }
  }
  return args;
}

// ── Build config từ env + CLI ─────────────────────────────────
function buildConfig(args: Record<string, string>): ScraperConfig {
  const scraperApiKey = args.key || process.env.SCRAPER_API_KEY || '';
  const usePlaywright = args.pw === 'true' || process.env.USE_PLAYWRIGHT === 'true';
  const sgsBaseUrl    = args.sgsUrl || process.env.SGS_BASE_URL || 'https://sgsland.vn';
  const sgsToken      = args.sgsToken || process.env.SGS_TOKEN || '';

  return {
    scraperApiKey:  scraperApiKey || undefined,
    proxyUrl:       scraperApiKey ? `http://api.scraperapi.com?api_key=${scraperApiKey}` : undefined,
    usePlaywright,
    headless:       true,
    timeout:        30_000,
    delayMs:        parseInt(args.delay || '1200'),
    maxRetries:     3,
    outputDir:      args.output || './output',
    regions:        args.regions?.split(',') || ['HCM', 'DongNai', 'BinhDuong'],
    maxLeads:       parseInt(args.max || '500'),
    sgsland: {
      baseUrl: sgsBaseUrl,
      token:   sgsToken,
      enabled: args.push === 'true' && !!sgsToken,
    },
  };
}

// ── Orchestrator ──────────────────────────────────────────────
async function runScraper(
  cfg: ScraperConfig,
  sources: SourceId[]
): Promise<MultiScrapeResult> {
  const start   = Date.now();
  const allLeads: Lead[] = [];
  const bySource: Record<SourceId, number> = {} as any;
  const errors:   Record<SourceId, string[]> = {} as any;

  console.log('\n' + '═'.repeat(60));
  console.log('  SGSLand Multi-Source Customer Scraper v2.0');
  console.log('═'.repeat(60));
  console.log(`  Nguồn:     ${sources.join(', ')}`);
  console.log(`  Proxy:     ${cfg.scraperApiKey ? 'ScraperAPI ✅' : 'Không có'}`);
  console.log(`  Playwright:${cfg.usePlaywright ? ' ✅' : ' ❌'}`);
  console.log(`  Regions:   ${cfg.regions?.join(', ')}`);
  console.log('═'.repeat(60) + '\n');

  if (!cfg.scraperApiKey && !cfg.usePlaywright) {
    console.warn('⚠️  CẢNH BÁO: Không có ScraperAPI key và Playwright.');
    console.warn('   ChợTốt sẽ hoạt động (API public).');
    console.warn('   Các trang khác (Novaland, Vinhomes...) cần proxy hoặc Playwright.');
    console.warn('   → Set: SCRAPER_API_KEY=your_key  hoặc  USE_PLAYWRIGHT=true\n');
  }

  // Tạo adapters
  const adapterMap: Record<SourceId, any> = {
    chotot:     new ChototAdapter(cfg),
    novaland:   new NovalandAdapter(cfg),
    vinhomes:   new VinhomesAdapter(cfg),
    masterise:  new MasteriseAdapter(cfg),
    sungroup:   new SunGroupAdapter(cfg),
    sonkim:     new SonKimAdapter(cfg),
    globalcity: new GlobalCityAdapter(cfg),
    aquacity:   new AquaCityAdapter(cfg),
    namlong:    new NamLongAdapter(cfg),
    izumi:      new IzumiAdapter(cfg),
  };

  // Chạy từng source
  for (const sourceId of sources) {
    const adapter = adapterMap[sourceId];
    if (!adapter) continue;

    try {
      let result: ScrapeResult;

      // ChợTốt có scrape options riêng
      if (sourceId === 'chotot') {
        result = await (adapter as ChototAdapter).scrape({
          regions:      cfg.regions,
          categories:   ['can_ho', 'dat_nen', 'nha_dat'],
          maxPerCombo:  50,
          enrichPhone:  true,
          enrichCount:  30,
        });
      } else {
        result = await adapter.scrape();
      }

      allLeads.push(...result.leads);
      bySource[sourceId]  = result.total;
      errors[sourceId]    = result.errors;

      console.log(`\n📊 [${sourceId}] ${result.total} leads, ${result.errors.length} lỗi\n`);

    } catch (e: any) {
      console.error(`❌ [${sourceId}] Fatal: ${e.message}`);
      bySource[sourceId] = 0;
      errors[sourceId]   = [e.message];
    }

    // Delay giữa các nguồn
    if (sources.indexOf(sourceId) < sources.length - 1) {
      await sleep(cfg.delayMs * 2);
    }
  }

  // Deduplicate global (cross-source) by phone
  const phoneSeen = new Set<string>();
  const uniqueLeads = allLeads.filter(l => {
    if (!l.phone) return true; // Giữ lại nếu không có phone
    if (phoneSeen.has(l.phone)) return false;
    phoneSeen.add(l.phone);
    return true;
  });

  const result: MultiScrapeResult = {
    scrapedAt:   new Date().toISOString(),
    durationMs:  Date.now() - start,
    totalLeads:  allLeads.length,
    uniqueLeads: uniqueLeads.length,
    bySource,
    leads:       uniqueLeads,
    errors,
  };

  return result;
}

// ── Summary print ─────────────────────────────────────────────
function printSummary(result: MultiScrapeResult): void {
  const withPhone = result.leads.filter(l => l.phone).length;
  const withEmail = result.leads.filter(l => l.email).length;

  console.log('\n' + '═'.repeat(60));
  console.log('  KẾT QUẢ');
  console.log('═'.repeat(60));
  console.log(`  Tổng raw       : ${result.totalLeads}`);
  console.log(`  Unique (dedup) : ${result.uniqueLeads}`);
  console.log(`  Có SĐT         : ${withPhone} (${Math.round(withPhone/result.uniqueLeads*100)}%)`);
  console.log(`  Có Email       : ${withEmail}`);
  console.log(`  Thời gian      : ${(result.durationMs/1000).toFixed(1)}s`);
  console.log('\n  Theo nguồn:');
  Object.entries(result.bySource).forEach(([src, n]) => {
    console.log(`    ${src.padEnd(12)}: ${n}`);
  });
  console.log('═'.repeat(60));

  // In ra leads có SĐT
  const phoneLeads = result.leads.filter(l => l.phone);
  if (phoneLeads.length > 0) {
    console.log('\n📱 DANH SÁCH CÓ SỐ ĐIỆN THOẠI:');
    console.log('─'.repeat(60));
    phoneLeads.slice(0, 20).forEach((l, i) => {
      const name   = (l.name || 'Ẩn danh').padEnd(20);
      const phone  = (l.phone || '').padEnd(12);
      const src    = l.source.padEnd(12);
      const proj   = (l.projectName || '').substring(0, 20);
      console.log(`  ${i+1}. ${name} ${phone} [${src}] ${proj}`);
    });
    if (phoneLeads.length > 20) {
      console.log(`  ... và ${phoneLeads.length - 20} leads khác`);
    }
  }
}

// ── MAIN ─────────────────────────────────────────────────────
async function main(): Promise<void> {
  const args = parseArgs();
  const cfg  = buildConfig(args);

  // Xác định sources cần chạy
  const ALL_SOURCES: SourceId[] = [
    'chotot', 'novaland', 'vinhomes', 'masterise',
    'sungroup', 'sonkim', 'globalcity', 'aquacity',
    'namlong', 'izumi',
  ];

  const requestedSource = args.source as SourceId | undefined;
  const sources = requestedSource
    ? (ALL_SOURCES.includes(requestedSource) ? [requestedSource] : [])
    : ALL_SOURCES;

  if (sources.length === 0) {
    console.error(`❌ Nguồn không hợp lệ: ${args.source}`);
    console.error(`   Hợp lệ: ${ALL_SOURCES.join(', ')}`);
    process.exit(1);
  }

  // Chạy scraper
  const result = await runScraper(cfg, sources);

  // Print summary
  printSummary(result);

  // Export files
  const dir = cfg.outputDir || './output';
  exportJSON(result, dir);
  exportCSV(result, dir);
  exportMarkdown(result, dir);

  // Push về SGSLand CRM (nếu bật)
  if (cfg.sgsland?.enabled) {
    await pushToSgsland(result.leads, cfg);
  }

  console.log(`\n✅ Xong! Files lưu tại: ${dir}/`);
}

main().catch((e) => {
  console.error('❌ Fatal error:', e);
  process.exit(1);
});
