// ================================================================
// EXPORTERS — CSV, JSON, Markdown + push về SGSLand CRM
// ================================================================

import * as fs   from 'fs';
import * as path from 'path';
import type { Lead, MultiScrapeResult, ScraperConfig } from './types.js';

function ts(): string {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

function esc(v: any): string {
  if (v === null || v === undefined) return '';
  const s = String(v);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""').replace(/\n/g, ' ') + '"';
  }
  return s;
}

// ── JSON ───────────────────────────────────────────────────────
export function exportJSON(result: MultiScrapeResult, dir: string): string {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `leads_${ts()}.json`);
  fs.writeFileSync(file, JSON.stringify(result, null, 2), 'utf-8');
  console.log(`💾 JSON → ${file}`);
  return file;
}

// ── CSV (UTF-8 BOM, Excel-ready) ──────────────────────────────
const CSV_HEADERS = [
  'nguon', 'ten', 'so_dien_thoai', 'email',
  'du_an_quan_tam', 'loai_bds', 'ngan_sach', 'dien_tich',
  'vi_tri', 'ghi_chu', 'thoi_gian', 'link_goc', 'scraped_luc'
];

export function exportCSV(result: MultiScrapeResult, dir: string): string {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `leads_${ts()}.csv`);
  const rows = result.leads.map(l => [
    l.source, l.name || '', l.phone || '', l.email || '',
    l.projectName || '', l.propertyType || '',
    l.budgetText || (l.budget ? (l.budget/1e9).toFixed(1)+' tỷ' : ''),
    l.area ? l.area+'m²' : '',
    l.location || '', l.notes?.substring(0,100) || '',
    l.postedAt || '', l.sourceUrl || '', l.scrapedAt,
  ].map(esc).join(','));

  fs.writeFileSync(file,
    '\uFEFF' + [CSV_HEADERS.join(','), ...rows].join('\n'),
    'utf-8'
  );
  console.log(`💾 CSV → ${file} (${result.leads.length} rows)`);
  return file;
}

// ── Markdown Report ─────────────────────────────────────────
export function exportMarkdown(result: MultiScrapeResult, dir: string): string {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `report_${ts()}.md`);

  const bySource = Object.entries(result.bySource)
    .sort(([,a],[,b]) => b - a)
    .map(([src, n]) => `| ${src} | ${n} |`)
    .join('\n');

  const withPhone  = result.leads.filter(l => l.phone).length;
  const withEmail  = result.leads.filter(l => l.email).length;

  const sampleRows = result.leads
    .filter(l => l.phone)
    .slice(0, 10)
    .map(l => `| ${l.name||'—'} | \`${l.phone}\` | ${l.source} | ${l.projectName?.substring(0,30)||'—'} |`)
    .join('\n');

  const md = `# Báo Cáo Khách Hàng BĐS — Multi-Source Scraper

> Scraped: **${result.scrapedAt}**  
> Tổng thời gian: **${(result.durationMs/1000).toFixed(1)}s**

---

## 📊 Tổng Quan

| Chỉ số | Giá trị |
|--------|---------|
| Tổng leads | **${result.totalLeads}** |
| Unique (sau dedup) | **${result.uniqueLeads}** |
| Có số điện thoại | **${withPhone}** (${Math.round(withPhone/result.uniqueLeads*100)}%) |
| Có email | **${withEmail}** |

## 📡 Theo Nguồn

| Nguồn | Leads |
|-------|-------|
${bySource}

## 📱 Danh Sách Có SĐT (10 mẫu đầu)

| Tên | SĐT | Nguồn | Dự án |
|-----|-----|-------|-------|
${sampleRows}

---

*Tạo bởi SGSLand Multi-Source Customer Scraper v2.0*
`;
  fs.writeFileSync(file, md, 'utf-8');
  console.log(`💾 Report → ${file}`);
  return file;
}

// ── Push về SGSLand CRM ─────────────────────────────────────
export async function pushToSgsland(
  leads: Lead[],
  cfg: ScraperConfig
): Promise<{ success: number; failed: number }> {
  if (!cfg.sgsland?.enabled || !cfg.sgsland?.token) {
    console.log('[SGSLand] Push tắt hoặc chưa có token. Set SGS_TOKEN=');
    return { success: 0, failed: 0 };
  }

  const { baseUrl, token } = cfg.sgsland;
  let success = 0, failed = 0;

  console.log(`\n[SGSLand] Pushing ${leads.length} leads...`);

  // Chỉ push lead có SĐT
  const validLeads = leads.filter(l => l.phone || l.email);

  for (const lead of validLeads) {
    try {
      const res = await fetch(`${baseUrl}/api/leads`, {
        method:  'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type':  'application/json',
        },
        body: JSON.stringify({
          name:   lead.name || 'Khách quan tâm',
          phone:  lead.phone,
          email:  lead.email,
          source: lead.source,
          stage:  'NEW',
          tags:   [lead.projectName, lead.propertyType].filter(Boolean) as string[],
          notes:  [
            lead.projectName && `Dự án: ${lead.projectName}`,
            lead.budgetText  && `Ngân sách: ${lead.budgetText}`,
            lead.location    && `Khu vực: ${lead.location}`,
            lead.notes,
            `Nguồn: ${lead.sourceUrl}`,
          ].filter(Boolean).join('\n'),
          preferences: {
            regions:       lead.location ? [lead.location] : [],
            propertyTypes: lead.propertyType ? [lead.propertyType] : [],
            budgetMin:     lead.budget,
            _source:       lead.source,
          },
        }),
      });

      if (res.ok) {
        success++;
        if (lead.phone) console.log(`  ✅ Pushed: ${lead.name} (${lead.phone})`);
      } else {
        const err = await res.text().catch(() => res.statusText);
        console.warn(`  ⚠️ Failed ${lead.phone}: ${res.status} ${err.substring(0,80)}`);
        failed++;
      }
    } catch (e: any) {
      console.warn(`  ❌ Error ${lead.phone}: ${e.message}`);
      failed++;
    }

    await new Promise(r => setTimeout(r, 200)); // Small delay
  }

  console.log(`[SGSLand] Done: ${success} success, ${failed} failed`);
  return { success, failed };
}
