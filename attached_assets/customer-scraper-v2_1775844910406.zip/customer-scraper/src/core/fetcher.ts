// ================================================================
// FETCHER — HTTP client với proxy + Playwright + retry
// ================================================================

import type { ScraperConfig } from './types.js';

const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

export function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

// ── ScraperAPI wrapper ──────────────────────────────────────────
// https://www.scraperapi.com — free 5000 req/tháng
// render=true: JS rendering (dùng cho React/Vue sites)
export function scraperApiUrl(
  targetUrl: string,
  apiKey: string,
  options: { render?: boolean; country?: string } = {}
): string {
  const p = new URLSearchParams({
    api_key:      apiKey,
    url:          targetUrl,
    country_code: options.country || 'vn',
  });
  if (options.render) p.set('render', 'true');
  return `http://api.scraperapi.com/?${p}`;
}

// ── Core fetch với retry ────────────────────────────────────────
export async function fetchText(
  url: string,
  cfg: ScraperConfig,
  options: {
    isJSON?:    boolean;
    render?:    boolean;   // yêu cầu JS rendering qua ScraperAPI
    headers?:   Record<string, string>;
  } = {}
): Promise<string> {
  const maxRetries = cfg.maxRetries || 3;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // Nếu có ScraperAPI key → dùng proxy
      const fetchUrl = cfg.scraperApiKey
        ? scraperApiUrl(url, cfg.scraperApiKey, { render: options.render })
        : url;

      const headers: Record<string, string> = {
        'User-Agent':      BROWSER_UA,
        'Accept':          options.isJSON
          ? 'application/json, text/plain, */*'
          : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
        'Cache-Control':   'no-cache',
        ...(options.headers || {}),
      };

      const res = await fetch(fetchUrl, { headers });

      if (res.status === 429) {
        const wait = cfg.delayMs * Math.pow(2, attempt);
        console.warn(`  [rate-limit] 429 — chờ ${wait}ms (attempt ${attempt})`);
        await sleep(wait);
        continue;
      }

      if (res.status === 403 || res.status === 503) {
        if (!cfg.scraperApiKey) {
          throw new Error(`HTTP ${res.status} — cần ScraperAPI key hoặc Playwright. Set SCRAPER_API_KEY=`);
        }
        throw new Error(`HTTP ${res.status}: ${url}`);
      }

      if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);

      return await res.text();

    } catch (e: any) {
      if (attempt === maxRetries) throw e;
      await sleep(cfg.delayMs * attempt);
    }
  }
  throw new Error(`fetchText: max retries exceeded for ${url}`);
}

export async function fetchJSON<T = any>(url: string, cfg: ScraperConfig, headers?: Record<string, string>): Promise<T> {
  const text = await fetchText(url, cfg, { isJSON: true, headers });
  return JSON.parse(text) as T;
}

// ── Playwright fetcher ──────────────────────────────────────────
// Dùng khi cần JS render + intercept network + form interaction
export async function fetchWithPlaywright(
  url: string,
  cfg: ScraperConfig,
  options: {
    waitFor?:        string;       // CSS selector để chờ
    interceptUrls?:  string[];     // URL patterns để intercept request/response
    fillForm?:       {             // Điền form nếu cần
      name?:    string;
      phone?:   string;
      email?:   string;
    };
    extractNetworkData?: boolean;  // Trả về cả data từ network intercept
  } = {}
): Promise<{ html: string; networkData: any[] }> {
  let chromium: any;
  try {
    const pw = await import('playwright');
    chromium = pw.chromium;
  } catch {
    throw new Error('Playwright chưa cài. Chạy: npm install playwright && npx playwright install chromium');
  }

  const browser = await chromium.launch({
    headless: cfg.headless ?? true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-blink-features=AutomationControlled',
      '--disable-web-security',
    ],
  });

  const networkData: any[] = [];

  try {
    const ctx  = await browser.newContext({
      userAgent: BROWSER_UA,
      locale:    'vi-VN',
      viewport:  { width: 1366, height: 768 },
      extraHTTPHeaders: { 'Accept-Language': 'vi-VN,vi;q=0.9' },
    });

    const page = await ctx.newPage();

    // Ẩn webdriver
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    });

    // Intercept network requests/responses
    if (options.interceptUrls?.length) {
      page.on('response', async (response: any) => {
        const isMatch = options.interceptUrls!.some(p => response.url().includes(p));
        if (isMatch && response.ok()) {
          try {
            const body = await response.json();
            networkData.push({ url: response.url(), data: body });
          } catch {}
        }
      });
    }

    await page.goto(url, { waitUntil: 'networkidle', timeout: cfg.timeout || 30000 });
    await page.waitForTimeout(2000);

    // Điền form nếu cần (để trigger JS events)
    if (options.fillForm) {
      const { name, phone, email } = options.fillForm;
      if (name) {
        const nameInput = await page.$('input[name*="name"], input[placeholder*="Họ"]');
        if (nameInput) await nameInput.fill(name);
      }
      if (phone) {
        const phoneInput = await page.$('input[type="tel"], input[name*="phone"], input[placeholder*="Điện thoại"]');
        if (phoneInput) await phoneInput.fill(phone);
      }
      if (email) {
        const emailInput = await page.$('input[type="email"]');
        if (emailInput) await emailInput.fill(email);
      }
    }

    // Chờ selector nếu cần
    if (options.waitFor) {
      await page.waitForSelector(options.waitFor, { timeout: 10000 }).catch(() => {});
    }

    const html = await page.content();
    return { html, networkData };

  } finally {
    await browser.close();
  }
}

// ── HTML Phone/Email extractor ──────────────────────────────────
export function extractPhones(html: string): string[] {
  const patterns = [
    /(?:0|\+84)(?:\d[ .-]?){8}\d/g,          // 0xxx xxx xxx
    /(?:0|\+84)[1-9]\d{8}/g,                  // 0xxxxxxxxx compact
    /\b(0[3-9][0-9]{8})\b/g,                  // strict VN phone
  ];
  const found = new Set<string>();
  for (const p of patterns) {
    const m = html.match(p) || [];
    m.forEach(ph => found.add(ph.replace(/[ .-]/g, '')));
  }
  return [...found].filter(ph => ph.replace(/\D/g, '').length === 10);
}

export function extractEmails(html: string): string[] {
  const m = html.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || [];
  return [...new Set(m)].filter(e =>
    !e.includes('example') && !e.includes('domain') &&
    !e.includes('noreply') && !e.includes('no-reply')
  );
}
