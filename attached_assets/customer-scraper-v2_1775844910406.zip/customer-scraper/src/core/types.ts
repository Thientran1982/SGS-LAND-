// ================================================================
// TYPES — Customer Scraper v2.0
// Schema thống nhất cho 10 nguồn BĐS
// ================================================================

export type SourceId =
  | 'chotot'
  | 'novaland'
  | 'vinhomes'
  | 'masterise'
  | 'sungroup'
  | 'sonkim'
  | 'globalcity'
  | 'aquacity'
  | 'namlong'
  | 'izumi';

export interface Lead {
  // ── Định danh ──────────────────────────────────────
  id:         string;         // {source}-{originalId}
  source:     SourceId;
  originalId: string;
  sourceUrl:  string;

  // ── Thông tin cá nhân ──────────────────────────────
  name:       string | null;
  phone:      string | null;  // chuẩn hoá: 0xxxxxxxxx
  phoneRaw:   string | null;  // raw từ nguồn
  email:      string | null;

  // ── Quan tâm BĐS ───────────────────────────────────
  projectName:     string | null;  // tên dự án quan tâm
  propertyType:    string | null;  // căn hộ, nhà phố, đất nền
  budget:          number | null;  // VND
  budgetText:      string | null;  // "5-10 tỷ"
  location:        string | null;  // quận/huyện
  area:            number | null;  // m²

  // ── Meta ───────────────────────────────────────────
  postedAt:   string | null;
  scrapedAt:  string;
  notes:      string | null;
  images:     string[];
  rawData:    Record<string, any>;
}

export interface ScraperConfig {
  // Proxy
  proxyUrl?:    string;   // ScraperAPI: http://api.scraperapi.com?api_key=KEY&url=
  scraperApiKey?: string; // ScraperAPI key

  // Playwright
  usePlaywright: boolean;
  headless:      boolean;
  timeout:       number;

  // Rate limiting
  delayMs:    number;
  maxRetries: number;

  // Output
  outputDir:  string;

  // Filters
  regions?:   string[];  // ['HCM', 'BinhDuong', 'DongNai']
  maxLeads?:  number;

  // Push về SGSLand CRM
  sgsland?: {
    baseUrl:  string;
    token:    string;
    enabled:  boolean;
  };
}

export interface ScrapeResult {
  source:     SourceId;
  leads:      Lead[];
  total:      number;
  failed:     number;
  durationMs: number;
  errors:     string[];
}

export interface MultiScrapeResult {
  scrapedAt:  string;
  durationMs: number;
  totalLeads: number;
  uniqueLeads: number;
  bySource:   Record<SourceId, number>;
  leads:      Lead[];
  errors:     Record<SourceId, string[]>;
}

// Normalize phone VN về dạng chuẩn 0xxxxxxxxx
export function normalizePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  // Bỏ tất cả ký tự không phải số
  let digits = raw.replace(/\D/g, '');
  // +84 → 0
  if (digits.startsWith('84') && digits.length === 11) digits = '0' + digits.slice(2);
  // Phải đủ 10 số và bắt đầu bằng 0
  if (digits.length === 10 && digits.startsWith('0')) return digits;
  return null;
}

// Tạo ID duy nhất
export function makeId(source: SourceId, raw: string | number): string {
  return `${source}-${String(raw).replace(/\W/g, '')}`;
}
