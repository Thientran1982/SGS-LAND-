# SGSLand Customer Scraper v3.0

## ScraperAPI Key đã có: eb3e5dcf652e80be98dace572f17b629

## Cài đặt (Replit)
```bash
npm install
```

## Cách chạy

### Tất cả nguồn
```bash
npm start
```

### Chỉ ChợTốt (nhanh nhất, SĐT thực)
```bash
npm run chotot
# Hoặc filter region + category
tsx src/main.ts --only=chotot --regions=HCM,DongNai --cats=can_ho,dat_nen,biet_thu
```

### 9 Chủ đầu tư
```bash
npm run developers
```

### Push về SGSLand CRM
```bash
SGS_TOKEN=your_token npm run push
```

## ChợTốt API

```
# Danh sách (không cần proxy)
GET gateway.chotot.com/v1/public/ad-listing
  ?cg=1020        # căn hộ
  &region_v2=13   # HCM
  &limit=50
  &st=k           # bán
  &f=p            # cá nhân

# Detail — CÓ SĐT THỰC (không cần proxy)
GET gateway.chotot.com/v2/public/ad-listing/{ad_id}.json
→ { phone: "0901234567", contact_name: "Nguyễn Văn A" }
```

## Categories ChợTốt
| Code  | Loại BĐS        |
|-------|-----------------|
| 1000  | Nhà đất (tất cả)|
| 1010  | Biệt thự        |
| 1020  | Căn hộ          |
| 1030  | Nhà mặt phố     |
| 1040  | Đất nền         |
| 1060  | Nhà trọ         |
| 1080  | Văn phòng       |

## Regions ChợTốt
| Key       | Tên             |
|-----------|-----------------|
| HCM       | TP. HCM (13)    |
| HN        | Hà Nội (12)     |
| DaNang    | Đà Nẵng (14)   |
| BinhDuong | Bình Dương (19) |
| DongNai   | Đồng Nai (60)   |
| VungTau   | Vũng Tàu (50)   |

## Output
- `output/leads_*.csv` — Excel-ready, UTF-8 BOM
- `output/leads_*.json` — Full JSON với rawData
