// ================================================================
// SCRAPER ENGINE v3.0
// ScraperAPI key: eb3e5dcf652e80be98dace572f17b629
// ================================================================

export const SCRAPER_API_KEY = process.env.SCRAPER_API_KEY || 'eb3e5dcf652e80be98dace572f17b629';
export const SCRAPER_BASE    = 'http://api.scraperapi.com';

// ── Types ─────────────────────────────────────────────────────
export interface Lead {
  id:           string;
  source:       string;
  sourceUrl:    string;
  name:         string | null;
  phone:        string | null;   // normalized: 0xxxxxxxxx
  phoneRaw:     string | null;
  email:        string | null;
  project:      string | null;
  propertyType: string | null;
  budget:       string | null;
  location:     string | null;
  area:         number | null;
  postedAt:     string | null;
  scrapedAt:    string;
  notes:        string | null;
  raw:          any;
}

// ── Normalize phone VN ────────────────────────────────────────
export function normalizePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  let d = String(raw).replace(/[\s.\-()]/g, '');
  if (d.startsWith('+84')) d = '0' + d.slice(3);
  if (d.startsWith('84') && d.length === 11) d = '0' + d.slice(2);
  // Loại bỏ ký tự không phải số
  d = d.replace(/\D/g, '');
  if (d.length === 10 && /^0[3-9]/.test(d)) return d;
  return null;
}

export function formatPhone(p: string): string {
  return p.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
}

export function extractPhones(text: string): string[] {
  const raw = text.match(/(?:\+84|0084|0)[3-9]\d{8}/g) || [];
  const clean = [...new Set(raw.map(p => normalizePhone(p)).filter(Boolean))] as string[];
  return clean;
}

export function extractEmails(text: string): string[] {
  const m = text.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || [];
  return [...new Set(m)].filter(e =>
    !/(example|domain|noreply|no-reply|test\.|sample)/i.test(e)
  );
}

// ── HTTP với ScraperAPI ───────────────────────────────────────
export async function scrapeUrl(
  targetUrl: string,
  options: {
    render?:  boolean;   // true = JS rendering (React/Vue sites)
    json?:    boolean;   // parse JSON response
    country?: string;    // country code (vn)
    retries?: number;
  } = {}
): Promise<string> {
  const params = new URLSearchParams({
    api_key:      SCRAPER_API_KEY,
    url:          targetUrl,
    country_code: options.country || 'vn',
  });
  if (options.render) params.set('render', 'true');

  const proxyUrl = `${SCRAPER_BASE}/?${params}`;
  const maxRetries = options.retries ?? 3;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const res = await fetch(proxyUrl, {
        headers: {
          'Accept': options.json
            ? 'application/json'
            : 'text/html,application/xhtml+xml,*/*',
          'Accept-Language': 'vi-VN,vi;q=0.9',
        },
        signal: AbortSignal.timeout(45_000),
      });

      if (res.status === 403 || res.status === 429) {
        console.warn(`  [scraper] ${res.status} — chờ ${attempt * 2}s`);
        await sleep(attempt * 2000);
        continue;
      }

      if (!res.ok) throw new Error(`HTTP ${res.status}: ${targetUrl}`);
      return await res.text();

    } catch (e: any) {
      if (attempt === maxRetries) throw e;
      console.warn(`  [scraper] Retry ${attempt}/${maxRetries}: ${e.message}`);
      await sleep(attempt * 1500);
    }
  }
  throw new Error(`Max retries: ${targetUrl}`);
}

export async function scrapeJSON<T = any>(url: string, opts = {}): Promise<T> {
  const text = await scrapeUrl(url, { ...opts, json: true });
  return JSON.parse(text) as T;
}

// ── Direct fetch (không qua proxy) cho API public ─────────────
export async function fetchJSON<T = any>(url: string, retries = 3): Promise<T> {
  for (let i = 1; i <= retries; i++) {
    try {
      const r = await fetch(url, {
        headers: {
          'Accept':          'application/json',
          'Accept-Language': 'vi-VN,vi;q=0.9',
          'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
        signal: AbortSignal.timeout(20_000),
      });
      if (r.status === 429) { await sleep(i * 2000); continue; }
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return await r.json() as T;
    } catch (e: any) {
      if (i === retries) throw e;
      await sleep(i * 1000);
    }
  }
  throw new Error(`fetch failed: ${url}`);
}

export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
