// ================================================================
// ChợTốt Adapter v3.0
// API đã xác nhận: gateway.chotot.com
// ✅ Lấy được SĐT thực từ /v2/public/ad-listing/{id}.json
// ================================================================

import { Lead, normalizePhone, fetchJSON, sleep } from '../core/engine.js';

export const CG = {
  all:'1000', can_ho:'1020', biet_thu:'1010', nha_mat_pho:'1030',
  dat_nen:'1040', nha_tro:'1060', van_phong:'1080',
} as const;

export const REGION = {
  HCM:'13', HN:'12', DaNang:'14', BinhDuong:'19',
  DongNai:'60', HaiPhong:'15', CanTho:'29', VungTau:'50',
} as const;

interface Ad {
  ad_id:number; list_id:number; account_id:number; account_oid:string;
  account_name:string; subject:string; body:string; category:number;
  area_name:string; region_name:string; ward_name:string;
  company_ad:boolean; type:string; price:number; price_string:string;
  image:string; area:number; date:string;
  // detail-only
  phone?:string; contact_name?:string; email?:string;
  params?:Array<{label:string;value:string}>;
}

const TYPE_MAP: Record<number,string> = {
  1000:'Nhà đất', 1010:'Biệt thự', 1020:'Căn hộ',
  1030:'Nhà mặt phố', 1040:'Đất nền', 1060:'Nhà trọ', 1080:'Văn phòng',
};

function adToLead(ad: Ad): Lead {
  const phone = normalizePhone(ad.phone);
  const loc   = [ad.ward_name, ad.area_name, ad.region_name].filter(Boolean).join(', ');
  return {
    id:`chotot-${ad.ad_id}`, source:'chotot',
    sourceUrl:`https://www.chotot.com/${ad.ad_id}.htm`,
    name:ad.contact_name || ad.account_name || null,
    phone, phoneRaw:ad.phone||null, email:ad.email||null,
    project:ad.subject||null,
    propertyType:TYPE_MAP[ad.category]||'Nhà đất',
    budget:ad.price_string||null, location:loc||null,
    area:ad.area||null, postedAt:ad.date||null,
    scrapedAt:new Date().toISOString(),
    notes:(ad.body||'').substring(0,200)||null,
    raw:{ad_id:ad.ad_id, account_oid:ad.account_oid, category:ad.category},
  };
}

export class ChototScraper {
  private readonly LIST   = 'https://gateway.chotot.com/v1/public/ad-listing';
  private readonly DETAIL = 'https://gateway.chotot.com/v2/public/ad-listing';

  private listUrl(cg:string, region:string, limit=50, offset=0) {
    return `${this.LIST}?cg=${cg}&region_v2=${region}&limit=${limit}&offset=${offset}&st=k&f=p&w=1`;
  }

  async getDetail(adId:number): Promise<Ad|null> {
    try {
      const d = await fetchJSON<{ad:Ad}>(`${this.DETAIL}/${adId}.json`);
      return d.ad || null;
    } catch { return null; }
  }

  async scrape(options:{
    regions?:string[]; categories?:string[];
    maxPerCombo?:number; enrichPhone?:boolean;
    enrichMax?:number; delayMs?:number;
    onProgress?:(m:string)=>void;
  }={}): Promise<Lead[]> {
    const {
      regions=['HCM','DongNai','BinhDuong'],
      categories=['can_ho','dat_nen','all'],
      maxPerCombo=50, enrichPhone=true,
      enrichMax=50, delayMs=600,
      onProgress,
    } = options;

    const log = (m:string) => { console.log(m); onProgress?.(m); };
    const all: Lead[] = [];

    // Phase 1: danh sách
    for (const rKey of regions) {
      const rCode = REGION[rKey as keyof typeof REGION];
      if (!rCode) continue;
      for (const cKey of categories) {
        const cCode = CG[cKey as keyof typeof CG];
        if (!cCode) continue;
        await sleep(delayMs);
        try {
          const data = await fetchJSON<{total:number;ads:Ad[]}>(
            this.listUrl(cCode, rCode, Math.min(maxPerCombo, 50))
          );
          log(`  [ChợTốt] ${rKey}/${cKey}: ${data.ads.length}/${data.total} ads`);
          data.ads.forEach(ad => all.push(adToLead(ad)));
          if (data.total > 50 && maxPerCombo > 50) {
            await sleep(delayMs);
            const d2 = await fetchJSON<{ads:Ad[]}>(this.listUrl(cCode,rCode,50,50)).catch(()=>({ads:[]}));
            d2.ads.forEach(ad => all.push(adToLead(ad)));
          }
        } catch(e:any) { log(`  [ChợTốt] ❌ ${rKey}/${cKey}: ${e.message}`); }
      }
    }
    log(`\n[ChợTốt] Phase 1: ${all.length} leads`);

    // Phase 2: enrich SĐT
    if (enrichPhone && all.length > 0) {
      const toEnrich = all.slice(0, enrichMax);
      log(`[ChợTốt] Enriching SĐT cho ${toEnrich.length} leads...`);
      for (let i=0; i<toEnrich.length; i++) {
        await sleep(delayMs / 2);
        const lead  = toEnrich[i];
        const adId  = Number(lead.id.replace('chotot-',''));
        const detail = await this.getDetail(adId);
        if (detail) {
          lead.phone    = normalizePhone(detail.phone);
          lead.phoneRaw = detail.phone || null;
          lead.name     = detail.contact_name || detail.account_name || lead.name;
          lead.email    = detail.email || lead.email;
          if (lead.phone) log(`  📱 [${i+1}/${toEnrich.length}] ${lead.name}: ${lead.phone}`);
          if (detail.params) {
            const ap = detail.params.find(p => /diện tích/i.test(p.label));
            if (ap) { const n=parseFloat(ap.value.replace(/[^\d.]/g,'')); if(!isNaN(n)) lead.area=n; }
          }
        }
      }
    }

    // Dedup
    const seen = new Set<string>();
    const unique = all.filter(l => {
      const k = l.phone || l.id;
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });

    log(`[ChợTốt] ✅ ${unique.length} unique | SĐT: ${unique.filter(l=>l.phone).length}`);
    return unique;
  }
}
