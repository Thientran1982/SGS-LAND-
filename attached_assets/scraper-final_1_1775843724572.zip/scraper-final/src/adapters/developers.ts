// ================================================================
// Developer Sites Adapter
// Novaland, Vinhomes, Masterise, SunGroup, SonKim,
// GlobalCity, AquaCity, NamLong, Izumi
//
// Phương pháp:
// 1. scrapeUrl(url, render=true) → HTML với JS đã render
// 2. Tìm phone/email trong HTML (hotline, tư vấn)
// 3. Parse form fields → ghi nhận fields quan tâm
// ================================================================

import {
  Lead, normalizePhone, extractPhones, extractEmails,
  scrapeUrl, sleep
} from '../core/engine.js';

interface SiteConfig {
  id:         string;
  name:       string;
  domain:     string;
  urls:       string[];       // trang cần scrape
  render:     boolean;        // cần JS rendering?
  projectMap: string[];       // tên dự án của site
}

const SITES: SiteConfig[] = [
  {
    id: 'novaland', name: 'Novaland', domain: 'novaland.com.vn',
    render: true,
    urls: [
      'https://www.novaland.com.vn/du-an/aqua-city',
      'https://www.novaland.com.vn/du-an/grand-manhattan',
      'https://www.novaland.com.vn/dang-ky',
      'https://www.novaland.com.vn/lien-he',
    ],
    projectMap: ['Aqua City','Grand Manhattan','NovaWorld Phan Thiết','The Park Avenue'],
  },
  {
    id: 'vinhomes', name: 'Vinhomes', domain: 'vinhomes.vn',
    render: true,
    urls: [
      'https://vinhomes.vn/grand-park',
      'https://vinhomes.vn/central-park',
      'https://vinhomes.vn/lien-he',
    ],
    projectMap: ['Vinhomes Grand Park','Vinhomes Central Park','Vinhomes Ocean Park'],
  },
  {
    id: 'masterise', name: 'Masterise Homes', domain: 'masterisehomes.com',
    render: true,
    urls: [
      'https://masterisehomes.com/du-an/the-global-city/',
      'https://masterisehomes.com/du-an/grand-marina/',
      'https://masterisehomes.com/contact/',
    ],
    projectMap: ['The Global City','Grand Marina','Masteri Centre Point'],
  },
  {
    id: 'sungroup', name: 'Sun Group', domain: 'sungroup.com.vn',
    render: false,
    urls: [
      'https://sungroup.com.vn/lien-he/',
      'https://sungroup.com.vn/du-an/',
    ],
    projectMap: ['Sun Premier Village','Sun Grand City','Sun Tropical Village'],
  },
  {
    id: 'sonkim', name: 'Son Kim Land', domain: 'sonkimland.com.vn',
    render: false,
    urls: [
      'https://sonkimland.com.vn/lien-he/',
      'https://sonkimland.com.vn/du-an/',
    ],
    projectMap: ['The Opera Residence','Léman Luxury Apartments','Gloria Residences'],
  },
  {
    id: 'globalcity', name: 'The Global City', domain: 'theglobalcity.vn',
    render: true,
    urls: [
      'https://theglobalcity.vn/',
      'https://theglobalcity.vn/lien-he/',
    ],
    projectMap: ['The Global City Phase 1','The Global City Phase 2'],
  },
  {
    id: 'aquacity', name: 'Aqua City', domain: 'aquacity.com.vn',
    render: true,
    urls: [
      'https://aquacity.com.vn/',
      'https://aquacity.com.vn/lien-he/',
    ],
    projectMap: ['Aqua City - The Fleet','Aqua City - Thủy Đặc Sản','Aqua City - Sun Harbor'],
  },
  {
    id: 'namlong', name: 'Nam Long Land', domain: 'namlongland.com.vn',
    render: false,
    urls: [
      'https://namlongland.com.vn/lien-he/',
      'https://namlongland.com.vn/du-an/izumi-city/',
    ],
    projectMap: ['Izumi City','Flora Fuji','Valora Kikyo','Akari City'],
  },
  {
    id: 'izumi', name: 'Izumi City', domain: 'izumicity.com.vn',
    render: true,
    urls: [
      'https://izumicity.com.vn/',
      'https://izumicity.com.vn/lien-he/',
    ],
    projectMap: ['Izumi City - Phân khu Nhật Bản','Izumi City Central Park'],
  },
];

// Hotline chính thức (public) của từng chủ đầu tư
const OFFICIAL_HOTLINES: Record<string, Array<{name:string; phone:string; role:string}>> = {
  novaland:   [{name:'Hotline Novaland Group',  phone:'1900636666', role:'Tư vấn chính'}],
  vinhomes:   [{name:'Hotline Vinhomes',        phone:'1800545454', role:'Tư vấn dự án'}],
  masterise:  [{name:'Hotline Masterise Homes', phone:'19001818',   role:'Tư vấn chính'}],
  sungroup:   [{name:'Hotline Sun Group BĐS',   phone:'1900545488', role:'Kinh doanh'}],
  sonkim:     [{name:'Son Kim Land Hotline',    phone:'02822002200',role:'Kinh doanh'}],
  globalcity: [{name:'Hotline The Global City', phone:'1800888899', role:'Tư vấn dự án'}],
  aquacity:   [{name:'Hotline Aqua City',       phone:'19002099',   role:'Tư vấn chính'}],
  namlong:    [{name:'Nam Long Land Hotline',   phone:'1800599924', role:'Kinh doanh'}],
  izumi:      [{name:'Hotline Izumi City',      phone:'02873077777',role:'Tư vấn dự án'}],
};

export class DeveloperScraper {
  constructor(private readonly delayMs = 1500) {}

  async scrapeAll(options: {
    siteIds?:    string[];
    onProgress?: (msg: string) => void;
  } = {}): Promise<Lead[]> {
    const { siteIds, onProgress } = options;
    const log = (msg: string) => { console.log(msg); onProgress?.(msg); };

    const sites = siteIds
      ? SITES.filter(s => siteIds.includes(s.id))
      : SITES;

    const allLeads: Lead[] = [];

    for (const site of sites) {
      log(`\n[${site.name}] Bắt đầu scrape ${site.urls.length} trang...`);
      const siteLeads = await this.scrapeSite(site, log);
      allLeads.push(...siteLeads);
      log(`[${site.name}] ✅ ${siteLeads.length} contacts (${siteLeads.filter(l=>l.phone).length} có SĐT)`);
      await sleep(this.delayMs);
    }

    return allLeads;
  }

  private async scrapeSite(site: SiteConfig, log: (m:string)=>void): Promise<Lead[]> {
    const leads: Lead[] = [];

    // Phase 1: Hotline chính thức (luôn có)
    const hotlines = OFFICIAL_HOTLINES[site.id] || [];
    for (const h of hotlines) {
      const phone = normalizePhone(h.phone.replace(/[^0-9]/g, ''));
      leads.push({
        id:           `${site.id}-hotline-${h.phone}`,
        source:       site.id,
        sourceUrl:    `https://${site.domain}`,
        name:         h.name,
        phone,
        phoneRaw:     h.phone,
        email:        null,
        project:      site.projectMap[0] || site.name,
        propertyType: null,
        budget:       null,
        location:     'TP. Hồ Chí Minh',
        area:         null,
        postedAt:     null,
        scrapedAt:    new Date().toISOString(),
        notes:        `${h.role} — hotline chính thức ${site.domain}`,
        raw:          { type: 'hotline', role: h.role },
      });
      log(`  📞 Hotline ${site.name}: ${h.phone}`);
    }

    // Phase 2: Scrape trang web qua ScraperAPI
    for (const url of site.urls) {
      await sleep(this.delayMs);
      try {
        log(`  [${site.name}] Scraping: ${url}`);
        const html = await scrapeUrl(url, { render: site.render });
        const extracted = this.parseHTML(html, url, site);
        if (extracted.length > 0) {
          log(`  [${site.name}] Found ${extracted.length} contacts trong HTML`);
          extracted.forEach(l => {
            if (l.phone) log(`  📱 ${l.name || 'N/A'}: ${l.phone}`);
          });
          leads.push(...extracted);
        }
      } catch (e: any) {
        log(`  [${site.name}] ⚠️ ${url}: ${e.message}`);
        // Tiếp tục với URL tiếp theo
      }
    }

    // Dedup phone trong site
    const seen = new Set<string>();
    return leads.filter(l => {
      const k = l.phone || l.id;
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
  }

  private parseHTML(html: string, pageUrl: string, site: SiteConfig): Lead[] {
    const leads: Lead[] = [];

    // Extract phones từ HTML
    const phones = extractPhones(html);
    const emails = extractEmails(html);

    // Tìm tên trang
    const titleM = html.match(/<title[^>]*>([^<]{3,80})<\/title>/i);
    const pageTitle = titleM?.[1]?.trim() || site.name;

    // Tìm tên agent/người tư vấn gần phone number
    // Pattern: tên + số điện thoại trong vài dòng
    const agentPatterns = [
      /(?:(?:Chuyên viên|Tư vấn|KD|Kinh doanh|Agent|Môi giới|Liên hệ)[:\s]+([^\n<]{3,40})\s*[\n<]+[^<]*?)(0[3-9]\d{8})/gi,
      /([\w\s]{5,30})(?:\s*[-:|]\s*)(0[3-9]\d{8})/g,
    ];

    const foundPairs: Array<{name:string; phone:string}> = [];
    for (const pat of agentPatterns) {
      let m;
      while ((m = pat.exec(html)) !== null) {
        const name  = m[1]?.trim().replace(/<[^>]+>/g, '').trim();
        const phone = normalizePhone(m[2]);
        if (phone && name && name.length > 2 && name.length < 40) {
          foundPairs.push({ name, phone });
        }
      }
    }

    // Tạo leads từ found pairs
    foundPairs.slice(0, 10).forEach((pair, i) => {
      leads.push({
        id:           `${site.id}-html-${i}-${pair.phone}`,
        source:       site.id,
        sourceUrl:    pageUrl,
        name:         pair.name,
        phone:        pair.phone,
        phoneRaw:     pair.phone,
        email:        emails[i] || null,
        project:      pageTitle,
        propertyType: null,
        budget:       null,
        location:     'TP. Hồ Chí Minh',
        area:         null,
        postedAt:     null,
        scrapedAt:    new Date().toISOString(),
        notes:        `Extracted from ${pageUrl}`,
        raw:          { extractedFrom: 'html', pageUrl },
      });
    });

    // Thêm phones đơn không có tên
    const usedPhones = new Set(foundPairs.map(p=>p.phone));
    phones.filter(p => !usedPhones.has(p)).slice(0, 5).forEach((phone, i) => {
      leads.push({
        id:           `${site.id}-phone-${i}-${phone}`,
        source:       site.id,
        sourceUrl:    pageUrl,
        name:         null,
        phone,
        phoneRaw:     phone,
        email:        emails[foundPairs.length + i] || null,
        project:      pageTitle,
        propertyType: null,
        budget:       null,
        location:     null,
        area:         null,
        postedAt:     null,
        scrapedAt:    new Date().toISOString(),
        notes:        `Phone từ ${site.domain}`,
        raw:          { extractedFrom: 'html-phone-only' },
      });
    });

    return leads;
  }
}
