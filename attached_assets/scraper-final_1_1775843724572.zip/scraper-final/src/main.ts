#!/usr/bin/env node
// ================================================================
// SGSLand Multi-Source Customer Scraper v3.0
// ScraperAPI Key: eb3e5dcf652e80be98dace572f17b629
//
// Chạy:
//   npm start                       # tất cả nguồn
//   npm start -- --only=chotot      # chỉ ChợTốt
//   npm start -- --only=developers  # 9 CĐT
//   npm start -- --regions=HCM,DongNai --cats=can_ho,dat_nen
//   npm start -- --push             # push về SGSLand CRM
// ================================================================

import { ChototScraper } from './adapters/chotot.js';
import { DeveloperScraper } from './adapters/developers.js';
import { Lead, formatPhone, sleep } from './core/engine.js';
import * as fs   from 'fs';
import * as path from 'path';

// ── Parse CLI args ────────────────────────────────────────────
function parseArgs(): Record<string,string> {
  const a: Record<string,string> = {};
  for (const arg of process.argv.slice(2)) {
    if (arg.startsWith('--')) {
      const [k, v = 'true'] = arg.slice(2).split('=');
      a[k] = v;
    }
  }
  return a;
}

// ── Dedup leads by phone ─────────────────────────────────────
function dedup(leads: Lead[]): Lead[] {
  const seen = new Set<string>();
  return leads.filter(l => {
    const k = l.phone || l.id;
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
}

// ── Print summary ─────────────────────────────────────────────
function printSummary(leads: Lead[]): void {
  const withPhone  = leads.filter(l => l.phone);
  const withEmail  = leads.filter(l => l.email);
  const bySrc: Record<string, number> = {};
  leads.forEach(l => { bySrc[l.source] = (bySrc[l.source]||0)+1; });

  console.log('\n' + '═'.repeat(60));
  console.log('  KẾT QUẢ SCRAPE');
  console.log('═'.repeat(60));
  console.log(`  Tổng:          ${leads.length} leads`);
  console.log(`  Có SĐT:        ${withPhone.length} (${Math.round(withPhone.length/leads.length*100)}%)`);
  console.log(`  Có email:      ${withEmail.length}`);
  console.log('');
  console.log('  Theo nguồn:');
  Object.entries(bySrc).sort(([,a],[,b])=>b-a).forEach(([src,n]) => {
    const srcLeads = leads.filter(l=>l.source===src);
    const phones   = srcLeads.filter(l=>l.phone).length;
    console.log(`    ${src.padEnd(14)} ${n} leads, ${phones} SĐT`);
  });

  if (withPhone.length > 0) {
    console.log('\n' + '─'.repeat(60));
    console.log('  📱 DANH SÁCH SĐT:');
    console.log('─'.repeat(60));
    withPhone.slice(0, 30).forEach((l, i) => {
      const name    = (l.name || 'Ẩn danh').padEnd(22);
      const phone   = formatPhone(l.phone!).padEnd(14);
      const source  = l.source.padEnd(12);
      const project = (l.project || '').substring(0, 20);
      console.log(`  ${String(i+1).padStart(2)}. ${name} ${phone} [${source}] ${project}`);
    });
    if (withPhone.length > 30) {
      console.log(`  ... và ${withPhone.length - 30} leads khác`);
    }
  }
  console.log('═'.repeat(60));
}

// ── Export CSV ───────────────────────────────────────────────
function exportCSV(leads: Lead[], dir: string): string {
  fs.mkdirSync(dir, { recursive: true });
  const ts   = new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
  const file = path.join(dir, `leads_${ts}.csv`);

  const esc = (v: any) => {
    if (v==null) return '';
    const s = String(v);
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? '"' + s.replace(/"/g,'""').replace(/\n/g,' ') + '"'
      : s;
  };

  const headers = ['nguon','ten','so_dien_thoai','sdt_format','email',
    'du_an','loai_bds','ngan_sach','dien_tich','vi_tri',
    'ghi_chu','thoi_gian_dang','scraped_luc','link'];

  const rows = leads.map(l => [
    l.source, l.name||'', l.phone||'',
    l.phone ? formatPhone(l.phone) : '',
    l.email||'', l.project||'', l.propertyType||'',
    l.budget||'', l.area ? l.area+'m²' : '', l.location||'',
    (l.notes||'').substring(0,100),
    l.postedAt||'', l.scrapedAt, l.sourceUrl||'',
  ].map(esc).join(','));

  fs.writeFileSync(file, '\uFEFF' + [headers.join(','), ...rows].join('\n'), 'utf-8');
  console.log(`💾 CSV  → ${file} (${leads.length} rows)`);
  return file;
}

// ── Export JSON ──────────────────────────────────────────────
function exportJSON(leads: Lead[], dir: string): string {
  fs.mkdirSync(dir, { recursive: true });
  const ts   = new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
  const file = path.join(dir, `leads_${ts}.json`);

  const data = {
    scrapedAt: new Date().toISOString(),
    total:     leads.length,
    withPhone: leads.filter(l=>l.phone).length,
    withEmail: leads.filter(l=>l.email).length,
    bySrc:     leads.reduce((acc,l) => { acc[l.source]=(acc[l.source]||0)+1; return acc; }, {} as Record<string,number>),
    leads,
  };

  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
  console.log(`💾 JSON → ${file}`);
  return file;
}

// ── Push về SGSLand CRM ──────────────────────────────────────
async function pushToSgsland(leads: Lead[], token: string, baseUrl = 'https://sgsland.vn'): Promise<void> {
  const phoneLeads = leads.filter(l => l.phone || l.email);
  console.log(`\n[SGSLand] Pushing ${phoneLeads.length} leads về CRM...`);

  let ok = 0, fail = 0;
  for (const lead of phoneLeads) {
    try {
      const r = await fetch(`${baseUrl}/api/leads`, {
        method:  'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type':  'application/json',
        },
        body: JSON.stringify({
          name:   lead.name || 'Khách quan tâm',
          phone:  lead.phone,
          email:  lead.email,
          source: lead.source,
          stage:  'NEW',
          tags:   [lead.project, lead.propertyType].filter(Boolean) as string[],
          notes:  [
            lead.project   && `Dự án: ${lead.project}`,
            lead.budget    && `Ngân sách: ${lead.budget}`,
            lead.location  && `Khu vực: ${lead.location}`,
            lead.notes,
            `Nguồn: ${lead.sourceUrl}`,
          ].filter(Boolean).join('\n'),
          preferences: {
            regions:       lead.location ? [lead.location] : [],
            propertyTypes: lead.propertyType ? [lead.propertyType] : [],
          },
        }),
      });

      if (r.ok) {
        ok++;
        console.log(`  ✅ ${lead.name||'Lead'} (${lead.phone}) → CRM`);
      } else {
        fail++;
        console.warn(`  ⚠️ ${lead.phone}: HTTP ${r.status}`);
      }
    } catch (e: any) {
      fail++;
      console.warn(`  ❌ ${lead.phone}: ${e.message}`);
    }
    await sleep(200);
  }

  console.log(`[SGSLand] Done: ${ok} pushed, ${fail} failed`);
}

// ── MAIN ─────────────────────────────────────────────────────
async function main(): Promise<void> {
  const args = parseArgs();
  const dir  = args.output || './output';

  console.log('═'.repeat(60));
  console.log('  SGSLand Multi-Source Customer Scraper v3.0');
  console.log(`  ScraperAPI Key: eb3e5dcf...${process.env.SCRAPER_API_KEY?.slice(-6) || '629'}`);
  console.log('═'.repeat(60) + '\n');

  const allLeads: Lead[] = [];

  // ── ChợTốt ────────────────────────────────────────────────
  if (!args.only || args.only === 'chotot' || args.only === 'all') {
    console.log('▶ ChợTốt...');
    const scraper = new ChototScraper();
    const regions = args.regions?.split(',') || ['HCM', 'DongNai', 'BinhDuong'];
    const cats    = args.cats?.split(',')    || ['can_ho', 'dat_nen', 'all'];

    const leads = await scraper.scrape({
      regions,
      categories:  cats,
      maxPerCombo: 50,
      enrichPhone: args.noenrich !== 'true',
      enrichMax:   parseInt(args.enrichmax || '50'),
      delayMs:     parseInt(args.delay || '600'),
      onProgress:  msg => process.stdout.write('\r' + msg.substring(0,80).padEnd(80)),
    });
    console.log('');
    allLeads.push(...leads);
  }

  // ── Developer sites ───────────────────────────────────────
  if (!args.only || args.only === 'developers' || args.only === 'all') {
    console.log('\n▶ Các chủ đầu tư...');
    const scraper  = new DeveloperScraper(parseInt(args.delay || '1500'));
    const siteIds  = args.sites?.split(',');
    const leads    = await scraper.scrapeAll({
      siteIds,
      onProgress: msg => console.log(msg),
    });
    allLeads.push(...leads);
  }

  // ── Dedup & output ────────────────────────────────────────
  const unique = dedup(allLeads);
  printSummary(unique);

  exportCSV(unique, dir);
  exportJSON(unique, dir);

  // ── Push về SGSLand CRM ───────────────────────────────────
  const token = args.token || process.env.SGS_TOKEN;
  if (args.push === 'true' && token) {
    await pushToSgsland(unique, token, args.sgsUrl || process.env.SGS_BASE_URL || 'https://sgsland.vn');
  } else if (args.push === 'true' && !token) {
    console.warn('\n⚠️ Push bật nhưng chưa có SGS_TOKEN. Set: SGS_TOKEN=your_jwt_token');
  }

  console.log(`\n✅ Xong! Files lưu tại: ${path.resolve(dir)}/`);
}

main().catch(e => {
  console.error('Fatal:', e);
  process.exit(1);
});
