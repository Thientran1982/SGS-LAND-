// ================================================================
// SCHEDULER — chạy scraper định kỳ + phát hiện thay đổi
// ================================================================

import fs   from 'fs';
import path from 'path';
import { SgsLandScraper } from './scraper.js';
import { exportAll }       from './exporters.js';
import type { ScrapeResult, Listing } from './types.js';

interface SchedulerOptions {
  intervalMs:    number;    // mỗi bao lâu chạy 1 lần (ms)
  outputDir:     string;
  stateFile?:    string;    // lưu state để so sánh
  onNewListings?:   (listings: Listing[]) => void;
  onPriceChanges?:  (changes: PriceChange[]) => void;
  onSoldListings?:  (listings: Listing[]) => void;
}

interface PriceChange {
  listing: Listing;
  oldPrice: number;
  newPrice: number;
  changePercent: number;
}

interface SchedulerState {
  lastRunAt: string;
  listingMap: Record<string, { price: number; status: string; updatedAt: string }>;
}

// ── Change Detector ───────────────────────────────────────────────

class ChangeDetector {
  private state: SchedulerState;
  private stateFile: string;

  constructor(stateFile: string) {
    this.stateFile = stateFile;
    this.state     = this.loadState();
  }

  private loadState(): SchedulerState {
    if (fs.existsSync(this.stateFile)) {
      try {
        return JSON.parse(fs.readFileSync(this.stateFile, 'utf-8'));
      } catch { /* ignore */ }
    }
    return { lastRunAt: '', listingMap: {} };
  }

  private saveState(): void {
    fs.mkdirSync(path.dirname(this.stateFile), { recursive: true });
    fs.writeFileSync(this.stateFile, JSON.stringify(this.state, null, 2));
  }

  detect(listings: Listing[]): {
    newListings:    Listing[];
    priceChanges:   PriceChange[];
    soldListings:   Listing[];
  } {
    const newListings:  Listing[]      = [];
    const priceChanges: PriceChange[]  = [];
    const soldListings: Listing[]      = [];

    const currentIds = new Set(listings.map(l => l.id));

    for (const listing of listings) {
      const prev = this.state.listingMap[listing.id];

      if (!prev) {
        // Listing mới xuất hiện
        newListings.push(listing);
      } else if (prev.price !== listing.price && listing.price > 0) {
        // Giá thay đổi
        const changePercent = ((listing.price - prev.price) / prev.price) * 100;
        priceChanges.push({ listing, oldPrice: prev.price, newPrice: listing.price, changePercent });
      }

      if (prev?.status === 'AVAILABLE' && listing.status !== 'AVAILABLE') {
        soldListings.push(listing);
      }
    }

    // Cập nhật state
    this.state.lastRunAt = new Date().toISOString();
    this.state.listingMap = {};
    for (const l of listings) {
      this.state.listingMap[l.id] = {
        price:     l.price,
        status:    l.status,
        updatedAt: l.updatedAt,
      };
    }
    this.saveState();

    return { newListings, priceChanges, soldListings };
  }
}

// ── Scheduler Class ───────────────────────────────────────────────

export class ScraperScheduler {
  private scraper:  SgsLandScraper;
  private opts:     SchedulerOptions;
  private detector: ChangeDetector;
  private timer:    ReturnType<typeof setInterval> | null = null;
  private runCount  = 0;
  private isRunning = false;

  constructor(scraper: SgsLandScraper, opts: SchedulerOptions) {
    this.scraper  = scraper;
    this.opts     = opts;
    const stateFile = opts.stateFile ?? path.join(opts.outputDir, '.state.json');
    this.detector = new ChangeDetector(stateFile);
  }

  start(): void {
    console.log(`⏰ Scheduler khởi động — interval: ${this.opts.intervalMs / 60_000} phút`);
    this.run(); // Chạy ngay lần đầu
    this.timer = setInterval(() => this.run(), this.opts.intervalMs);
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      console.log('⏹️  Scheduler dừng.');
    }
  }

  private async run(): Promise<void> {
    if (this.isRunning) {
      console.log('⚠️  Scraper đang chạy, bỏ qua lần này.');
      return;
    }

    this.isRunning = true;
    this.runCount++;
    console.log(`\n🔄 Run #${this.runCount} — ${new Date().toLocaleString('vi-VN')}`);

    try {
      const result = await this.scraper.scrapeAll();

      // Export files
      const files = exportAll(result, this.opts.outputDir);
      console.log('📁 Files:', Object.values(files).map(f => path.basename(f)).join(', '));

      // Change detection
      const changes = this.detector.detect(result.listings);

      if (changes.newListings.length > 0) {
        console.log(`🆕 ${changes.newListings.length} listing MỚI:`);
        changes.newListings.forEach(l =>
          console.log(`   + ${l.code} | ${l.title.substring(0, 50)} | ${(l.price / 1e9).toFixed(1)} tỷ`)
        );
        this.opts.onNewListings?.(changes.newListings);
      }

      if (changes.priceChanges.length > 0) {
        console.log(`💹 ${changes.priceChanges.length} THAY ĐỔI GIÁ:`);
        changes.priceChanges.forEach(c =>
          console.log(`   ~ ${c.listing.code} | ${(c.oldPrice / 1e9).toFixed(1)} → ${(c.newPrice / 1e9).toFixed(1)} tỷ (${c.changePercent > 0 ? '+' : ''}${c.changePercent.toFixed(1)}%)`)
        );
        this.opts.onPriceChanges?.(changes.priceChanges);
      }

      if (changes.soldListings.length > 0) {
        console.log(`🔴 ${changes.soldListings.length} đã BÁN/HỆT:`);
        changes.soldListings.forEach(l =>
          console.log(`   - ${l.code} | ${l.title.substring(0, 50)}`)
        );
        this.opts.onSoldListings?.(changes.soldListings);
      }

    } catch (err) {
      console.error(`❌ Run #${this.runCount} thất bại:`, err);
    } finally {
      this.isRunning = false;
    }
  }
}
