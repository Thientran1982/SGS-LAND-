// ================================================================
// SCRAPER CORE — sgsland.vn
// API đã xác nhận hoạt động:
//   GET /api/public/listings?page=N&pageSize=N&[filters]
//   GET /api/public/listings/:uuid
//   GET /api/valuation/teaser?location=...&area=N
// ================================================================

import type {
  Listing, ListingAttributes, ListingImage,
  PaginatedResponse, ValuationTeaser,
  ScraperConfig, ScrapeResult, ScrapeStats,
  PriceStats, AreaStats
} from './types.js';

// ── Hằng số ──────────────────────────────────────────────────────
const DEFAULT_CONFIG: ScraperConfig = {
  baseUrl:              'https://sgsland.vn',
  pageSize:             20,
  delayMs:              800,     // ms giữa mỗi request
  maxRetries:           3,
  enrichWithValuation:  false,   // set true để gọi thêm valuation teaser
  outputDir:            './output',
};

// ── Helpers ───────────────────────────────────────────────────────

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

function formatBillion(n: number): string {
  return (n / 1_000_000_000).toFixed(2) + ' tỷ';
}

function percentile(sorted: number[], p: number): number {
  const idx = Math.floor(sorted.length * p / 100);
  return sorted[Math.min(idx, sorted.length - 1)];
}

// ── Normalize raw API → Listing ───────────────────────────────────

function normalizeImage(img: any): ListingImage {
  if (typeof img === 'string') return { url: img };
  return {
    url:   img.url || img.src || img.path || '',
    thumb: img.thumb || img.thumbnail || undefined,
    alt:   img.alt   || undefined,
  };
}

function normalizeAttributes(attrs: any): ListingAttributes {
  if (!attrs || typeof attrs !== 'object') {
    return { description: null, direction: null, frontage: null, roadWidth: null, furniture: null, landType: null, floors: null, legalType: null };
  }
  return {
    description: attrs.description   ?? null,
    direction:   attrs.direction     ?? null,
    frontage:    attrs.frontage      ?? null,
    roadWidth:   attrs.roadWidth     ?? null,
    furniture:   attrs.furniture     ?? null,
    landType:    attrs.landType      ?? null,
    floors:      attrs.floors        ?? null,
    legalType:   attrs.legalType     ?? attrs.legal ?? null,
    ...attrs,  // giữ lại mọi field chưa biết
  };
}

export function normalizeListing(raw: any, baseUrl = 'https://sgsland.vn'): Listing {
  const pricePerM2 = (raw.price && raw.area)
    ? Math.round(raw.price / raw.area)
    : null;

  return {
    id:             raw.id,
    code:           raw.code,
    tenantId:       raw.tenantId   ?? '',
    title:          raw.title      ?? '',
    type:           raw.type       ?? 'Unknown',
    status:         raw.status     ?? 'UNKNOWN',
    transaction:    raw.transaction ?? 'SALE',
    price:          raw.price      ?? 0,
    pricePerM2,
    currency:       raw.currency   ?? 'VND',
    area:           raw.area       ?? 0,
    bedrooms:       raw.bedrooms   ?? null,
    bathrooms:      raw.bathrooms  ?? null,
    location:       raw.location   ?? '',
    address:        raw.address    ?? null,
    coordinates:    raw.coordinates ?? null,
    projectId:      raw.projectId   ?? null,
    projectCode:    raw.projectCode ?? null,
    isVerified:     raw.isVerified  ?? false,
    viewCount:      raw.viewCount   ?? 0,
    bookingCount:   raw.bookingCount ?? 0,
    totalUnits:     raw.totalUnits  ?? null,
    availableUnits: raw.availableUnits ?? null,
    holdExpiresAt:  raw.holdExpiresAt  ?? null,
    attributes:     normalizeAttributes(raw.attributes),
    images:         (raw.images ?? []).map(normalizeImage),
    contactPhone:   raw.contactPhone ?? null,
    ownerName:      raw.ownerName    ?? null,
    ownerPhone:     raw.ownerPhone   ?? null,
    commission:     raw.commission   ?? null,
    commissionUnit: raw.commissionUnit ?? 'PERCENT',
    authorizedAgents: raw.authorizedAgents ?? [],
    assignedTo:     raw.assignedTo     ?? null,
    assignedToName: raw.assignedToName ?? null,
    assignedToEmail: raw.assignedToEmail ?? null,
    assignedToAvatar: raw.assignedToAvatar ?? null,
    assignedToRole: raw.assignedToRole ?? null,
    createdBy:      raw.createdBy   ?? null,
    createdAt:      raw.createdAt   ?? '',
    updatedAt:      raw.updatedAt   ?? '',
    scrapedAt:      new Date().toISOString(),
    sourceUrl:      `${baseUrl}/listing/${raw.id}`,
  };
}

// ── Stats ─────────────────────────────────────────────────────────

function computeStats(listings: Listing[]): ScrapeStats {
  const prices = listings.map(l => l.price).filter(Boolean).sort((a, b) => a - b);
  const areas  = listings.map(l => l.area).filter(Boolean).sort((a, b) => a - b);

  const byType: Record<string, number>        = {};
  const byTransaction: Record<string, number> = {};
  const byStatus: Record<string, number>      = {};
  const locationCount: Record<string, number> = {};

  for (const l of listings) {
    byType[l.type]               = (byType[l.type] || 0) + 1;
    byTransaction[l.transaction] = (byTransaction[l.transaction] || 0) + 1;
    byStatus[l.status]           = (byStatus[l.status] || 0) + 1;
    if (l.location) {
      locationCount[l.location] = (locationCount[l.location] || 0) + 1;
    }
  }

  const priceStats: PriceStats = prices.length ? {
    min:    prices[0],
    max:    prices[prices.length - 1],
    avg:    Math.round(prices.reduce((a, b) => a + b, 0) / prices.length),
    median: percentile(prices, 50),
    p25:    percentile(prices, 25),
    p75:    percentile(prices, 75),
  } : { min: 0, max: 0, avg: 0, median: 0, p25: 0, p75: 0 };

  const areaStats: AreaStats = areas.length ? {
    min: areas[0],
    max: areas[areas.length - 1],
    avg: Math.round(areas.reduce((a, b) => a + b, 0) / areas.length),
  } : { min: 0, max: 0, avg: 0 };

  const topLocations = Object.entries(locationCount)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)
    .map(([location, count]) => ({ location, count }));

  return {
    totalListings:  listings.length,
    verifiedCount:  listings.filter(l => l.isVerified).length,
    byType,
    byTransaction,
    byStatus,
    price:          priceStats,
    area:           areaStats,
    topLocations,
  };
}

// ── Core Scraper Class ────────────────────────────────────────────

export class SgsLandScraper {
  private cfg: ScraperConfig;
  private listingsUrl: string;
  private valuationUrl: string;
  private errors: Array<{ url: string; error: string }> = [];

  constructor(config: Partial<ScraperConfig> = {}) {
    this.cfg          = { ...DEFAULT_CONFIG, ...config };
    this.listingsUrl  = `${this.cfg.baseUrl}/api/public/listings`;
    this.valuationUrl = `${this.cfg.baseUrl}/api/valuation/teaser`;
  }

  // ── HTTP ─────────────────────────────────────────────────────────

  private async fetchJSON<T = any>(url: string): Promise<T> {
    let lastError: Error = new Error('Unknown');

    for (let attempt = 1; attempt <= this.cfg.maxRetries; attempt++) {
      try {
        const res = await fetch(url, {
          headers: {
            'Accept':       'application/json',
            'User-Agent':   'SGSLand-Scraper/2.0 (internal-tool)',
            'Cache-Control': 'no-cache',
          },
        });

        if (res.status === 429) {
          // Rate limited — exponential backoff
          const wait = this.cfg.delayMs * Math.pow(2, attempt);
          console.warn(`  ⏳ Rate limited. Chờ ${wait}ms...`);
          await sleep(wait);
          continue;
        }

        if (res.status === 503) {
          // Server error — retry với backoff
          const wait = this.cfg.delayMs * attempt;
          console.warn(`  ⚠️  503 Service Unavailable. Chờ ${wait}ms... (attempt ${attempt}/${this.cfg.maxRetries})`);
          await sleep(wait);
          continue;
        }

        if (!res.ok) {
          throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }

        return await res.json() as T;

      } catch (err) {
        lastError = err as Error;
        if (attempt < this.cfg.maxRetries) {
          await sleep(this.cfg.delayMs * attempt);
        }
      }
    }

    this.errors.push({ url, error: lastError.message });
    throw lastError;
  }

  // ── Build URL ─────────────────────────────────────────────────────

  private buildListingsUrl(page: number): string {
    const p = new URLSearchParams({
      page:     String(page),
      pageSize: String(this.cfg.pageSize),
    });

    const f = this.cfg.filters ?? {};
    if (f.type)        p.set('type',        f.type);
    if (f.transaction) p.set('transaction', f.transaction);
    if (f.location)    p.set('location',    f.location);
    if (f.minPrice)    p.set('minPrice',    String(f.minPrice));
    if (f.maxPrice)    p.set('maxPrice',    String(f.maxPrice));
    if (f.minArea)     p.set('minArea',     String(f.minArea));
    if (f.maxArea)     p.set('maxArea',     String(f.maxArea));
    if (f.isVerified)  p.set('isVerified',  'true');
    if (f.search)      p.set('search',      f.search);

    return `${this.listingsUrl}?${p.toString()}`;
  }

  // ── Valuation Enrichment ──────────────────────────────────────────

  async fetchValuation(location: string, area: number): Promise<ValuationTeaser | null> {
    if (!location || !area) return null;
    try {
      const url = `${this.valuationUrl}?location=${encodeURIComponent(location)}&area=${area}`;
      const data = await this.fetchJSON<ValuationTeaser>(url);
      return data.found ? data : null;
    } catch {
      return null;
    }
  }

  // ── Main Scrape ───────────────────────────────────────────────────

  async scrapeAll(): Promise<ScrapeResult> {
    const startTime = Date.now();
    this.errors = [];
    console.log('\n🚀 Bắt đầu scrape sgsland.vn...');
    console.log(`   Config: pageSize=${this.cfg.pageSize}, delay=${this.cfg.delayMs}ms, enrichValuation=${this.cfg.enrichWithValuation}`);
    if (this.cfg.filters && Object.keys(this.cfg.filters).length) {
      console.log(`   Filters: ${JSON.stringify(this.cfg.filters)}`);
    }

    // Trang đầu — lấy tổng số trang
    const firstUrl = this.buildListingsUrl(1);
    console.log(`\n📡 Fetching trang 1...`);
    const firstPage = await this.fetchJSON<PaginatedResponse>(firstUrl);

    const { total, totalPages } = firstPage;
    console.log(`📊 Tổng: ${total} listings / ${totalPages} trang`);

    // Thu thập tất cả raw data
    const allRaw: any[] = [...(firstPage.data ?? [])];
    console.log(`   ✅ Trang 1/${totalPages}: ${firstPage.data?.length ?? 0} items`);

    for (let page = 2; page <= totalPages; page++) {
      await sleep(this.cfg.delayMs);
      console.log(`📡 Fetching trang ${page}/${totalPages}...`);

      try {
        const pageData = await this.fetchJSON<PaginatedResponse>(this.buildListingsUrl(page));
        allRaw.push(...(pageData.data ?? []));
        console.log(`   ✅ Trang ${page}/${totalPages}: ${pageData.data?.length ?? 0} items (tổng: ${allRaw.length})`);
      } catch (err) {
        console.error(`   ❌ Trang ${page} thất bại: ${err}`);
      }
    }

    // Normalize
    const listings: Listing[] = allRaw.map(r => normalizeListing(r, this.cfg.baseUrl));
    console.log(`\n✅ Normalized: ${listings.length} listings`);

    // Enrichment với valuation
    let enriched = 0;
    if (this.cfg.enrichWithValuation) {
      console.log(`\n🔬 Enriching với valuation teaser...`);
      for (const listing of listings) {
        if (listing.location && listing.area) {
          await sleep(this.cfg.delayMs / 2);
          listing.valuation = await this.fetchValuation(listing.location, listing.area);
          if (listing.valuation) enriched++;
        }
      }
      console.log(`   ✅ Enriched: ${enriched}/${listings.length}`);
    }

    const duration = Date.now() - startTime;
    const stats    = computeStats(listings);

    const result: ScrapeResult = {
      config: {
        baseUrl:  this.cfg.baseUrl,
        pageSize: this.cfg.pageSize,
        filters:  this.cfg.filters,
      },
      total,
      scraped:  listings.length,
      enriched,
      failed:   this.errors.length,
      listings,
      stats,
      scrapedAt:  new Date().toISOString(),
      durationMs: duration,
    };

    this.printSummary(result);
    return result;
  }

  // ── Single listing ────────────────────────────────────────────────

  async scrapeOne(uuid: string): Promise<Listing | null> {
    try {
      const raw  = await this.fetchJSON<any>(`${this.listingsUrl}/${uuid}`);
      const item = normalizeListing(raw, this.cfg.baseUrl);
      if (this.cfg.enrichWithValuation && item.location && item.area) {
        item.valuation = await this.fetchValuation(item.location, item.area);
      }
      return item;
    } catch (err) {
      console.error(`scrapeOne(${uuid}) failed:`, err);
      return null;
    }
  }

  // ── Summary ───────────────────────────────────────────────────────

  private printSummary(r: ScrapeResult): void {
    const s = r.stats;
    console.log('\n' + '═'.repeat(50));
    console.log('📈  KẾT QUẢ SCRAPE sgsland.vn');
    console.log('═'.repeat(50));
    console.log(`  Tổng listing    : ${r.scraped}/${r.total} (${r.failed} thất bại)`);
    console.log(`  Đã xác thực     : ${s.verifiedCount}`);
    console.log(`  Loại hình       : ${JSON.stringify(s.byType)}`);
    console.log(`  Giao dịch       : ${JSON.stringify(s.byTransaction)}`);
    console.log(`  Giá (min→max)   : ${formatBillion(s.price.min)} → ${formatBillion(s.price.max)}`);
    console.log(`  Giá trung bình  : ${formatBillion(s.price.avg)}`);
    console.log(`  Giá trung vị    : ${formatBillion(s.price.median)}`);
    console.log(`  Diện tích TB    : ${s.area.avg} m²`);
    console.log(`  Thời gian       : ${r.durationMs}ms`);
    if (r.enriched > 0) {
      console.log(`  Định giá AI     : ${r.enriched} listings`);
    }
    if (s.topLocations.length > 0) {
      console.log(`  Top vị trí      :`);
      s.topLocations.slice(0, 5).forEach(({ location, count }) => {
        console.log(`    - ${location}: ${count}`);
      });
    }
    console.log('═'.repeat(50) + '\n');
  }

  // ── Getters ───────────────────────────────────────────────────────

  get errorLog() { return this.errors; }
}
