// ================================================================
// TYPES — sgsland-scraper
// Dựa trên kiểm tra thực tế API sgsland.vn ngày 2026-04-10
// ================================================================

export interface Listing {
  // Core IDs
  id: string;               // UUID — dùng cho /api/public/listings/:id
  code: string;             // LST + số — dùng để hiển thị
  tenantId: string;

  // Nội dung
  title: string;
  type: ListingType;
  status: ListingStatus;
  transaction: TransactionType;

  // Giá
  price: number;            // VND nguyên (vd: 13200000000)
  pricePerM2: number | null;
  currency: string;         // 'VND'

  // Kích thước
  area: number;             // m²
  bedrooms: number | null;
  bathrooms: number | null;

  // Vị trí
  location: string;         // 'đường Ngô Quyền, Long Hưng, Đồng Nai'
  address: string | null;
  coordinates: Coordinates | null;
  projectId: string | null;
  projectCode: string | null;

  // Trạng thái
  isVerified: boolean;
  viewCount: number;
  bookingCount: number;
  totalUnits: number | null;
  availableUnits: number | null;
  holdExpiresAt: string | null;

  // Thuộc tính chi tiết
  attributes: ListingAttributes;

  // Media
  images: ListingImage[];

  // Liên hệ
  contactPhone: string | null;
  ownerName: string | null;
  ownerPhone: string | null;

  // Hoa hồng
  commission: number | null;
  commissionUnit: CommissionUnit;
  authorizedAgents: string[];

  // Phân công nội bộ
  assignedTo: string | null;
  assignedToName: string | null;
  assignedToEmail: string | null;
  assignedToAvatar: string | null;
  assignedToRole: string | null;
  createdBy: string | null;

  // Timestamps
  createdAt: string;
  updatedAt: string;

  // Enrichment (thêm khi scrape)
  valuation?: ValuationTeaser | null;
  scrapedAt?: string;
  sourceUrl?: string;
}

export interface ListingAttributes {
  description: string | null;
  direction: DirectionType | null;
  frontage: number | null;         // mét
  roadWidth: number | null;        // mét
  furniture: FurnitureType | null;
  landType: string | null;         // 'ONT', etc.
  floors: number | null;
  legalType: string | null;        // 'HDMB', 'SODO', etc.
  [key: string]: any;
}

export interface ListingImage {
  url: string;
  thumb?: string;
  alt?: string;
}

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface ValuationTeaser {
  found: boolean;
  locationDisplay: string;
  pricePerM2: number;
  priceMin: number;
  priceMax: number;
  pricePerM2Display: string;
  totalMin: number;
  totalMid: number;
  totalMax: number;
  totalMinDisplay: string;
  totalMidDisplay: string;
  totalMaxDisplay: string;
  area: number;
  confidence: number;            // 0-100
  trendText: string;
  dataSource: string;
  dataAge: string;
}

export interface PaginatedResponse {
  data: any[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  stats: ListingStats;
}

export interface ListingStats {
  availableCount: number;
  holdCount: number;
  soldCount: number;
  rentedCount: number;
  bookingCount: number;
  openingCount: number;
  inactiveCount: number;
  totalCount: number;
}

export interface ScraperConfig {
  baseUrl: string;
  pageSize: number;
  delayMs: number;
  maxRetries: number;
  enrichWithValuation: boolean;
  outputDir: string;
  filters?: ListingFilters;
}

export interface ListingFilters {
  type?: ListingType;
  transaction?: TransactionType;
  location?: string;
  minPrice?: number;
  maxPrice?: number;
  minArea?: number;
  maxArea?: number;
  isVerified?: boolean;
  search?: string;
}

export interface ScrapeResult {
  config: Partial<ScraperConfig>;
  total: number;
  scraped: number;
  enriched: number;
  failed: number;
  listings: Listing[];
  stats: ScrapeStats;
  scrapedAt: string;
  durationMs: number;
}

export interface ScrapeStats {
  totalListings: number;
  verifiedCount: number;
  byType: Record<string, number>;
  byTransaction: Record<string, number>;
  byStatus: Record<string, number>;
  price: PriceStats;
  area: AreaStats;
  topLocations: Array<{ location: string; count: number }>;
}

export interface PriceStats {
  min: number;
  max: number;
  avg: number;
  median: number;
  p25: number;
  p75: number;
}

export interface AreaStats {
  min: number;
  max: number;
  avg: number;
}

// Enums
export type ListingType     = 'Villa' | 'Townhouse' | 'Commercial' | 'Apartment' | 'Land' | string;
export type ListingStatus   = 'AVAILABLE' | 'HOLD' | 'SOLD' | 'RENTED' | 'INACTIVE' | 'OPENING';
export type TransactionType = 'SALE' | 'RENT';
export type CommissionUnit  = 'PERCENT' | 'FIXED';
export type DirectionType   = 'North' | 'South' | 'East' | 'West' | 'NorthEast' | 'NorthWest' | 'SouthEast' | 'SouthWest' | string;
export type FurnitureType   = 'NONE' | 'BASIC' | 'FULL' | string;
