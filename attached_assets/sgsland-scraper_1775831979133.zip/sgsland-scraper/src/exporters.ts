// ================================================================
// EXPORTERS — xuất dữ liệu ra JSON, CSV, Markdown
// ================================================================

import fs   from 'fs';
import path from 'path';
import type { ScrapeResult, Listing } from './types.js';

// ── Helpers ───────────────────────────────────────────────────────

function ensureDir(dir: string): void {
  fs.mkdirSync(dir, { recursive: true });
}

function timestamp(): string {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

function vnd(n: number): string {
  return n ? (n / 1_000_000_000).toFixed(3) + ' tỷ' : '';
}

function csvEscape(val: any): string {
  if (val === null || val === undefined) return '';
  const str = String(val);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return '"' + str.replace(/"/g, '""').replace(/\n/g, ' ') + '"';
  }
  return str;
}

// ── JSON export ───────────────────────────────────────────────────

export function exportJson(result: ScrapeResult, outputDir: string): string {
  ensureDir(outputDir);
  const file = path.join(outputDir, `sgsland_${timestamp()}.json`);
  fs.writeFileSync(file, JSON.stringify(result, null, 2), 'utf-8');
  console.log(`💾 JSON  → ${file} (${(fs.statSync(file).size / 1024).toFixed(1)} KB)`);
  return file;
}

// ── CSV export (Excel-compatible) ────────────────────────────────

const CSV_HEADERS = [
  'code', 'title', 'type', 'status', 'transaction',
  'price_vnd', 'price_display', 'price_per_m2',
  'area_m2', 'bedrooms', 'bathrooms',
  'location', 'address', 'lat', 'lng',
  'project_code', 'is_verified', 'view_count', 'booking_count',
  'direction', 'frontage_m', 'road_width_m', 'furniture', 'land_type',
  'commission', 'commission_unit',
  'image_count', 'first_image_url',
  'source_url', 'created_at', 'updated_at', 'scraped_at',
  // Valuation (nếu có)
  'val_price_per_m2', 'val_total_mid', 'val_confidence', 'val_location_display',
];

function listingToCsvRow(l: Listing): string {
  const vals = [
    l.code,
    l.title,
    l.type,
    l.status,
    l.transaction,
    l.price,
    vnd(l.price),
    l.pricePerM2 ?? '',
    l.area,
    l.bedrooms ?? '',
    l.bathrooms ?? '',
    l.location,
    l.address ?? '',
    l.coordinates?.lat ?? '',
    l.coordinates?.lng ?? '',
    l.projectCode ?? '',
    l.isVerified,
    l.viewCount,
    l.bookingCount,
    l.attributes.direction ?? '',
    l.attributes.frontage  ?? '',
    l.attributes.roadWidth ?? '',
    l.attributes.furniture ?? '',
    l.attributes.landType  ?? '',
    l.commission ?? '',
    l.commissionUnit,
    l.images.length,
    l.images[0]?.url ?? '',
    l.sourceUrl ?? '',
    l.createdAt,
    l.updatedAt,
    l.scrapedAt ?? '',
    // Valuation
    l.valuation?.pricePerM2        ?? '',
    l.valuation?.totalMid          ?? '',
    l.valuation?.confidence        ?? '',
    l.valuation?.locationDisplay   ?? '',
  ];
  return vals.map(csvEscape).join(',');
}

export function exportCsv(result: ScrapeResult, outputDir: string): string {
  ensureDir(outputDir);
  const file = path.join(outputDir, `sgsland_${timestamp()}.csv`);
  const lines = [
    '\uFEFF' + CSV_HEADERS.join(','),  // BOM cho Excel UTF-8
    ...result.listings.map(listingToCsvRow),
  ];
  fs.writeFileSync(file, lines.join('\n'), 'utf-8');
  console.log(`💾 CSV   → ${file} (${result.listings.length} rows)`);
  return file;
}

// ── Markdown report ───────────────────────────────────────────────

export function exportMarkdownReport(result: ScrapeResult, outputDir: string): string {
  ensureDir(outputDir);
  const file = path.join(outputDir, `sgsland_report_${timestamp()}.md`);
  const s    = result.stats;

  const typeTable = Object.entries(s.byType)
    .sort(([, a], [, b]) => b - a)
    .map(([type, count]) => `| ${type} | ${count} | ${((count / s.totalListings) * 100).toFixed(1)}% |`)
    .join('\n');

  const locationTable = s.topLocations
    .map(({ location, count }) => `| ${location} | ${count} |`)
    .join('\n');

  const sampleListings = result.listings.slice(0, 5)
    .map(l => `| ${l.code} | ${l.title.substring(0, 40)}... | ${vnd(l.price)} | ${l.area}m² | ${l.isVerified ? '✅' : '❌'} |`)
    .join('\n');

  const md = `# Báo Cáo Scrape sgsland.vn

> Scraped: **${result.scrapedAt}**  
> Thời gian: **${result.durationMs}ms**  
> Nguồn: [sgsland.vn/marketplace](https://sgsland.vn/marketplace)

---

## 📊 Tổng Quan

| Chỉ số | Giá trị |
|--------|---------|
| Tổng listings | **${result.total}** |
| Đã scrape | **${result.scraped}** |
| Đã xác thực | **${s.verifiedCount}** (${((s.verifiedCount / s.totalListings) * 100).toFixed(1)}%) |
| Thất bại | ${result.failed} |
| Enriched (định giá AI) | ${result.enriched} |

---

## 🏘️ Phân Loại

| Loại hình | Số lượng | Tỷ lệ |
|-----------|----------|-------|
${typeTable}

---

## 💰 Phân Tích Giá

| Chỉ số | Giá trị |
|--------|---------|
| Thấp nhất | ${vnd(s.price.min)} |
| Cao nhất | ${vnd(s.price.max)} |
| Trung bình | ${vnd(s.price.avg)} |
| Trung vị (P50) | ${vnd(s.price.median)} |
| P25 | ${vnd(s.price.p25)} |
| P75 | ${vnd(s.price.p75)} |

---

## 📐 Diện Tích

| Chỉ số | Giá trị |
|--------|---------|
| Nhỏ nhất | ${s.area.min} m² |
| Lớn nhất | ${s.area.max} m² |
| Trung bình | ${s.area.avg} m² |

---

## 📍 Top Vị Trí

| Vị trí | Số listings |
|--------|-------------|
${locationTable}

---

## 🔍 Mẫu Dữ Liệu (5 listings đầu)

| Mã | Tiêu đề | Giá | Diện tích | Xác thực |
|----|---------|-----|-----------|----------|
${sampleListings}

---

## 🔧 Cấu Hình Scrape

\`\`\`json
${JSON.stringify(result.config, null, 2)}
\`\`\`

---

*Được tạo tự động bởi SGSLand Scraper v2.0*
`;

  fs.writeFileSync(file, md, 'utf-8');
  console.log(`💾 Report → ${file}`);
  return file;
}

// ── NDJSON (Newline-delimited JSON) — dành cho streaming/pipeline ─

export function exportNdjson(result: ScrapeResult, outputDir: string): string {
  ensureDir(outputDir);
  const file = path.join(outputDir, `sgsland_${timestamp()}.ndjson`);
  const lines = result.listings.map(l => JSON.stringify(l));
  fs.writeFileSync(file, lines.join('\n'), 'utf-8');
  console.log(`💾 NDJSON → ${file} (${result.listings.length} records)`);
  return file;
}

// ── Export tất cả ─────────────────────────────────────────────────

export function exportAll(result: ScrapeResult, outputDir: string): Record<string, string> {
  return {
    json:    exportJson(result, outputDir),
    csv:     exportCsv(result, outputDir),
    report:  exportMarkdownReport(result, outputDir),
    ndjson:  exportNdjson(result, outputDir),
  };
}
