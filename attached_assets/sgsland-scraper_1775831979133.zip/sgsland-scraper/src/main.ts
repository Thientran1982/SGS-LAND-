#!/usr/bin/env node
// ================================================================
// MAIN — SGSLand Scraper v2.0
//
// Cách dùng:
//   npx ts-node src/main.ts                         # scrape once, xuất tất cả
//   npx ts-node src/main.ts --mode=once             # giống trên
//   npx ts-node src/main.ts --mode=schedule         # chạy mỗi 30 phút
//   npx ts-node src/main.ts --mode=one --id=UUID    # scrape 1 listing
//   npx ts-node src/main.ts --type=Villa            # lọc theo loại
//   npx ts-node src/main.ts --search=biệt+thự       # tìm kiếm
//   npx ts-node src/main.ts --valuation             # thêm định giá AI
// ================================================================

import { SgsLandScraper }  from './scraper.js';
import { ScraperScheduler } from './scheduler.js';
import { exportAll, exportJson } from './exporters.js';

// ── Parse CLI args ────────────────────────────────────────────────

function parseArgs(): Record<string, string> {
  const args: Record<string, string> = { mode: 'once' };
  for (const arg of process.argv.slice(2)) {
    if (arg.startsWith('--')) {
      const [k, v = 'true'] = arg.slice(2).split('=');
      args[k] = v;
    }
  }
  return args;
}

// ── Main ──────────────────────────────────────────────────────────

async function main() {
  const args = parseArgs();
  const OUTPUT_DIR = args.output ?? './output';

  console.log('╔════════════════════════════════════════╗');
  console.log('║   SGSLand Scraper v2.0 — sgsland.vn   ║');
  console.log('╚════════════════════════════════════════╝');

  // Xây dựng config
  const scraper = new SgsLandScraper({
    baseUrl:             'https://sgsland.vn',
    pageSize:            20,
    delayMs:             parseInt(args.delay ?? '800'),
    maxRetries:          3,
    enrichWithValuation: args.valuation === 'true',
    outputDir:           OUTPUT_DIR,
    filters: {
      ...(args.type        && { type:        args.type }),
      ...(args.transaction && { transaction: args.transaction }),
      ...(args.location    && { location:    args.location }),
      ...(args.search      && { search:      decodeURIComponent(args.search) }),
      ...(args.minPrice    && { minPrice:    parseInt(args.minPrice) }),
      ...(args.maxPrice    && { maxPrice:    parseInt(args.maxPrice) }),
      ...(args.verified    && { isVerified:  true }),
    },
  });

  // ── Mode: single listing ────────────────────────────────────────
  if (args.mode === 'one' || args.id) {
    const uuid = args.id;
    if (!uuid) {
      console.error('❌ Cần cung cấp --id=UUID');
      process.exit(1);
    }
    console.log(`\n🔍 Scraping listing: ${uuid}`);
    const listing = await scraper.scrapeOne(uuid);
    if (listing) {
      console.log(JSON.stringify(listing, null, 2));
    } else {
      console.error('❌ Không tìm thấy listing');
    }
    return;
  }

  // ── Mode: once ─────────────────────────────────────────────────
  if (args.mode === 'once' || !args.mode) {
    const result = await scraper.scrapeAll();
    exportAll(result, OUTPUT_DIR);
    console.log('\n✅ Hoàn thành! Files đã lưu vào:', OUTPUT_DIR);
    return;
  }

  // ── Mode: schedule ─────────────────────────────────────────────
  if (args.mode === 'schedule') {
    const intervalMin = parseInt(args.interval ?? '30');
    const intervalMs  = intervalMin * 60 * 1000;

    const scheduler = new ScraperScheduler(scraper, {
      intervalMs,
      outputDir: OUTPUT_DIR,

      // Webhook / notification callbacks
      onNewListings: (listings) => {
        console.log(`\n📬 [WEBHOOK] ${listings.length} listing mới — gửi notification...`);
        // TODO: gửi email, Slack, Telegram, Zalo
      },
      onPriceChanges: (changes) => {
        console.log(`\n📬 [WEBHOOK] ${changes.length} thay đổi giá`);
        // TODO: cập nhật DB, gửi alert
      },
      onSoldListings: (listings) => {
        console.log(`\n📬 [WEBHOOK] ${listings.length} đã sold/hold`);
        // TODO: đánh dấu trong DB
      },
    });

    scheduler.start();

    // Graceful shutdown
    process.on('SIGINT',  () => { scheduler.stop(); process.exit(0); });
    process.on('SIGTERM', () => { scheduler.stop(); process.exit(0); });

    console.log(`\n⏳ Scheduler chạy. Nhấn Ctrl+C để dừng.`);
    await new Promise(() => {}); // Giữ process sống
  }
}

main().catch((err) => {
  console.error('Fatal:', err);
  process.exit(1);
});
