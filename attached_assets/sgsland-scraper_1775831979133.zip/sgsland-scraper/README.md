# SGSLand Scraper v2.0

Hệ thống scraper BĐS cho **sgsland.vn** — thu thập dữ liệu realtime qua API public.

---

## 🔍 API đã phát hiện (kiểm tra thực tế 2026-04-10)

| Endpoint | Auth | Mô tả |
|----------|------|-------|
| `GET /api/public/listings` | ❌ Không cần | Danh sách BĐS có pagination |
| `GET /api/public/listings/:uuid` | ❌ Không cần | Chi tiết 1 listing theo UUID |
| `GET /api/valuation/teaser` | ❌ Không cần | Định giá AI theo khu vực + diện tích |
| `GET /api/public/listings/locations` | ❌ Không cần | Danh sách vị trí |

### Query params hỗ trợ (`/api/public/listings`)
```
page, pageSize          — pagination
type                    — Villa | Townhouse | Commercial | Apartment
transaction             — SALE | RENT
location                — chuỗi địa chỉ
minPrice, maxPrice      — giá VND
minArea, maxArea        — diện tích m²
isVerified              — true/false
search                  — tìm kiếm full-text
```

### Cấu trúc Response
```json
{
  "data": [ ...listings ],
  "total": 53,
  "page": 1,
  "pageSize": 20,
  "totalPages": 3,
  "stats": {
    "availableCount": 53,
    "totalCount": 53
  }
}
```

---

## 📦 Cài đặt

```bash
cd sgsland-scraper
npm install
```

---

## 🚀 Cách dùng

### Scrape 1 lần (mặc định)
```bash
npm run once
# hoặc
npx ts-node src/main.ts
```

### Chạy định kỳ mỗi 30 phút
```bash
npm run schedule
# hoặc
npx ts-node src/main.ts --mode=schedule --interval=30
```

### Lọc theo loại hình
```bash
npx ts-node src/main.ts --type=Villa
npx ts-node src/main.ts --type=Townhouse
```

### Thêm định giá AI
```bash
npx ts-node src/main.ts --valuation=true
```

### Tìm kiếm
```bash
npx ts-node src/main.ts --search=biệt+thự
```

### Lọc giá
```bash
npx ts-node src/main.ts --minPrice=5000000000 --maxPrice=15000000000
```

### Scrape 1 listing cụ thể
```bash
npx ts-node src/main.ts --id=dd9a0dfb-87c8-4f8b-a5b1-f43285b3d43e
```

---

## 📂 Output files

Tất cả output được lưu vào `./output/`:

| File | Mô tả |
|------|-------|
| `sgsland_*.json` | Full data JSON |
| `sgsland_*.csv` | Excel-compatible CSV (UTF-8 BOM) |
| `sgsland_report_*.md` | Báo cáo Markdown |
| `sgsland_*.ndjson` | NDJSON cho pipeline/streaming |
| `.state.json` | State file cho change detection |

---

## 🔔 Change Detection (Scheduler)

Khi chạy `--mode=schedule`, hệ thống tự động phát hiện:

- **🆕 Listing mới** — xuất hiện lần đầu
- **💹 Thay đổi giá** — tăng/giảm % so với lần trước
- **🔴 Đã bán/hết** — chuyển từ AVAILABLE sang trạng thái khác

Cấu hình callbacks trong `src/main.ts`:
```typescript
onNewListings:   (listings) => { /* gửi Telegram/Zalo */ },
onPriceChanges:  (changes)  => { /* cập nhật DB */ },
onSoldListings:  (listings) => { /* đánh dấu sold */ },
```

---

## 🏗️ Kiến trúc

```
src/
├── types.ts       — TypeScript interfaces & types
├── scraper.ts     — Core scraper (HTTP, normalize, paginate)
├── exporters.ts   — JSON, CSV, Markdown, NDJSON exporters
├── scheduler.ts   — Cron scheduler + change detection
└── main.ts        — CLI entry point
```

---

## 📊 Dữ liệu mẫu (thực tế từ sgsland.vn)

```json
{
  "id": "dd9a0dfb-87c8-4f8b-a5b1-f43285b3d43e",
  "code": "LST870787",
  "title": "Bán biệt thự song lập NA.SV1-1 diện tích 10x20m giá đầu tư 12 tỷ",
  "type": "Villa",
  "status": "AVAILABLE",
  "transaction": "SALE",
  "price": 13200000000,
  "pricePerM2": 66000000,
  "currency": "VND",
  "area": 200,
  "location": "đường Ngô Quyền, Long Hưng, Đồng Nai",
  "coordinates": { "lat": 10.882098, "lng": 106.858173 },
  "isVerified": true,
  "viewCount": 9,
  "attributes": {
    "direction": "NorthEast",
    "frontage": 10,
    "roadWidth": 12,
    "furniture": "BASIC"
  },
  "valuation": {
    "pricePerM2": 72000000,
    "totalMid": 14400000000,
    "confidence": 57,
    "locationDisplay": "Aqua City, Biên Hòa, Đồng Nai"
  }
}
```

---

## ⚠️ Lưu ý

- Dùng delay `800ms` giữa mỗi request để không làm ảnh hưởng server
- API public không cần auth — không lưu hay hardcode cookie/token
- UUID dùng cho detail endpoint, không dùng LST code
- Rate limit: chưa phát hiện header limit, nhưng nên tôn trọng server

---

*SGSLand Scraper v2.0 — được xây dựng dựa trên kiểm tra thực tế API sgsland.vn*
